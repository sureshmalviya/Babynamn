//
//  SQLiteManager.h
//  collections
//
//  Created by Ester Sanchez on 10/03/11.
//  Copyright 2011 Dinamica Studios. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "sqlite3.h"
//************************
#import "MyFavoriteObject.h"
//************************

enum errorCodes {
	kDBNotExists,
	kDBFailAtOpen, 
	kDBFailAtCreate,
	kDBErrorQuery,
	kDBFailAtClose
};

@interface SQLiteManager : NSObject {

	sqlite3 *db; // The SQLite db reference
	NSString *databaseName; // The database name
}

- (id)initWithDatabaseNamed:(NSString *)name;

// SQLite Operations
- (NSError *) openDatabase;
- (NSError *) doQuery:(NSString *)sql;
- (NSError *)doUpdateQuery:(NSString *)sql withParams:(NSArray *)params;
- (NSArray *) getRowsForQuery:(NSString *)sql;
- (NSError *) closeDatabase;
- (NSInteger)getLastInsertRowID;

- (NSString *)getDatabaseDump;

#pragma mark - NEW DB METHODS
#pragma mark -
//-(void)insertEvent:(Events*)obj;
-(void)insertFavorite:(MyFavoriteObject*)obj;
//-(NSMutableArray *)getFavorite_Name:(NSString*)firstName;
-(NSMutableArray *)getFavorite_Name:(NSString*)firstName andGender:(NSString*)gender;
-(void)checkIfCoupanTimeIsCompleted:(NSString*)lastName;
-(NSMutableArray *)getAllFavorites;
-(BOOL)updateLastNameOfFavoriteList:(NSString*)lastName;
//-(BOOL)deleteFromFavoriteList:(NSString *)firstName;
-(BOOL)deleteFromFavoriteList:(NSString *)firstName andGender:(NSString*)gender;

-(NSMutableArray *)getAllCountries;

-(NSString *)getFamousPeople_whoHaveName:(NSString*)name;
-(BOOL)updateOrderingOfFavoriteList:(int)newOrdering name:(NSString*)name andGender:(NSString*)gender;
-(int)getMaxOrdering;
@end


