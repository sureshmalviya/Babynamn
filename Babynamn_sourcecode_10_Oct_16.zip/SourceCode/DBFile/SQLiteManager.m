//
//  SQLiteManager.m
//  collections
//
//  Created by Ester Sanchez on 10/03/11.
//  Copyright 2011 Dinamica Studios. All rights reserved.
//

#import "SQLiteManager.h"



static  sqlite3 *database;
// Private methods
@interface SQLiteManager (Private)

- (NSString *)getDatabasePath;
- (NSError *)createDBErrorWithDescription:(NSString*)description andCode:(int)code;

@end



@implementation SQLiteManager

#pragma mark Init & Dealloc

/**
 * Init method.
 * Use this method to initialise the object, instead of just "init".
 *
 * @param name the name of the database to manage.
 *
 * @return the SQLiteManager object initialised.
 */

- (id)initWithDatabaseNamed:(NSString *)name; {
	self = [super init];
	if (self != nil) {
		databaseName = [[NSString alloc] initWithString:name];
		db = nil;
	}
	return self;
}

#pragma mark SQLite Operations

/**
 * Open or create a SQLite3 database.
 *
 * If the db exists, then is opened and ready to use. If not exists then is created and opened.
 *
 * @return nil if everything was ok, an NSError in other case.
 *
 */

- (NSError *) openDatabase {
	
	NSError *error = nil;
	
	NSString *databasePath = [self getDatabasePath];
    
	const char *dbpath = [databasePath UTF8String];
	int result = sqlite3_open(dbpath, &db);
	if (result != SQLITE_OK) {
        const char *errorMsg = sqlite3_errmsg(db);
        NSString *errorStr = [NSString stringWithFormat:@"The database could not be opened: %@",[NSString stringWithCString:errorMsg encoding:NSUTF8StringEncoding]];
        error = [self createDBErrorWithDescription:errorStr	andCode:kDBFailAtOpen];
	}
	
	return error;
}


/**
 * Does an SQL query.
 *
 * You should use this method for everything but SELECT statements.
 *
 * @param sql the sql statement.
 *
 * @return nil if everything was ok, NSError in other case.
 */

- (NSError *)doQuery:(NSString *)sql {
	
    
	NSError *openError = nil;
	NSError *errorQuery = nil;
	
	//Check if database is open and ready.
	if (db == nil) {
		openError = [self openDatabase];
	}
	
	if (openError == nil) {
		sqlite3_stmt *statement;
		const char *query = [sql UTF8String];
		sqlite3_prepare_v2(db, query, -1, &statement, NULL);
		
		if (sqlite3_step(statement) == SQLITE_ERROR) {
			const char *errorMsg = sqlite3_errmsg(db);
			errorQuery = [self createDBErrorWithDescription:[NSString stringWithCString:errorMsg encoding:NSUTF8StringEncoding]
													andCode:kDBErrorQuery];
		}
		sqlite3_finalize(statement);
		errorQuery = [self closeDatabase];
	}
	else {
		errorQuery = openError;
	}
    
	return errorQuery;
}

/**
 * Does an SQL parameterized query.
 *
 * You should use this method for parameterized INSERT or UPDATE statements.
 *
 * @param sql the sql statement using ? for params.
 *
 * @param params NSArray of params type (id), in CORRECT order please.
 *
 * @return nil if everything was ok, NSError in other case.
 */

- (NSError *)doUpdateQuery:(NSString *)sql withParams:(NSArray *)params
{
	
	NSError *openError = nil;
	NSError *errorQuery = nil;
	
	//Check if database is open and ready.
	if (db == nil) {
        openError = [self openDatabase];
	}
	
	if (openError == nil) {
		sqlite3_stmt *statement;
		const char *query = [sql UTF8String];
		sqlite3_prepare_v2(db, query, -1, &statement, NULL);
        
        //BIND the params!
        int count =0;
        for (id param in params ) {
            count++;
            if ([param isKindOfClass:[NSString class]] )
                sqlite3_bind_text(statement, count, [param UTF8String], -1, SQLITE_TRANSIENT);
            if ([param isKindOfClass:[NSNumber class]] ) {
                if (!strcmp([param objCType], @encode(float)))
                    sqlite3_bind_double(statement, count, [param doubleValue]);
                else if (!strcmp([param objCType], @encode(int)))
                    sqlite3_bind_int(statement, count, [param intValue]);
                else if (!strcmp([param objCType], @encode(BOOL)))
                    sqlite3_bind_int(statement, count, [param intValue]);
                else
                    NSLog(@"unknown NSNumber");
            }
            if ([param isKindOfClass:[NSDate class]]) {
               sqlite3_bind_double(statement, count, [param timeIntervalSince1970]);
            }
            if ([param isKindOfClass:[NSData class]] ) {
                sqlite3_bind_blob(statement, count, [param bytes], [param length], SQLITE_STATIC);
            }
        }
		
		if (sqlite3_step(statement) == SQLITE_ERROR) {
			const char *errorMsg = sqlite3_errmsg(db);
			errorQuery = [self createDBErrorWithDescription:[NSString stringWithCString:errorMsg encoding:NSUTF8StringEncoding]
													andCode:kDBErrorQuery];
		}
		sqlite3_finalize(statement);
        errorQuery = [self closeDatabase];
	}
	else {
		errorQuery = openError;
	}
    
	return errorQuery;
}

- (NSInteger)getLastInsertRowID {

    NSError *openError = nil;
	
    sqlite3_int64 rowid = 0;
	
	//Check if database is open and ready.
	if (db == nil) {
		openError = [self openDatabase];
	}
	
	if (openError == nil) {
        rowid = sqlite3_last_insert_rowid(db);
    }
    
    return (NSInteger)rowid;
}

/**
 * Does a SELECT query and gets the info from the db.
 *
 * The return array contains an NSDictionary for row, made as: key=columName value= columnValue.
 *
 * For example, if we have a table named "users" containing:
 * name | pass
 * -------------
 * admin| 1234
 * pepe | 5678
 *
 * it will return an array with 2 objects:
 * resultingArray[0] = name=admin, pass=1234;
 * resultingArray[1] = name=pepe, pass=5678;
 *
 * So to get the admin password:
 * [[resultingArray objectAtIndex:0] objectForKey:@"pass"];
 *
 * @param sql the sql query (remember to use only a SELECT statement!).
 *
 * @return an array containing the rows fetched.
 */

- (NSArray *)getRowsForQuery:(NSString *)sql
{
	NSMutableArray *resultsArray = [[NSMutableArray alloc] initWithCapacity:1];
	
	if (db == nil) {
		[self openDatabase];
	}
	
	sqlite3_stmt *statement;
	const char *query = [sql UTF8String];
	int returnCode = sqlite3_prepare_v2(db, query, -1, &statement, NULL);
	
	if (returnCode == SQLITE_ERROR) {
		const char *errorMsg = sqlite3_errmsg(db);
		NSError *errorQuery = [self createDBErrorWithDescription:[NSString stringWithCString:errorMsg encoding:NSUTF8StringEncoding]
                                                         andCode:kDBErrorQuery];
		NSLog(@"%@", errorQuery);
	}
	
	while (sqlite3_step(statement) == SQLITE_ROW) {
		int columns = sqlite3_column_count(statement);
		NSMutableDictionary *result = [[NSMutableDictionary alloc] initWithCapacity:columns];
        
		for (int i = 0; i<columns; i++) {
			const char *name = sqlite3_column_name(statement, i);
            
			NSString *columnName = [NSString stringWithCString:name encoding:NSUTF8StringEncoding];
			
			int type = sqlite3_column_type(statement, i);
			
			switch (type) {
				case SQLITE_INTEGER:
				{
					int value = sqlite3_column_int(statement, i);
					[result setObject:[NSNumber numberWithInt:value] forKey:columnName];
					break;
				}
				case SQLITE_FLOAT:
				{
					float value = sqlite3_column_double(statement, i);
					[result setObject:[NSNumber numberWithFloat:value] forKey:columnName];
					break;
				}
				case SQLITE_TEXT:
				{
					const char *value = (const char*)sqlite3_column_text(statement, i);
					[result setObject:[NSString stringWithCString:value encoding:NSUTF8StringEncoding] forKey:columnName];
					break;
				}
                    
				case SQLITE_BLOB:
                {
                    int bytes = sqlite3_column_bytes(statement, i);
                    if (bytes > 0) {
                        const void *blob = sqlite3_column_blob(statement, i);
                        if (blob != NULL) {
                            [result setObject:[NSData dataWithBytes:blob length:bytes] forKey:columnName];
                        }
                    }
					break;
                }
                    
				case SQLITE_NULL:
					[result setObject:[NSNull null] forKey:columnName];
					break;
                    
				default:
				{
					const char *value = (const char *)sqlite3_column_text(statement, i);
					[result setObject:[NSString stringWithCString:value encoding:NSUTF8StringEncoding] forKey:columnName];
					break;
				}
                    
			} //end switch
			
			
		} //end for
		
		[resultsArray addObject:result];
		
	} //end while
	sqlite3_finalize(statement);
	
	[self closeDatabase];
	
	return resultsArray;
	
}


/**
 * Closes the database.
 *
 * @return nil if everything was ok, NSError in other case.
 */

- (NSError *) closeDatabase {
	
	NSError *error = nil;
    return error;
	
	if (db != nil) {
		if (sqlite3_close(db) != SQLITE_OK){
			const char *errorMsg = sqlite3_errmsg(db);
			NSString *errorStr = [NSString stringWithFormat:@"The database could not be closed: %@",[NSString stringWithCString:errorMsg encoding:NSUTF8StringEncoding]];
			error = [self createDBErrorWithDescription:errorStr andCode:kDBFailAtClose];
		}
		
		db = nil;
	}
	
	return error;
}


/**
 * Creates an SQL dump of the database.
 *
 * This method could get a csv format dump with a few changes.
 * But i prefer working with sql dumps ;)
 *
 * @return an NSString containing the dump.
 */

- (NSString *)getDatabaseDump {
	
	NSMutableString *dump = [[NSMutableString alloc] initWithCapacity:256];
	
	// info string ;) please do not remove it
	[dump appendString:@";\n; Dump generated with SQLiteManager4iOS \n;\n; By Misato (2011)\n"];
	[dump appendString:[NSString stringWithFormat:@"; database %@;\n", [databaseName lastPathComponent]]];
	
	// first get all table information
	
	NSArray *rows = [self getRowsForQuery:@"SELECT * FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%';"];
	// last sql query returns something like:
	// {
	// name = users;
	// rootpage = 2;
	// sql = "CREATE TABLE users (id integer primary key autoincrement, user text, password text)";
	// "tbl_name" = users;
	// type = table;
	// }
	
	//loop through all tables
	for (int i = 0; i<[rows count]; i++) {
		
		NSDictionary *obj = [rows objectAtIndex:i];
		//get sql "create table" sentence
		NSString *sql = [obj objectForKey:@"sql"];
		[dump appendString:[NSString stringWithFormat:@"%@;\n",sql]];
        
		//get table name
		NSString *tableName = [obj objectForKey:@"name"];
        
		//get all table content
		NSArray *tableContent = [self getRowsForQuery:[NSString stringWithFormat:@"SELECT * FROM %@",tableName]];
		
		for (int j = 0; j<[tableContent count]; j++) {
			NSDictionary *item = [tableContent objectAtIndex:j];
			
			//keys are column names
			NSArray *keys = [item allKeys];
			
			//values are column values
			NSArray *values = [item allValues];
			
			//start constructing insert statement for this item
			[dump appendString:[NSString stringWithFormat:@"insert into %@ (",tableName]];
			
			//loop through all keys (aka column names)
			NSEnumerator *enumerator = [keys objectEnumerator];
			id obj;
			while (obj = [enumerator nextObject]) {
				[dump appendString:[NSString stringWithFormat:@"%@,",obj]];
			}
			
			//delete last comma
			NSRange range;
			range.length = 1;
			range.location = [dump length]-1;
			[dump deleteCharactersInRange:range];
			[dump appendString:@") values ("];
			
			// loop through all values
			// value types could be:
			// NSNumber for integer and floats, NSNull for null or NSString for text.
			
			enumerator = [values objectEnumerator];
			while (obj = [enumerator nextObject]) {
				//if it's a number (integer or float)
				if ([obj isKindOfClass:[NSNumber class]]){
					[dump appendString:[NSString stringWithFormat:@"%@,",[obj stringValue]]];
				}
				//if it's a null
				else if ([obj isKindOfClass:[NSNull class]]){
					[dump appendString:@"null,"];
				}
				//else is a string ;)
				else{
					[dump appendString:[NSString stringWithFormat:@"'%@',",obj]];
				}
				
			}
			
			//delete last comma again
			range.length = 1;
			range.location = [dump length]-1;
			[dump deleteCharactersInRange:range];
			
			//finish our insert statement
			[dump appendString:@");\n"];
			
		}
		
	}
    
	return dump;
}

@end


#pragma mark -
@implementation SQLiteManager (Private)

/**
 * Gets the database file path (in NSDocumentDirectory).
 *
 * @return the path to the db file.
 */

- (NSString *)getDatabasePath{
	
	if([[NSFileManager defaultManager] fileExistsAtPath:databaseName]){
		// Already Full Path
		return databaseName;
	} else {
        // Get the documents directory
        NSArray *dirPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *docsDir = [dirPaths objectAtIndex:0];
        
        return [docsDir stringByAppendingPathComponent:databaseName];
	}
}

/**
 * Creates an NSError.
 *
 * @param description the description wich can be queried with [error localizedDescription];
 * @param code the error code (code erors are defined as enum in the header file).
 *
 * @return the NSError just created.
 *
 */

- (NSError *)createDBErrorWithDescription:(NSString*)description andCode:(int)code {
	
	NSDictionary *userInfo = [[NSDictionary alloc] initWithObjectsAndKeys:description, NSLocalizedDescriptionKey, nil];
	NSError *error = [NSError errorWithDomain:@"SQLite Error" code:code userInfo:userInfo];
	
	return error;
}
#pragma mark - NEW DB METHODS
#pragma mark -
-(void)insertFavorite:(MyFavoriteObject*)obj
{
//    NSString *deleteQuery=[NSString stringWithFormat:@"DELETE FROM \"%@\" WHERE id=\"%@\"",TABLE_EVENTS,obj.strEventID];
//    NSError *error=[App_Delegate.dbManager doQuery:deleteQuery];
    
    sqlite3_stmt *compiledStatement;
    //    sqlite3_finalize(compiledStatement);
    //    compiledStatement=nil;
    database = db;
    if (!database) {
        sqlite3_open([App_Delegate.dbPath UTF8String], &database);
    }
    
    
    NSString *queryString=[NSString stringWithFormat:@"INSERT into my_favorite (name, last_name, gender, ordering) values(?,?,?,?)"];
    
    const char *insertSql = [queryString  cStringUsingEncoding:NSUTF8StringEncoding];
    
    if(sqlite3_prepare_v2(database, insertSql, -1, &compiledStatement, NULL) == SQLITE_OK)
    {
        int columIndex=0;
        
        
        sqlite3_bind_text(compiledStatement, ++columIndex, [[obj.strFirstName capitalizedString] UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strLastName UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strGender UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_int(compiledStatement, ++columIndex, obj.ordering);
        
        //sqlite3_bind_double(compiledStatement, ++columIndex, message.ID );
        //sqlite3_bind_text(compiledStatement, ++columIndex, [message.strFriendUserName UTF8String],-1,SQLITE_TRANSIENT);
        //sqlite3_bind_int(compiledStatement, ++columIndex, message.status);
    }
    
    if(sqlite3_step(compiledStatement) != SQLITE_DONE)
    {
        //NSAssert1(0, @"Error while creating insert statement '%s'", sqlite3_errmsg(database));
        //    NSLog(@"Error Occured:'%s'",sqlite3_errmsg(database));
    }
    else
    {
        //    NSLog(@"Row Inserted!!!:");
    }
    
    //if(database) sqlite3_close(database);

}
-(NSMutableArray *)getFavorite_Name:(NSString*)firstName andGender:(NSString*)gender
{
    sqlite3_stmt *compiledStatement;
    
    database = db;
    if (!database) {
        sqlite3_open([App_Delegate.dbPath UTF8String], &database);
    }
    
    NSMutableArray *arrFav=[[NSMutableArray alloc] init];
    
    NSString *queryString;
    
    if ([gender isEqualToString:@"zero"])
    {
        queryString=[NSString stringWithFormat:@"SELECT * From my_favorite WHERE name=\"%@\" order by ordering",firstName];
    }
    else
    {
        queryString=[NSString stringWithFormat:@"SELECT * From my_favorite WHERE name=\"%@\" AND gender=\"%@\" order by ordering",firstName,gender];
    }
    
    const char *sqlSelect = [queryString  cStringUsingEncoding:NSUTF8StringEncoding];
    
    if(sqlite3_prepare_v2(database, sqlSelect, -1, &compiledStatement, NULL) != SQLITE_OK)
    {
        NSLog(@"Error Occured:'%s'",sqlite3_errmsg(database));
    }
    else
    {
        // Loop through the results and add them to the feeds array
        while(sqlite3_step(compiledStatement) == SQLITE_ROW)
        {
            MyFavoriteObject *fav=[[MyFavoriteObject alloc]initWithDefaults];
            int columIndex=-1;
            fav.strFirstName=sqlite3_column_text(compiledStatement, ++columIndex) != NULL ?[NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement,columIndex)]:@"";
            
            fav.strLastName=sqlite3_column_text(compiledStatement, ++columIndex) != NULL ?[NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement,columIndex)]:@"";
            
            fav.strGender=sqlite3_column_text(compiledStatement, ++columIndex) != NULL ?[NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement,columIndex)]:@"";
            
            fav.ordering=sqlite3_column_int(compiledStatement, ++columIndex);
            
            if (fav.strLastName == (id)[NSNull null])
            {
                fav.strLastName=@"";
            }
            
            if (fav.strGender == (id)[NSNull null])
            {
                fav.strGender=@"";
            }
            
            [arrFav addObject:fav];
        }
    }
    sqlite3_finalize(compiledStatement);
    
    return arrFav;
}
-(NSMutableArray *)getAllFavorites
{
    sqlite3_stmt *compiledStatement;
    
    database = db;
    if (!database) {
        sqlite3_open([App_Delegate.dbPath UTF8String], &database);
    }
    
    NSMutableArray *arrFav=[[NSMutableArray alloc] init];
    
    NSString *queryString=[NSString stringWithFormat:@"SELECT * From my_favorite order by ordering"];
    
    const char *sqlSelect = [queryString  cStringUsingEncoding:NSUTF8StringEncoding];
    
    
    
    if(sqlite3_prepare_v2(database, sqlSelect, -1, &compiledStatement, NULL) != SQLITE_OK)
    {
        NSLog(@"Error Occured:'%s'",sqlite3_errmsg(database));
    }
    else
    {
        // Loop through the results and add them to the feeds array
        while(sqlite3_step(compiledStatement) == SQLITE_ROW)
        {
            MyFavoriteObject *fav=[[MyFavoriteObject alloc]initWithDefaults];
            int columIndex=-1;
            fav.strFirstName=sqlite3_column_text(compiledStatement, ++columIndex) != NULL ?[NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement,columIndex)]:@"";
            
            fav.strLastName=sqlite3_column_text(compiledStatement, ++columIndex) != NULL ?[NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement,columIndex)]:@"";
            
            
            
            if (fav.strLastName == (id)[NSNull null])
            {
                fav.strLastName=@"";
            }
            
            fav.strGender=sqlite3_column_text(compiledStatement, ++columIndex) != NULL ?[NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement,columIndex)]:@"";
            
            if (fav.strGender == (id)[NSNull null])
            {
                fav.strGender=@"";
            }
            
            fav.ordering=sqlite3_column_int(compiledStatement, ++columIndex);
            
            
            [arrFav addObject:fav];
        }
    }
    sqlite3_finalize(compiledStatement);
    
    return arrFav;
}
-(int)getMaxOrdering
{
    sqlite3_stmt *compiledStatement;
    
    database = db;
    if (!database) {
        sqlite3_open([App_Delegate.dbPath UTF8String], &database);
    }
    
    NSMutableArray *arrFav=[[NSMutableArray alloc] init];
    
    NSString *queryString=[NSString stringWithFormat:@"SELECT max(ordering) From my_favorite"];
    
    const char *sqlSelect = [queryString  cStringUsingEncoding:NSUTF8StringEncoding];
    
    int order_fav=0;
    
    if(sqlite3_prepare_v2(database, sqlSelect, -1, &compiledStatement, NULL) != SQLITE_OK)
    {
        NSLog(@"Error Occured:'%s'",sqlite3_errmsg(database));
    }
    else
    {
        // Loop through the results and add them to the feeds array
        while(sqlite3_step(compiledStatement) == SQLITE_ROW)
        {
            MyFavoriteObject *fav=[[MyFavoriteObject alloc]initWithDefaults];
            int columIndex=-1;
            
            order_fav=sqlite3_column_int(compiledStatement, ++columIndex);
            
           
        }
    }
    sqlite3_finalize(compiledStatement);
    
    return order_fav;
}
-(BOOL)updateLastNameOfFavoriteList:(NSString*)lastName
{
    sqlite3_stmt *compiledStatement;
    
    database = db;
    if (!database) {
        sqlite3_open([App_Delegate.dbPath UTF8String], &database);
    }
    
    NSString *queryString = [NSString stringWithFormat:@"UPDATE my_favorite SET last_name =\"%@\"",lastName];
    
    const char *insertSql = [queryString  cStringUsingEncoding:NSUTF8StringEncoding];
    
    if(sqlite3_prepare_v2(database, insertSql, -1, &compiledStatement, NULL) == SQLITE_OK)
    {
        
    }
    
    if(sqlite3_step(compiledStatement) != SQLITE_DONE)
    {
        //NSAssert1(0, @"Error while creating insert statement '%s'", sqlite3_errmsg(database));
        NSLog(@"Error Occured:'%s'",sqlite3_errmsg(database));
        
        return NO;
    }
    else
    {
        
    }
    sqlite3_finalize(compiledStatement);
    compiledStatement=nil;
    
    return YES;
}
-(BOOL)updateOrderingOfFavoriteList:(int)newOrdering name:(NSString*)name andGender:(NSString*)gender
{
    sqlite3_stmt *compiledStatement;
    
    database = db;
    if (!database) {
        sqlite3_open([App_Delegate.dbPath UTF8String], &database);
    }
    
    NSString *queryString = [NSString stringWithFormat:@"UPDATE my_favorite SET ordering =\"%d\" WHERE name=\"%@\" AND gender=\"%@\"",newOrdering,name,gender];
    
    const char *insertSql = [queryString  cStringUsingEncoding:NSUTF8StringEncoding];
    
    if(sqlite3_prepare_v2(database, insertSql, -1, &compiledStatement, NULL) == SQLITE_OK)
    {
        
    }
    
    if(sqlite3_step(compiledStatement) != SQLITE_DONE)
    {
        //NSAssert1(0, @"Error while creating insert statement '%s'", sqlite3_errmsg(database));
        NSLog(@"Error Occured:'%s'",sqlite3_errmsg(database));
        
        return NO;
    }
    else
    {
        
    }
    sqlite3_finalize(compiledStatement);
    compiledStatement=nil;
    
    return YES;
}
-(BOOL)deleteFromFavoriteList:(NSString *)firstName andGender:(NSString*)gender
{
    //CREATE TABLE "tbl_USER_coupons" ("row_id" VARCHAR, "coupan_id" VARCHAR,"coupan_status" VARCHAR, "coupan_code" VARCHAR, "expiry" VARCHAR,"qr_image" VARCHAR, "is_active" BOOL , "spent_time" INTEGER,"created_at" VARCHAR)
    
    sqlite3_stmt *compiledStatement;
    
    database = db;
    if (!database) {
        sqlite3_open([App_Delegate.dbPath UTF8String], &database);
    }
    
    
    NSString *queryString;
    
    if ([gender isEqualToString:@"zero"])
    {
        queryString=[NSString stringWithFormat:@"Delete from my_favorite where name = \"%@\"",firstName];
    }
    else
    {
        queryString=[NSString stringWithFormat:@"Delete from my_favorite where name = \"%@\" AND gender=\"%@\"",firstName,gender];
    }
    
    
    BOOL success = NO;
    const char *deleteQuery = [queryString UTF8String];
    
    if(sqlite3_prepare_v2(database, deleteQuery, -1, &compiledStatement, NULL) != SQLITE_OK)
    {
        NSLog(@"Error Occured:'%s'",sqlite3_errmsg(database));
    }
    else
    {
        if(sqlite3_step(compiledStatement) == SQLITE_DONE)
        {
            success = YES;
        }
        else
        {
            NSLog(@"%s: step not ok: %s", __FUNCTION__, sqlite3_errmsg(database));
        }
        sqlite3_finalize(compiledStatement);
    }
    NSLog(@"Error Occured:'%s'",sqlite3_errmsg(database));
    return success;
}
-(NSMutableArray *)getAllCountries
{
    sqlite3_stmt *compiledStatement;
    
    database = db;
    if (!database) {
        sqlite3_open([App_Delegate.dbPath UTF8String], &database);
    }
    
    NSMutableArray *arrFav=[[NSMutableArray alloc] init];
    
    //NSString *queryString=[NSString stringWithFormat:@"SELECT * From my_favorite"];
    NSString *queryString=@"SELECT group_concat(lang_origin) as country FROM master_new";
    const char *sqlSelect = [queryString  cStringUsingEncoding:NSUTF8StringEncoding];
    
    if(sqlite3_prepare_v2(database, sqlSelect, -1, &compiledStatement, NULL) != SQLITE_OK)
    {
        NSLog(@"Error Occured:'%s'",sqlite3_errmsg(database));
    }
    else
    {
        // Loop through the results and add them to the feeds array
        while(sqlite3_step(compiledStatement) == SQLITE_ROW)
        {
            NSMutableDictionary *dic=[[NSMutableDictionary alloc]init];
            
            int columIndex=-1;
            NSString *str=sqlite3_column_text(compiledStatement, ++columIndex) != NULL ?[NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement,columIndex)]:@"";
            
            [dic setObject:str forKey:@"country"];
            
            [arrFav addObject:dic];
        }
    }
    sqlite3_finalize(compiledStatement);
    
    return arrFav;
}
-(NSString *)getFamousPeople_whoHaveName:(NSString*)name
{
    sqlite3_stmt *compiledStatement;
    
    database = db;
    if (!database) {
        sqlite3_open([App_Delegate.dbPath UTF8String], &database);
    }
    
    NSMutableArray *arrFav=[[NSMutableArray alloc] init];
    
    //NSString *queryString=[NSString stringWithFormat:@"SELECT celeb FROM famous_people where name like \"%%%@%%\"",name];
    NSString *queryString=[NSString stringWithFormat:@"SELECT celeb FROM famous_people where trim(name)=\"%@\"",name];
    const char *sqlSelect = [queryString  cStringUsingEncoding:NSUTF8StringEncoding];
    
    NSString *strFamousPeople=@"";
    if(sqlite3_prepare_v2(database, sqlSelect, -1, &compiledStatement, NULL) != SQLITE_OK)
    {
        NSLog(@"Error Occured:'%s'",sqlite3_errmsg(database));
    }
    else
    {
        // Loop through the results and add them to the feeds array
        while(sqlite3_step(compiledStatement) == SQLITE_ROW)
        {
            NSMutableDictionary *dic=[[NSMutableDictionary alloc]init];
            
            int columIndex=-1;
            NSString *str=sqlite3_column_text(compiledStatement, ++columIndex) != NULL ?[NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement,columIndex)]:@"";
            
            strFamousPeople=str;
            
            //[arrFav addObject:dic];
        }
    }
    sqlite3_finalize(compiledStatement);
    
    return strFamousPeople;
}
/*
-(void)insertEvent:(Events*)obj
{
    NSString *deleteQuery=[NSString stringWithFormat:@"DELETE FROM \"%@\" WHERE id=\"%@\"",TABLE_EVENTS,obj.strEventID];
    NSError *error=[App_Delegate.dbManager doQuery:deleteQuery];
    
    sqlite3_stmt *compiledStatement;
    //    sqlite3_finalize(compiledStatement);
    //    compiledStatement=nil;
    database = db;
    if (!database) {
        sqlite3_open([App_Delegate.dbPath UTF8String], &database);
    }

    
    NSString *queryString=[NSString stringWithFormat:@"INSERT into \"%@\" (\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\") values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",TABLE_EVENTS,DB_EVENTS_ID,DB_EVENTS_TITLE_EN,DB_EVENTS_TITLE_GR,DB_EVENTS_SUBJECT_EN,DB_EVENTS_SUBJECT_GR,DB_EVENTS_STARTING_DATETIME,DB_EVENTS_ENDING_DATETIME,DB_EVENTS_LANGUAGE,DB_EVENTS_DESCRIPTION_EN,DB_EVENTS_DESCRIPTION_GR,DB_EVENTS_SCHEDULE,DB_EVENTS_WEBSITE,DB_EVENTS_SPECIALTIES_ID,DB_EVENTS_ORGANIZER_ID,DB_EVENTS_ORGANIZER_PERSON_ID,DB_EVENTS_PCO_ID,DB_EVENTS_PCO_PERSON_ID,DB_EVENTS_VENUE_ID,DB_EVENTS_INFORAMTION_SOURCE,DB_EVENTS_KIND_ID__,DB_EVENTS_TYPE_ID__,DB_EVENTS_MASTER_CONFERENCE_ID,DB_EVENTS_KEYWORDS,DB_EVENTS_APPLE_STORE,DB_EVENTS_PLAY_STORE,DB_EVENTS_WINDOWS_STORE,DB_EVENTS_DATE_CREATED,DB_EVENTS_DATE_UPDATED,DB_EVENTS_LAST_UPDATED_BY,DB_EVENTS_HIDE,DB_EVENTS_DELETED_BY,DB_EVENTS_ORGANIZER_NAME_GR,DB_EVENTS_ORGANIZER_NAME_EN,DB_EVENTS_ORGANIZER_WEBSITE,DB_EVENTS_ORGANIZER_EMAIL,DB_EVENTS_IMAGE,DB_EVENTS_PHONENO,DB_EVENTS_EMAIL];
    
    const char *insertSql = [queryString  cStringUsingEncoding:NSUTF8StringEncoding];
    
    if(sqlite3_prepare_v2(database, insertSql, -1, &compiledStatement, NULL) == SQLITE_OK)
    {
        int columIndex=0;
        
        
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strEventID UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strTitleEN UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strTitleGR UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strSubjectEN UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strSubjectGR UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strStartDate UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strEndDate UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strLanguage UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strDescEN UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strDescGR UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strSchedule UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strWebsite UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strSpecialitiesID UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strOrganizerID UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strOrganizerPerson UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strPCOid UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strPCOpersion UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strVenueID UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strInformationSource UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strEventKindID UTF8String],-1,SQLITE_TRANSIENT);
        
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strEventTypeID UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strMasterConferenceID UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strKeywords UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strAppleStore UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strPlayStore UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strWindowsStore UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strDateCreated UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strDateUpdated UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strLastUpdatedBy UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strHide UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strDeletedBy UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strOrganizerNameGR UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strOrganizerNameEN UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strOrganizerWebsite UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strOrganizerEmail UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strEventImage UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strPhoneNo UTF8String],-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(compiledStatement, ++columIndex, [obj.strEmail UTF8String],-1,SQLITE_TRANSIENT);
        
        //sqlite3_bind_double(compiledStatement, ++columIndex, message.ID );
        //sqlite3_bind_text(compiledStatement, ++columIndex, [message.strFriendUserName UTF8String],-1,SQLITE_TRANSIENT);
        //sqlite3_bind_int(compiledStatement, ++columIndex, message.status);
    }
    
    if(sqlite3_step(compiledStatement) != SQLITE_DONE)
    {
        //NSAssert1(0, @"Error while creating insert statement '%s'", sqlite3_errmsg(database));
        //    NSLog(@"Error Occured:'%s'",sqlite3_errmsg(database));
    }
    else
    {
        //    NSLog(@"Row Inserted!!!:");
    }
    
    //if(database) sqlite3_close(database);
}
 */
@end

