//
//  DBFile.m
//  Italic
//
//  Created by FOX-MAC-M on 29/03/14.
//  Copyright (c) 2014 fox. All rights reserved.
//  com.italickeyboard.app

#import "DBFile.h"
#import "AppDelegate.h"

@implementation DBFile
{
    NSMutableArray *arr;
    NSMutableDictionary *dict;

}
-(id)initWith
{
   
    app=(AppDelegate *)[[UIApplication sharedApplication] delegate];
    //formatter=[[NSDateFormatter alloc] init];
    //[formatter setDateFormat:@"ddMMyyyyHHmmssSSS"];

    if(sqlite3_open([app.dbPath UTF8String], &database) == SQLITE_OK)
    {
        NSLog(@"Success");
    }
    else
    {
        NSLog(@"Fail");
    }
    
    return self;
}
#pragma mark - Form1
//insertValuesIn tableForm 1
-(void)insertValuesInTableForm1:(NSString*)reportName formNo:(NSString*)formNo name:(NSString*)name phone:(NSString*)phone email:(NSString*)email jobInvoice:(NSString*)jobInvoice reportOrderedBy:(NSString*)reportOrderedBy address:(NSString*)address date:(NSString*)date arrivalTime:(NSString*)arrivalTime depTime:(NSString*)depTime weather:(NSString*)weather furnishd:(NSString*)furnished tenacy:(NSString*)tenacy personpresent:(NSString*)personpresent image:(NSString*)image;
{
    NSString *query =[NSString stringWithFormat:@"INSERT INTO tableForm1 VALUES (\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\")",reportName,formNo,name,phone,email,jobInvoice,reportOrderedBy,address,date,arrivalTime,depTime,weather,furnished,tenacy,personpresent,image];
    sqlite3_stmt *statement;
    
    if (sqlite3_prepare_v2(database, [query UTF8String], -1, &statement, nil)
        == SQLITE_OK)
    {
         NSLog(@"error: %s", sqlite3_errmsg(database));
         if (sqlite3_step(statement) != SQLITE_DONE)
        {
            NSLog(@"error: %s", sqlite3_errmsg(database));
        }
        else
        {
            NSLog(@"updateContact SUCCESS - executed command %@",query);
            
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Alert!!" message:@"Form saved successfully" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
            [alert show];
        }
        sqlite3_reset(statement);
       //sqlite3_step(statement);
        sqlite3_finalize(statement);
    }
    else
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
    }
}

#pragma mark - Form2
//insertValuesIn tableForm2
-(void)insertValuesInTableForm2:(NSString*)reportName formNo:(NSString*)formNo invoice:(NSString*)invoice client:(NSString*)client phone:(NSString*)phone property:(NSString*)property fee:(NSString*)fee amount:(NSString*)amount abnNo:(NSString*)abnNo paidDate:(NSString*)paidDate
{
    NSString *query =[NSString stringWithFormat:@"INSERT INTO tableForm2 VALUES (\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\")",reportName,formNo,invoice,client,phone,property,fee,amount,abnNo,paidDate];
    sqlite3_stmt *statement;
    
    if (sqlite3_prepare_v2(database, [query UTF8String], -1, &statement, nil)
        == SQLITE_OK)
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
        if (sqlite3_step(statement) != SQLITE_DONE)
        {
            NSLog(@"error: %s", sqlite3_errmsg(database));
        }
        else
        {
            NSLog(@"updateContact SUCCESS - executed command %@",query);
            
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Alert!!" message:@"Form saved successfully" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
            [alert show];
        }
        sqlite3_reset(statement);
        //sqlite3_step(statement);
        sqlite3_finalize(statement);
    }
    else
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
    }
}

#pragma mark - Form3
//insertValuesIn tableForm3
-(void)insertValuesInTableForm3:(NSString*)reportName formNo:(NSString*)formNo roofExterior:(NSString*)roofExterior exterior:(NSString*)exterior walls:(NSString*)walls drainage:(NSString*)drainage outBuilding:(NSString*)outBuilding floorSpace:(NSString*)floorSpace roofSpace:(NSString*)roofSpace interior:(NSString*)interior overall:(NSString*)overall
{
    NSString *query =[NSString stringWithFormat:@"INSERT INTO tableForm3 VALUES (\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\")",reportName,formNo,roofExterior,exterior,walls,drainage,outBuilding,floorSpace,roofSpace,interior,overall];
    sqlite3_stmt *statement;
    
    if (sqlite3_prepare_v2(database, [query UTF8String], -1, &statement, nil)
        == SQLITE_OK)
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
        if (sqlite3_step(statement) != SQLITE_DONE)
        {
            NSLog(@"error: %s", sqlite3_errmsg(database));
        }
        else
        {
            NSLog(@"updateContact SUCCESS - executed command %@",query);
            
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Alert!!" message:@"Form saved successfully" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
            [alert show];
        }
        sqlite3_reset(statement);
        //sqlite3_step(statement);
        sqlite3_finalize(statement);
    }
    else
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
    }
}

#pragma mark - Image Description
//insertValuesIn tableImgDesc
-(void)insertValuesInTableImgDesc:(NSString*)reportName formNo:(NSString*)formNo image:(NSString*)image desc:(NSString*)desc imgId:(NSString*)imgId
{
    NSString *query =[NSString stringWithFormat:@"INSERT INTO tableImgDesc VALUES (\"%@\",\"%@\",\"%@\",\"%@\",\"%@\")",reportName,formNo,image,desc,imgId];
    sqlite3_stmt *statement;
    
    if (sqlite3_prepare_v2(database, [query UTF8String], -1, &statement, nil)
        == SQLITE_OK)
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
        if (sqlite3_step(statement) != SQLITE_DONE)
        {
            NSLog(@"error: %s", sqlite3_errmsg(database));
        }
        else
        {
            NSLog(@"updateContact SUCCESS - executed command %@",query);
            
//            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Alert!!" message:@"Form saved successfully" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
//            [alert show];
        }
        sqlite3_reset(statement);
        //sqlite3_step(statement);
        sqlite3_finalize(statement);
    }
    else
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
    }
}

#pragma mark - Text Description
-(void)insertValuesInTableTextDesc:(NSString*)reportName formNo:(NSString*)formNo title:(NSString*)title desc:(NSString*)desc textId:(NSString*)textId;
{
    NSString *query =[NSString stringWithFormat:@"INSERT INTO tableTextDesc VALUES (\"%@\",\"%@\",\"%@\",\"%@\",\"%@\")",reportName,formNo,title,desc,textId];
    sqlite3_stmt *statement;
    
    if (sqlite3_prepare_v2(database, [query UTF8String], -1, &statement, nil)
        == SQLITE_OK)
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
        if (sqlite3_step(statement) != SQLITE_DONE)
        {
            NSLog(@"error: %s", sqlite3_errmsg(database));
        }
        else
        {
            NSLog(@"updateContact SUCCESS - executed command %@",query);
            
            //            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Alert!!" message:@"Form saved successfully" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
            //            [alert show];
        }
        sqlite3_reset(statement);
        //sqlite3_step(statement);
        sqlite3_finalize(statement);
    }
    else
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
    }
}

#pragma mark - Room Description
//insertValuesIn tableRoomDesc
-(void)insertValuesInTableRoomDesc:(NSString*)reportName formNo:(NSString*)formNo roomName:(NSString*)roomName roomDesc:(NSString*)roomDesc image:(NSString*)image desc:(NSString*)desc roomNo:(NSString*)roomNo
{
    NSString *query =[NSString stringWithFormat:@"INSERT INTO tableRoomDesc VALUES (\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\")",reportName,formNo,roomName,roomDesc,image,desc,roomNo];
    sqlite3_stmt *statement;
    
    if (sqlite3_prepare_v2(database, [query UTF8String], -1, &statement, nil)
        == SQLITE_OK)
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
        if (sqlite3_step(statement) != SQLITE_DONE)
        {
            NSLog(@"error: %s", sqlite3_errmsg(database));
        }
        else
        {
            NSLog(@"updateContact SUCCESS - executed command %@",query);
            
            //            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Alert!!" message:@"Form saved successfully" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
            //            [alert show];
        }
        sqlite3_reset(statement);
        //sqlite3_step(statement);
        sqlite3_finalize(statement);
    }
    else
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
    }
}

-(NSMutableArray*)selectRandomEntryFormTableRoomDesc:(NSString*)queryString
{
    arr = [[NSMutableArray alloc]init];
    dict =[[NSMutableDictionary alloc]init];
    
    // NSString *iscomplete=@"N";
    
    //NSString *queryString=[NSString stringWithFormat:@"SELECT * FROM tableRoomDesc WHERE reportname=\"%@\" AND formno=\"%@\"",reportName,formName];
    const char *sqlSelect = [queryString UTF8String];
    sqlite3_stmt *compiledStatement;
    
    
    if(sqlite3_prepare_v2(database, sqlSelect, -1, &compiledStatement, NULL) != SQLITE_OK)
    {
        
        NSLog(@"Error Occured:'%s'",sqlite3_errmsg(database));
        
    }
    else if(sqlite3_prepare_v2(database, sqlSelect, -1, &compiledStatement, NULL) == SQLITE_OK)
    {
        while(sqlite3_step(compiledStatement) == SQLITE_ROW)
        {
            
            // Init the Data Dictionary
            NSMutableDictionary *_dataDictionary=[[NSMutableDictionary alloc] init];
            
            NSString *str1 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
            NSString *str2 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
            NSString *str3 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 2)];
            NSString *str4 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 3)];
            NSString *str5 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 4)];
            NSString *str6 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 5)];
            NSString *str7 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 6)];
            
            
            
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str1] forKey:@"reportName"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str2] forKey:@"formNo"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str3] forKey:@"roomName"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str4] forKey:@"roomDesc"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str5] forKey:@"imagePath"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str6] forKey:@"imageDesc"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str7] forKey:@"roomNo"];
            
            [arr addObject:_dataDictionary];
        }
    }
    
    return arr;
}

#pragma mark - Form4
//insertValuesIn tableForm4
-(void)insertValuesInTableForm4:(NSString*)reportName formNo:(NSString*)formNo que1:(NSString*)que1 que2:(NSString*)que2 que3:(NSString*)que3 que4:(NSString*)que4 que5:(NSString*)que5 que6:(NSString*)que6 que7:(NSString*)que7 que8:(NSString*)que8 que9:(NSString*)que9
{
    NSString *query =[NSString stringWithFormat:@"INSERT INTO tableForm4 VALUES (\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\")",reportName,formNo,que1,que2,que3,que4,que5,que6,que7,que8,que9];
    sqlite3_stmt *statement;
    
    if (sqlite3_prepare_v2(database, [query UTF8String], -1, &statement, nil)
        == SQLITE_OK)
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
        if (sqlite3_step(statement) != SQLITE_DONE)
        {
            NSLog(@"error: %s", sqlite3_errmsg(database));
        }
        else
        {
            NSLog(@"updateContact SUCCESS - executed command %@",query);
            
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Alert!!" message:@"Form saved successfully" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
            [alert show];
        }
        sqlite3_reset(statement);
        //sqlite3_step(statement);
        sqlite3_finalize(statement);
    }
    else
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
    }
}

#pragma mark - Form5
//insertValuesIn tableForm5
-(void)insertValuesInTableForm5:(NSString*)reportName formNo:(NSString*)formNo description:(NSString*)description frontFace:(NSString*)frontFace topography:(NSString*)topography storeys:(NSString*)storeys floorType:(NSString*)floorType wallType:(NSString*)wallType roofType:(NSString*)roofType roofCovering:(NSString*)roofCovering interiorLining:(NSString*)interiorLining noOfBalconies:(NSString*)noOfBalconies location:(NSString*)location
{
    NSString *query =[NSString stringWithFormat:@"INSERT INTO tableForm5 VALUES (\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\")",reportName,formNo,description,frontFace,topography,storeys,floorType,wallType,roofType,roofCovering,interiorLining,noOfBalconies,location];
    sqlite3_stmt *statement;
    
    if (sqlite3_prepare_v2(database, [query UTF8String], -1, &statement, nil)
        == SQLITE_OK)
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
        if (sqlite3_step(statement) != SQLITE_DONE)
        {
            NSLog(@"error: %s", sqlite3_errmsg(database));
        }
        else
        {
            NSLog(@"updateContact SUCCESS - executed command %@",query);
            
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Alert!!" message:@"Form saved successfully" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
            [alert show];
        }
        sqlite3_reset(statement);
        //sqlite3_step(statement);
        sqlite3_finalize(statement);
    }
    else
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
    }
}

#pragma mark - Form6
//insertValuesIn tableForm6
-(void)insertValuesInTableForm6:(NSString*)reportName formNo:(NSString*)formNo pool:(NSString*)pool cpr:(NSString*)cpr fence:(NSString*)fence fenceNote:(NSString*)fenceNote imgPath1:(NSString*)imgPath1 imgPath2:(NSString*)imgPath2 imgPath3:(NSString*)imgPath3 imgNote1:(NSString*)imgNote1 imgNote2:(NSString*)imgNote2 imgNote3:(NSString*)imgNote3 shed:(NSString*)shed shedcmt:(NSString*)shedcmt garage:(NSString*)garage garagecmt:(NSString*)garagecmt carport:(NSString*)carport carportcmt:(NSString*)carportcmt pergola:(NSString*)pergola pergolacmt:(NSString*)pergolacmt decking:(NSString*)decking deckingcmt:(NSString*)deckingcmt outbuilding:(NSString*)outbuilding outbuildingcmt:(NSString*)outbuildingcmt flat:(NSString*)flat flatcmt:(NSString*)flatcmt
{
    NSString *query =[NSString stringWithFormat:@"INSERT INTO tableForm6 VALUES (\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\")",reportName,formNo,pool,cpr,fence,fenceNote,imgPath1,imgPath2,imgPath3,imgNote1,imgNote2,imgNote3,shed,shedcmt,garage,garagecmt,carport,carportcmt,pergola,pergolacmt,decking,deckingcmt,outbuilding,outbuildingcmt,flat,flatcmt];
    sqlite3_stmt *statement;
    
    if (sqlite3_prepare_v2(database, [query UTF8String], -1, &statement, nil)
        == SQLITE_OK)
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
        if (sqlite3_step(statement) != SQLITE_DONE)
        {
            NSLog(@"error: %s", sqlite3_errmsg(database));
        }
        else
        {
            NSLog(@"updateContact SUCCESS - executed command %@",query);
            
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Alert!!" message:@"Form saved successfully" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
            [alert show];
        }
        sqlite3_reset(statement);
        //sqlite3_step(statement);
        sqlite3_finalize(statement);
    }
    else
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
    }
}

#pragma mark - Form7
//insertValuesIn tableForm7
-(void)insertValuesInTableForm7:(NSString*)reportName formNo:(NSString*)formNo params:(NSMutableDictionary*)dicParams
{
    NSString *query =[NSString stringWithFormat:@"INSERT INTO tableForm7 VALUES (\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\")",reportName,formNo,
                      [dicParams objectForKey:@"q1"],
                      [dicParams objectForKey:@"501"],
                      [dicParams objectForKey:@"q2"],
                      [dicParams objectForKey:@"502"],
                      [dicParams objectForKey:@"q3"],
                      [dicParams objectForKey:@"503"],
                      [dicParams objectForKey:@"q4"],
                      [dicParams objectForKey:@"504"],
                      [dicParams objectForKey:@"q5"],
                      [dicParams objectForKey:@"505"],
                      [dicParams objectForKey:@"q6"],
                      [dicParams objectForKey:@"506"],
                      [dicParams objectForKey:@"q7"],
                      [dicParams objectForKey:@"507"],
                      [dicParams objectForKey:@"q8"],
                      [dicParams objectForKey:@"508"],
                      [dicParams objectForKey:@"q9"],
                      [dicParams objectForKey:@"509"],
                      [dicParams objectForKey:@"q10"],
                      [dicParams objectForKey:@"510"],
                      [dicParams objectForKey:@"q11"],
                      [dicParams objectForKey:@"511"]];
    sqlite3_stmt *statement;
    
    if (sqlite3_prepare_v2(database, [query UTF8String], -1, &statement, nil)
        == SQLITE_OK)
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
        if (sqlite3_step(statement) != SQLITE_DONE)
        {
            NSLog(@"error: %s", sqlite3_errmsg(database));
        }
        else
        {
            NSLog(@"updateContact SUCCESS - executed command %@",query);
            
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Alert!!" message:@"Form saved successfully" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
            [alert show];
        }
        sqlite3_reset(statement);
        //sqlite3_step(statement);
        sqlite3_finalize(statement);
    }
    else
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
    }
}

#pragma mark - Form8
//insertValuesIn tableForm7
-(void)insertValuesInTableForm8:(NSString*)reportName formNo:(NSString*)formNo cracking:(NSString*)cracking engineer:(NSString*)engineer
{
    NSString *query =[NSString stringWithFormat:@"INSERT INTO tableForm8 VALUES (\"%@\",\"%@\",\"%@\",\"%@\")",reportName,formNo,cracking,engineer];
    sqlite3_stmt *statement;
    
    if (sqlite3_prepare_v2(database, [query UTF8String], -1, &statement, nil)
        == SQLITE_OK)
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
        if (sqlite3_step(statement) != SQLITE_DONE)
        {
            NSLog(@"error: %s", sqlite3_errmsg(database));
        }
        else
        {
            NSLog(@"updateContact SUCCESS - executed command %@",query);
            
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Alert!!" message:@"Form saved successfully" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
            [alert show];
        }
        sqlite3_reset(statement);
        //sqlite3_step(statement);
        sqlite3_finalize(statement);
    }
    else
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
    }
}

#pragma mark - Form9
-(void)insertValuesInTableForm9:(NSString*)reportName formNo:(NSString*)formNo param:(NSMutableDictionary*)dicParam
{
    
        NSString *query =[NSString stringWithFormat:@"INSERT INTO tableForm9 VALUES (\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\")",reportName,formNo,
                          [dicParam objectForKey:@"0"],
                          [dicParam objectForKey:@"imgPath1"],
                          [dicParam objectForKey:@"1"],
                          [dicParam objectForKey:@"2"],
                          [dicParam objectForKey:@"3"],
                          [dicParam objectForKey:@"4"],
                          [dicParam objectForKey:@"5"],
                          [dicParam objectForKey:@"6"],
                          [dicParam objectForKey:@"7"],
                          [dicParam objectForKey:@"8"],
                          [dicParam objectForKey:@"9"],
                          [dicParam objectForKey:@"10"],
                          [dicParam objectForKey:@"11"],
                          [dicParam objectForKey:@"12"],
                          [dicParam objectForKey:@"13"],
                          [dicParam objectForKey:@"14"],
                          [dicParam objectForKey:@"imgPath15"],
                          [dicParam objectForKey:@"15"],
                          [dicParam objectForKey:@"16"],
                          [dicParam objectForKey:@"17"],
                          [dicParam objectForKey:@"18"],
                          [dicParam objectForKey:@"19"],
                          [dicParam objectForKey:@"imgPath20"],
                          [dicParam objectForKey:@"20"],
                          [dicParam objectForKey:@"21"],
                          [dicParam objectForKey:@"22"],
                          [dicParam objectForKey:@"23"]];
        sqlite3_stmt *statement;
        
        if (sqlite3_prepare_v2(database, [query UTF8String], -1, &statement, nil)
            == SQLITE_OK)
        {
            NSLog(@"error: %s", sqlite3_errmsg(database));
            if (sqlite3_step(statement) != SQLITE_DONE)
            {
                NSLog(@"error: %s", sqlite3_errmsg(database));
            }
            else
            {
                NSLog(@"updateContact SUCCESS - executed command %@",query);
                
                UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Alert!!" message:@"Form saved successfully" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
                [alert show];
            }
            sqlite3_reset(statement);
            //sqlite3_step(statement);
            sqlite3_finalize(statement);
        }
        else
        {
            NSLog(@"error: %s", sqlite3_errmsg(database));
        }
    
}

#pragma mark - Form10
//insertValuesIn tableForm10
-(void)insertValuesInTableForm10:(NSString*)reportName formNo:(NSString*)formNo imgPath1:(NSString*)imgPath1 imgDesc1:(NSString*)imgDesc1 imgPath2:(NSString*)imgPath2 imgDesc2:(NSString*)imgDesc2 imgPath3:(NSString*)imgPath3 imgDesc3:(NSString*)imgDesc3 imgPath4:(NSString*)imgPath4 imgDesc4:(NSString*)imgDesc4 imgPath5:(NSString*)imgPath5 imgDesc5:(NSString*)imgDesc5 imgPath6:(NSString*)imgPath6 imgDesc6:(NSString*)imgDesc6 que1:(NSString*)que1 cmt1:(NSString*)cmt1 que2:(NSString*)que2 cmt2:(NSString*)cmt2 que3:(NSString*)que3 cmt3:(NSString*)cmt3 que4:(NSString*)que4 cmt4:(NSString*)cmt4 que5:(NSString*)que5 cmt5:(NSString*)cmt5 que6:(NSString*)que6 cmt6:(NSString*)cmt6 que7:(NSString*)que7 cmt7:(NSString*)cmt7 que8:(NSString*)que8 cmt8:(NSString*)cmt8 que9:(NSString*)que9 cmt9:(NSString*)cmt9 que10:(NSString*)que10 cmt10:(NSString*)cmt10 que11:(NSString*)que11 cmt11:(NSString*)cmt11 que12:(NSString*)que12 cmt12:(NSString*)cmt12 que13:(NSString*)que13 cmt13:(NSString*)cmt13 que14:(NSString*)que14 cmt14:(NSString*)cmt14 que15:(NSString*)que15 cmt15:(NSString*)cmt15 que16:(NSString*)que16 cmt16:(NSString*)cmt16 que17:(NSString*)que17 cmt17:(NSString*)cmt17 que18:(NSString*)que18 cmt18:(NSString*)cmt18 que19:(NSString*)que19 cmt19:(NSString*)cmt19
{
    NSString *query =[NSString stringWithFormat:@"INSERT INTO tableForm10 VALUES (\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\")",reportName,formNo,imgPath1,imgDesc1,imgPath2,imgDesc2,imgPath3,imgDesc3,imgPath4,imgDesc4,imgPath5,imgDesc5,imgPath6,imgDesc6,que1,cmt1,que2,cmt2,que3,cmt3,que4,cmt4,que5,cmt5,que6,cmt6,que7,cmt7,que8,cmt8,que9,cmt9,que10,cmt10,que11,cmt11,que12,cmt12,que13,cmt13,que14,cmt14,que15,cmt15,que16,cmt16,que17,cmt17,que18,cmt18,que19,cmt19];
    sqlite3_stmt *statement;
    
    if (sqlite3_prepare_v2(database, [query UTF8String], -1, &statement, nil)
        == SQLITE_OK)
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
        if (sqlite3_step(statement) != SQLITE_DONE)
        {
            NSLog(@"error: %s", sqlite3_errmsg(database));
        }
        else
        {
            NSLog(@"updateContact SUCCESS - executed command %@",query);
            
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Alert!!" message:@"Form saved successfully" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
            [alert show];
        }
        sqlite3_reset(statement);
        //sqlite3_step(statement);
        sqlite3_finalize(statement);
    }
    else
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
    }
}

#pragma mark - Form11
-(void)insertValuesInTableForm11:(NSString*)reportName formNo:(NSString*)formNo que0:(NSString*)que0 desc0:(NSString*)desc0 que1:(NSString*)que1 desc1:(NSString*)desc1 que2:(NSString*)que2 desc2:(NSString*)desc2 que3:(NSString*)que3 desc3:(NSString*)desc3 que4:(NSString*)que4 desc4:(NSString*)desc4 que5:(NSString*)que5 desc5:(NSString*)desc5 que6:(NSString*)que6 desc6:(NSString*)desc6 que7:(NSString*)que7 desc7:(NSString*)desc7
{
    NSString *query =[NSString stringWithFormat:@"INSERT INTO tableForm11 VALUES (\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\")",reportName,formNo,que0,desc0,que1,desc1,que2,desc2,que3,desc3,que4,desc4,que5,desc5,que6,desc6,que7,desc7];
    sqlite3_stmt *statement;
    
    if (sqlite3_prepare_v2(database, [query UTF8String], -1, &statement, nil)
        == SQLITE_OK)
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
        if (sqlite3_step(statement) != SQLITE_DONE)
        {
            NSLog(@"error: %s", sqlite3_errmsg(database));
        }
        else
        {
            NSLog(@"updateContact SUCCESS - executed command %@",query);
            
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Alert!!" message:@"Form saved successfully" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
            [alert show];
        }
        sqlite3_reset(statement);
        //sqlite3_step(statement);
        sqlite3_finalize(statement);
    }
    else
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
    }
}

#pragma mark - Form12
-(void)insertValuesInTableForm12:(NSString*)reportName formNo:(NSString*)formNo que0:(NSString*)que0 desc0:(NSString*)desc0 que1:(NSString*)que1 desc1:(NSString*)desc1 que2:(NSString*)que2 desc2:(NSString*)desc2 que3:(NSString*)que3 desc3:(NSString*)desc3 que4:(NSString*)que4 desc4:(NSString*)desc4 que5:(NSString*)que5 desc5:(NSString*)desc5 que6:(NSString*)que6 desc6:(NSString*)desc6 que7:(NSString*)que7 desc7:(NSString*)desc7 que8:(NSString*)que8 desc8:(NSString*)desc8 que9:(NSString*)que9 desc9:(NSString*)desc9 que10:(NSString*)que10 desc10:(NSString*)desc10 que11:(NSString*)que11 desc11:(NSString*)desc11 que12:(NSString*)que12 desc12:(NSString*)desc12 que13:(NSString*)que13 desc13:(NSString*)desc13
{
    NSString *query =[NSString stringWithFormat:@"INSERT INTO tableForm12 VALUES (\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\")",reportName,formNo,que0,desc0,que1,desc1,que2,desc2,que3,desc3,que4,desc4,que5,desc5,que6,desc6,que7,desc7,que8,desc8,que9,desc9,que10,desc10,que11,desc11,que12,desc12,que13,desc13];
    sqlite3_stmt *statement;
    
    if (sqlite3_prepare_v2(database, [query UTF8String], -1, &statement, nil)
        == SQLITE_OK)
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
        if (sqlite3_step(statement) != SQLITE_DONE)
        {
            NSLog(@"error: %s", sqlite3_errmsg(database));
        }
        else
        {
            NSLog(@"updateContact SUCCESS - executed command %@",query);
            
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Alert!!" message:@"Form saved successfully" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
            [alert show];
        }
        sqlite3_reset(statement);
        //sqlite3_step(statement);
        sqlite3_finalize(statement);
    }
    else
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
    }
}

#pragma mark - Form13
-(void)insertValuesInTableForm13:(NSString*)reportName formNo:(NSString*)formNo que0:(NSString*)que0 desc0:(NSString*)desc0 que1:(NSString*)que1 desc1:(NSString*)desc1 que2:(NSString*)que2 desc2:(NSString*)desc2 que3:(NSString*)que3 desc3:(NSString*)desc3 que4:(NSString*)que4 desc4:(NSString*)desc4 que5:(NSString*)que5 desc5:(NSString*)desc5 que6:(NSString*)que6 desc6:(NSString*)desc6 que7:(NSString*)que7 desc7:(NSString*)desc7 que8:(NSString*)que8 desc8:(NSString*)desc8 que9:(NSString*)que9 desc9:(NSString*)desc9 que10:(NSString*)que10 desc10:(NSString*)desc10 que11:(NSString*)que11 desc11:(NSString*)desc11 que12:(NSString*)que12 desc12:(NSString*)desc12 que13:(NSString*)que13 desc13:(NSString*)desc13 que14:(NSString*)que14 desc14:(NSString*)desc14 que15:(NSString*)que15 desc15:(NSString*)desc15
{
    NSString *query =[NSString stringWithFormat:@"INSERT INTO tableForm13 VALUES (\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\")",reportName,formNo,que0,desc0,que1,desc1,que2,desc2,que3,desc3,que4,desc4,que5,desc5,que6,desc6,que7,desc7,que8,desc8,que9,desc9,que10,desc10,que11,desc11,que12,desc12,que13,desc13,que14,desc14,que15,desc15];
    sqlite3_stmt *statement;
    
    if (sqlite3_prepare_v2(database, [query UTF8String], -1, &statement, nil)
        == SQLITE_OK)
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
        if (sqlite3_step(statement) != SQLITE_DONE)
        {
            NSLog(@"error: %s", sqlite3_errmsg(database));
        }
        else
        {
            NSLog(@"updateContact SUCCESS - executed command %@",query);
            
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Alert!!" message:@"Form saved successfully" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
            [alert show];
        }
        sqlite3_reset(statement);
        //sqlite3_step(statement);
        sqlite3_finalize(statement);
    }
    else
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
    }
}

#pragma mark - Form14
-(void)insertValuesInTableForm14:(NSString*)reportName formNo:(NSString*)formNo que0:(NSString*)que0 desc0:(NSString*)desc0 que1:(NSString*)que1 desc1:(NSString*)desc1 que2:(NSString*)que2 desc2:(NSString*)desc2 que3:(NSString*)que3 desc3:(NSString*)desc3 que4:(NSString*)que4 desc4:(NSString*)desc4 que5:(NSString*)que5 desc5:(NSString*)desc5 que6:(NSString*)que6 desc6:(NSString*)desc6 que7:(NSString*)que7 desc7:(NSString*)desc7 que8:(NSString*)que8 desc8:(NSString*)desc8 que9:(NSString*)que9 desc9:(NSString*)desc9 que10:(NSString*)que10 desc10:(NSString*)desc10 que11:(NSString*)que11 desc11:(NSString*)desc11 que12:(NSString*)que12 desc12:(NSString*)desc12 que13:(NSString*)que13 desc13:(NSString*)desc13 que14:(NSString*)que14 desc14:(NSString*)desc14 que15:(NSString*)que15 desc15:(NSString*)desc15 que16:(NSString*)que16 desc16:(NSString*)desc16 que17:(NSString*)que17 desc17:(NSString*)desc17 que18:(NSString*)que18 desc18:(NSString*)desc18 que19:(NSString*)que19 desc19:(NSString*)desc19
{
    NSString *query =[NSString stringWithFormat:@"INSERT INTO tableForm14 VALUES (\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\")",reportName,formNo,que0,desc0,que1,desc1,que2,desc2,que3,desc3,que4,desc4,que5,desc5,que6,desc6,que7,desc7,que8,desc8,que9,desc9,que10,desc10,que11,desc11,que12,desc12,que13,desc13,que14,desc14,que15,desc15,que16,desc16,que17,desc17,que18,desc18,que19,desc19];
    sqlite3_stmt *statement;
    
    if (sqlite3_prepare_v2(database, [query UTF8String], -1, &statement, nil)
        == SQLITE_OK)
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
        if (sqlite3_step(statement) != SQLITE_DONE)
        {
            NSLog(@"error: %s", sqlite3_errmsg(database));
        }
        else
        {
            NSLog(@"updateContact SUCCESS - executed command %@",query);
            
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Alert!!" message:@"Form saved successfully" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
            [alert show];
        }
        sqlite3_reset(statement);
        //sqlite3_step(statement);
        sqlite3_finalize(statement);
    }
    else
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
    }
}

#pragma mark - Form16
-(void)insertValuesInTableForm16:(NSString*)reportName formNo:(NSString*)formNo que0:(NSString*)que0 que1:(NSString*)que1 que2:(NSString*)que2 que3:(NSString*)que3 que4:(NSString*)que4 que5:(NSString*)que5 que6:(NSString*)que6 que7:(NSString*)que7 que8:(NSString*)que8 que9:(NSString*)que9 que10:(NSString*)que10 que11:(NSString*)que11 que12:(NSString*)que12 que13:(NSString*)que13 que14:(NSString*)que14 que15:(NSString*)que15 que16:(NSString*)que16  que17:(NSString*)que17 que18:(NSString*)que18 que19:(NSString*)que19 que20:(NSString*)que20 que21:(NSString*)que21 que22:(NSString*)que22 que23:(NSString*)que23 que24:(NSString*)que24 que25:(NSString*)que25 que26:(NSString*)que26 que27:(NSString*)que27
{
    NSString *query =[NSString stringWithFormat:@"INSERT INTO tableForm16 VALUES (\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\")",reportName,formNo,que0,que1,que2,que3,que4,que5,que6,que7,que8,que9,que10,que11,que12,que13,que14,que15,que16,que17,que18,que19,que20,que21,que22,que23,que24,que25,que26,que27];
    sqlite3_stmt *statement;
    
    if (sqlite3_prepare_v2(database, [query UTF8String], -1, &statement, nil)
        == SQLITE_OK)
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
        if (sqlite3_step(statement) != SQLITE_DONE)
        {
            NSLog(@"error: %s", sqlite3_errmsg(database));
        }
        else
        {
            NSLog(@"updateContact SUCCESS - executed command %@",query);
            
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Alert!!" message:@"Form saved successfully" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
            [alert show];
        }
        sqlite3_reset(statement);
        //sqlite3_step(statement);
        sqlite3_finalize(statement);
    }
    else
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
    }
}

#pragma mark - tableSignature
-(void)insertValuesInTableSignatre:(NSString*)reportName imagePath:(NSString*)imagePath sign:(NSString*)sign date:(NSString*)date
{
    NSString *query =[NSString stringWithFormat:@"INSERT INTO tableSignature VALUES (\"%@\",\"%@\",\"%@\",\"%@\")",reportName,imagePath,sign,date];
    sqlite3_stmt *statement;
    
    if (sqlite3_prepare_v2(database, [query UTF8String], -1, &statement, nil)
        == SQLITE_OK)
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
        if (sqlite3_step(statement) != SQLITE_DONE)
        {
            NSLog(@"error: %s", sqlite3_errmsg(database));
        }
        else
        {
            NSLog(@"updateContact SUCCESS - executed command %@",query);
            
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Alert!!" message:@"Form saved successfully" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
            [alert show];
        }
        sqlite3_reset(statement);
        //sqlite3_step(statement);
        sqlite3_finalize(statement);
    }
    else
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
    }
}

//insertValuesInTable 2
-(void)insertValuesInTableItem:(NSString*)pdfname item:(NSString*)item date1:(NSString*)date1 date2:(NSString*)date2 date3:(NSString*)date3 date4:(NSString*)date4 temp1:(NSString*)temp1 temp2:(NSString*)temp2 temp3:(NSString*)temp3 temp4:(NSString*)temp4 mc1:(NSString*)mc1 mc2:(NSString*)mc2 mc3:(NSString*)mc3 mc4:(NSString*)mc4 viewId:(NSString*)viewId description:(NSString*)description
{
    NSString *query =[NSString stringWithFormat:@"INSERT INTO pdf1_item VALUES (\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\")",pdfname,item,date1,date2,date3,date4,temp1,temp2,temp3,temp4,mc1,mc2,mc3,mc4,viewId,description];
    sqlite3_stmt *statement;
    
    if (sqlite3_prepare_v2(database, [query UTF8String], -1, &statement, nil)
        == SQLITE_OK)
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
        if (sqlite3_step(statement) != SQLITE_DONE)
        {
            NSLog(@"error: %s", sqlite3_errmsg(database));
        }
        else
        {
           NSLog(@"updateContact SUCCESS - executed command %@",query);
        }
        sqlite3_reset(statement);
        //sqlite3_step(statement);
        sqlite3_finalize(statement);
    }
    else
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
    }
}




//selectRandomEntryFormDB 1
-(NSMutableArray*)selectRandomEntryFormTableHeader:(NSString*)pdfName
{
    arr = [[NSMutableArray alloc]init];
    dict =[[NSMutableDictionary alloc]init];
    
   // NSString *iscomplete=@"N";
    
    NSString *queryString=[NSString stringWithFormat:@"SELECT pdfname,title,claim,customer,dw,w,spw,ins,pw,cp FROM pdf1_header WHERE pdfname=\"%@\"",pdfName];
    const char *sqlSelect = [queryString UTF8String];
    sqlite3_stmt *compiledStatement;
    
    
    if(sqlite3_prepare_v2(database, sqlSelect, -1, &compiledStatement, NULL) != SQLITE_OK)
    {
        
        NSLog(@"Error Occured:'%s'",sqlite3_errmsg(database));
        
    }
    else if(sqlite3_prepare_v2(database, sqlSelect, -1, &compiledStatement, NULL) == SQLITE_OK)
    {
        while(sqlite3_step(compiledStatement) == SQLITE_ROW)
        {
            
            // Init the Data Dictionary
            NSMutableDictionary *_dataDictionary=[[NSMutableDictionary alloc] init];
            
            NSString *str1 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
            NSString *str2 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
            NSString *str3 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 2)];
            NSString *str4 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 3)];
            NSString *str5 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 4)];
            NSString *str6 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 5)];
            NSString *str7 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 6)];
            NSString *str8 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 7)];
            NSString *str9 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 8)];
            NSString *str10 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 9)];
            
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str1] forKey:@"pdfname"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str2] forKey:@"title"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str3] forKey:@"claim"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str4] forKey:@"customer"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str5] forKey:@"dw"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str6] forKey:@"w"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str7] forKey:@"spw"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str8] forKey:@"ins"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str9] forKey:@"pw"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str10] forKey:@"cp"];
            
            [arr addObject:_dataDictionary];
          }
    }
 
    return arr;
}

//selectRandomEntryFormDB 2
-(NSMutableArray*)selectRandomEntryFormTableItem:(NSString*)pdfName withViewId:(NSString*)viewId
{
    arr = [[NSMutableArray alloc]init];
    dict =[[NSMutableDictionary alloc]init];
    
    // NSString *iscomplete=@"N";
    
    NSString *queryString=[NSString stringWithFormat:@"SELECT pdfname,item,date1,date2,date3,date4,temp1,temp2,temp3,temp4,mc1,mc2,mc3,mc4,viewId,description FROM pdf1_item WHERE pdfname=\"%@\" AND viewid=\"%@\"",pdfName,viewId];
    const char *sqlSelect = [queryString UTF8String];
    sqlite3_stmt *compiledStatement;
    
    
    if(sqlite3_prepare_v2(database, sqlSelect, -1, &compiledStatement, NULL) != SQLITE_OK)
    {
        
        NSLog(@"Error Occured:'%s'",sqlite3_errmsg(database));
        
    }
    else if(sqlite3_prepare_v2(database, sqlSelect, -1, &compiledStatement, NULL) == SQLITE_OK)
    {
        while(sqlite3_step(compiledStatement) == SQLITE_ROW)
        {
            
            // Init the Data Dictionary
            NSMutableDictionary *_dataDictionary=[[NSMutableDictionary alloc] init];
            
            NSString *str1 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
            NSString *str2 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
            NSString *str3 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 2)];
            NSString *str4 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 3)];
            NSString *str5 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 4)];
            NSString *str6 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 5)];
            NSString *str7 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 6)];
            NSString *str8 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 7)];
            NSString *str9 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 8)];
            NSString *str10 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 9)];
            NSString *str11 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 10)];
            NSString *str12 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 11)];
            NSString *str13 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 12)];
            NSString *str14 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 13)];
            NSString *str15 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 14)];
            NSString *str16 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 15)];
            
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str1] forKey:@"pdfname"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str2] forKey:@"item"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str3] forKey:@"date1"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str4] forKey:@"date2"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str5] forKey:@"date3"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str6] forKey:@"date4"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str7] forKey:@"temp1"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str8] forKey:@"temp2"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str9] forKey:@"temp3"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str10] forKey:@"temp4"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str11] forKey:@"mc1"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str12] forKey:@"mc2"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str13] forKey:@"mc3"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str14] forKey:@"mc4"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str15] forKey:@"viewid"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str16] forKey:@"description"];
            
            [arr addObject:_dataDictionary];
        }
    }
    
    return arr;
}

#pragma mark //------------pdf 2 methods------------
//insertValuesInTableRowCount 1
-(void)insertValuesInTableRowCount:(NSString*)pdfName rowCount1:(int)rowCount1 rowCount2:(int)rowCount2
{
    NSString *query =[NSString stringWithFormat:@"INSERT INTO pdf2_numberofrows VALUES (\"%@\",\"%d\",\"%d\")",pdfName,rowCount1,rowCount2];
    sqlite3_stmt *statement;
    
    if (sqlite3_prepare_v2(database, [query UTF8String], -1, &statement, nil)
        == SQLITE_OK)
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
        if (sqlite3_step(statement) != SQLITE_DONE)
        {
            NSLog(@"error: %s", sqlite3_errmsg(database));
        }
        else
        {
            NSLog(@"updateContact SUCCESS - executed command %@",query);
        }
        sqlite3_reset(statement);
        //sqlite3_step(statement);
        sqlite3_finalize(statement);
    }
    else
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
    }
}


//insertValuesInTableHeader 1
-(void)insertValuesInTableHeader1:(NSString*)pdfName title:(NSString*)title invoice:(NSString*)invoice name:(NSString*)name address:(NSString*)address city:(NSString*)city phone:(NSString*)phone area:(NSString*)area datetime:(NSString*)datetime category:(NSString*)category class:(NSString*)class superviser:(NSString*)superviser
{
    NSString *query =[NSString stringWithFormat:@"INSERT INTO pdf2_header VALUES (\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\")",pdfName,title,invoice,name,address,city,phone,area,datetime,category,class,superviser];
    sqlite3_stmt *statement;
    
    if (sqlite3_prepare_v2(database, [query UTF8String], -1, &statement, nil)
        == SQLITE_OK)
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
        if (sqlite3_step(statement) != SQLITE_DONE)
        {
            NSLog(@"error: %s", sqlite3_errmsg(database));
        }
        else
        {
            NSLog(@"updateContact SUCCESS - executed command %@",query);
        }
        sqlite3_reset(statement);
        //sqlite3_step(statement);
        sqlite3_finalize(statement);
    }
    else
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
    }
}

//insertValuesInTableHeader 2
-(void)insertValuesInTableHeadre2:(NSString*)pdfName titleatmos:(NSString*)titleAtmos inspection1:(NSString*)inspection1 inspection2:(NSString*)inspection2 inspection3:(NSString*)inspection3 inspection4:(NSString*)inspection4 inspection5:(NSString*)inspection5 titleEquipment:(NSString*)titleEquipment cfm1:(NSString*)cfm1 cfm2:(NSString*)cfm2 cfm3:(NSString*)cfm3 cfm4:(NSString*)cfm4 cfm5:(NSString*)cfm5 inspection11:(NSString*)inspection11 inspection22:(NSString*)inspection22 inspection33:(NSString*)inspection33 inspection44:(NSString*)inspection44 inspection55:(NSString*)inspection55
{
    NSString *query =[NSString stringWithFormat:@"INSERT INTO pdf2_header2 VALUES (\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\")",pdfName,titleAtmos,inspection1,inspection2,inspection3,inspection4,inspection5,titleEquipment,cfm1,cfm2,cfm3,cfm4,cfm5,inspection11,inspection22,inspection33,inspection44,inspection55];
    sqlite3_stmt *statement;
    
    if (sqlite3_prepare_v2(database, [query UTF8String], -1, &statement, nil)
        == SQLITE_OK)
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
        if (sqlite3_step(statement) != SQLITE_DONE)
        {
            NSLog(@"error: %s", sqlite3_errmsg(database));
        }
        else
        {
            NSLog(@"updateContact SUCCESS - executed command %@",query);
        }
        sqlite3_reset(statement);
        //sqlite3_step(statement);
        sqlite3_finalize(statement);
    }
    else
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
    }
}
//insertValuesInTableRow
-(void)insertValuesInTableRow:(NSString*)pdfname viewId:(NSString*)viewId rowNumber:(int)rowNumber dateTime:(NSString*)dateTime temp1:(NSString*)temp1 rh1:(NSString*)rh1 gpp1:(NSString*)gpp1 temp2:(NSString*)temp2 rh2:(NSString*)rh2 gpp2:(NSString*)gpp2 temp3:(NSString*)temp3 rh3:(NSString*)rh3 gpp3:(NSString*)gpp3 temp4:(NSString*)temp4 rh4:(NSString*)rh4 gpp4:(NSString*)gpp4 temp5:(NSString*)temp5 rh5:(NSString*)rh5 gpp5:(NSString*)gpp5
{
    NSString *query =[NSString stringWithFormat:@"INSERT INTO pdf2_row VALUES (\"%@\",\"%@\",\"%d\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\")",pdfname,viewId,rowNumber,dateTime,temp1,rh1,gpp1,temp2,rh2,gpp2,temp3,rh3,gpp3,temp4,rh4,gpp4,temp5,rh5,gpp5];
    sqlite3_stmt *statement;
    
    if (sqlite3_prepare_v2(database, [query UTF8String], -1, &statement, nil)
        == SQLITE_OK)
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
        if (sqlite3_step(statement) != SQLITE_DONE)
        {
            NSLog(@"error: %s", sqlite3_errmsg(database));
        }
        else
        {
            NSLog(@"updateContact SUCCESS - executed command %@",query);
        }
        sqlite3_reset(statement);
        //sqlite3_step(statement);
        sqlite3_finalize(statement);
    }
    else
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
    }
}
//selectRandomEntryFormTableNumberOfRows
-(NSMutableArray*)selectRandomEntryFormTableRowCount:(NSString*)pdfName
{
    arr = [[NSMutableArray alloc]init];
    dict =[[NSMutableDictionary alloc]init];
    
    // NSString *iscomplete=@"N";
    
    NSString *queryString=[NSString stringWithFormat:@"SELECT pdfname,rowcount1,rowcount2 FROM pdf2_numberofrows WHERE pdfname=\"%@\"",pdfName];
    const char *sqlSelect = [queryString UTF8String];
    sqlite3_stmt *compiledStatement;
    
    
    if(sqlite3_prepare_v2(database, sqlSelect, -1, &compiledStatement, NULL) != SQLITE_OK)
    {
        
        NSLog(@"Error Occured:'%s'",sqlite3_errmsg(database));
        
    }
    else if(sqlite3_prepare_v2(database, sqlSelect, -1, &compiledStatement, NULL) == SQLITE_OK)
    {
        while(sqlite3_step(compiledStatement) == SQLITE_ROW)
        {
            
            // Init the Data Dictionary
            NSMutableDictionary *_dataDictionary=[[NSMutableDictionary alloc] init];
            
            NSString *str1 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
            NSString *str2 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
            NSString *str3 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 2)];
           
            
            
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str1] forKey:@"pdfname"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str2] forKey:@"rowcount1"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str3] forKey:@"rowcount2"];
            
            
            [arr addObject:_dataDictionary];
        }
    }
    
    return arr;
}

//selectRandomEntryFormDB 1
-(NSMutableArray*)selectRandomEntryFormTableHeader1:(NSString*)pdfName
{
    arr = [[NSMutableArray alloc]init];
    dict =[[NSMutableDictionary alloc]init];
    
    // NSString *iscomplete=@"N";
    
    NSString *queryString=[NSString stringWithFormat:@"SELECT pdfname,title,invoice,name,address,city,phone,area,datetime,category,class,superviser FROM pdf2_header WHERE pdfname=\"%@\"",pdfName];
    const char *sqlSelect = [queryString UTF8String];
    sqlite3_stmt *compiledStatement;
    
    
    if(sqlite3_prepare_v2(database, sqlSelect, -1, &compiledStatement, NULL) != SQLITE_OK)
    {
        
        NSLog(@"Error Occured:'%s'",sqlite3_errmsg(database));
        
    }
    else if(sqlite3_prepare_v2(database, sqlSelect, -1, &compiledStatement, NULL) == SQLITE_OK)
    {
        while(sqlite3_step(compiledStatement) == SQLITE_ROW)
        {
            
            // Init the Data Dictionary
            NSMutableDictionary *_dataDictionary=[[NSMutableDictionary alloc] init];
            
            NSString *str1 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
            NSString *str2 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
            NSString *str3 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 2)];
            NSString *str4 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 3)];
            NSString *str5 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 4)];
            NSString *str6 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 5)];
            NSString *str7 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 6)];
            NSString *str8 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 7)];
            NSString *str9 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 8)];
            NSString *str10 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 9)];
            NSString *str11 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 10)];
            NSString *str12 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 11)];
            
            
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str1] forKey:@"pdfname"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str2] forKey:@"title"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str3] forKey:@"invoice"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str4] forKey:@"name"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str5] forKey:@"address"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str6] forKey:@"city"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str7] forKey:@"phone"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str8] forKey:@"area"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str9] forKey:@"datetime"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str10] forKey:@"category"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str11] forKey:@"class"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str12] forKey:@"superviser"];
            
            [arr addObject:_dataDictionary];
        }
    }
    
    return arr;
}

//selectRandomEntryFormDB 2
-(NSMutableArray*)selectRandomEntryFormTableHeader2:(NSString*)pdfName
{
    arr = [[NSMutableArray alloc]init];
    dict =[[NSMutableDictionary alloc]init];
    
    // NSString *iscomplete=@"N";
    
    NSString *queryString=[NSString stringWithFormat:@"SELECT pdfname,titleatmos,inspection1,inspection2,inspection3,inspection4,inspection5,titleequipment,cfm1,cfm2,cfm3,cfm4,cfm5,inspection11,inspection22,inspection33,inspection44,inspection55 FROM pdf2_header2 WHERE pdfname=\"%@\"",pdfName];
    const char *sqlSelect = [queryString UTF8String];
    sqlite3_stmt *compiledStatement;
    
    
    if(sqlite3_prepare_v2(database, sqlSelect, -1, &compiledStatement, NULL) != SQLITE_OK)
    {
        
        NSLog(@"Error Occured:'%s'",sqlite3_errmsg(database));
        
    }
    else if(sqlite3_prepare_v2(database, sqlSelect, -1, &compiledStatement, NULL) == SQLITE_OK)
    {
        while(sqlite3_step(compiledStatement) == SQLITE_ROW)
        {
            
            // Init the Data Dictionary
            NSMutableDictionary *_dataDictionary=[[NSMutableDictionary alloc] init];
            
            NSString *str1 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
            NSString *str2 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
            NSString *str3 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 2)];
            NSString *str4 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 3)];
            NSString *str5 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 4)];
            NSString *str6 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 5)];
            NSString *str7 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 6)];
            NSString *str8 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 7)];
            NSString *str9 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 8)];
            NSString *str10 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 9)];
            NSString *str11 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 10)];
            NSString *str12 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 11)];
            NSString *str13 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 12)];
            NSString *str14 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 13)];
            NSString *str15 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 14)];
            NSString *str16 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 15)];
            NSString *str17 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 16)];
            NSString *str18 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 17)];
            
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str1] forKey:@"pdfname"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str2] forKey:@"titleatmos"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str3] forKey:@"inspection1"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str4] forKey:@"inspection2"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str5] forKey:@"inspection3"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str6] forKey:@"inspection4"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str7] forKey:@"inspection5"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str8] forKey:@"titleequipment"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str9] forKey:@"cfm1"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str10] forKey:@"cfm2"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str11] forKey:@"cfm3"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str12] forKey:@"cfm4"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str13] forKey:@"cfm5"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str14] forKey:@"inspection11"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str15] forKey:@"inspection22"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str16] forKey:@"inspection33"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str17] forKey:@"inspection44"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str18] forKey:@"inspection55"];
            
            [arr addObject:_dataDictionary];
        }
    }
    
    return arr;
}

//selectRandomEntryFormDB 3
-(NSMutableArray*)selectRandomEntryFormTableRow:(NSString*)pdfName withViewId:(NSString*)viewId andRowNumber:(int)rowNumber
{
    arr = [[NSMutableArray alloc]init];
    dict =[[NSMutableDictionary alloc]init];
    
    // NSString *iscomplete=@"N";
    
    NSString *queryString=[NSString stringWithFormat:@"SELECT pdfname,viewid,rownumber,datetime,temp1,rh1,gpp1,temp2,rh2,gpp2,temp3,rh3,gpp3,temp4,rh4,gpp4,temp5,rh5,gpp5 FROM pdf2_row WHERE pdfname=\"%@\" AND viewid=\"%@\" AND rownumber=\"%d\"",pdfName,viewId,rowNumber];
    const char *sqlSelect = [queryString UTF8String];
    sqlite3_stmt *compiledStatement;
    
    
    if(sqlite3_prepare_v2(database, sqlSelect, -1, &compiledStatement, NULL) != SQLITE_OK)
    {
        
        NSLog(@"Error Occured:'%s'",sqlite3_errmsg(database));
        
    }
    else if(sqlite3_prepare_v2(database, sqlSelect, -1, &compiledStatement, NULL) == SQLITE_OK)
    {
        while(sqlite3_step(compiledStatement) == SQLITE_ROW)
        {
            
            // Init the Data Dictionary
            NSMutableDictionary *_dataDictionary=[[NSMutableDictionary alloc] init];
            
            NSString *str1 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 0)];
            NSString *str2 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 1)];
            NSString *str3 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 2)];
            NSString *str4 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 3)];
            NSString *str5 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 4)];
            NSString *str6 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 5)];
            NSString *str7 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 6)];
            NSString *str8 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 7)];
            NSString *str9 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 8)];
            NSString *str10 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 9)];
            NSString *str11 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 10)];
            NSString *str12 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 11)];
            NSString *str13 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 12)];
            NSString *str14 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 13)];
            NSString *str15 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 14)];
            NSString *str16 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 15)];
            NSString *str17 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 16)];
            NSString *str18 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 17)];
            NSString *str19 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(compiledStatement, 18)];
            
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str1] forKey:@"pdfname"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str2] forKey:@"viewid"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str3] forKey:@"rownumber"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str4] forKey:@"datetime"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str5] forKey:@"temp1"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str6] forKey:@"rh1"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str7] forKey:@"gpp1"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str8] forKey:@"temp2"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str9] forKey:@"rh2"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str10] forKey:@"gpp2"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str11] forKey:@"temp3"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str12] forKey:@"rh3"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str13] forKey:@"gpp3"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str14] forKey:@"temp4"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str15] forKey:@"rh4"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str16] forKey:@"gpp4"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str17] forKey:@"temp5"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str18] forKey:@"rh5"];
            [_dataDictionary setObject:[NSString stringWithFormat:@"%@",str19] forKey:@"gpp5"];
            
            [arr addObject:_dataDictionary];
        }
    }
    
    return arr;
}

//ResettheDBLyrics
-(void)updateTheDB
{
    //NSString *query =  [NSString stringWithFormat:@"update Puzzle set iscompleted='N'"];
    NSString *query =  [NSString stringWithFormat:@"update Puzzle set Question= 'Arjun'"];
    sqlite3_stmt *statement;
    
    if (sqlite3_prepare_v2(database, [query UTF8String], -1, &statement, nil)
        == SQLITE_OK)
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
        if (sqlite3_step(statement) != SQLITE_DONE)
        {
            NSLog(@"error: %s", sqlite3_errmsg(database));
        }
        else
        {
            NSLog(@"update lYrics success - executed command %@",query);
        }
        sqlite3_reset(statement);
        sqlite3_step(statement);
        sqlite3_finalize(statement);
     // sqlite3_finalize(statement);
    }
    else
    {
        NSLog(@"error: %s", sqlite3_errmsg(database));
    }

}

//remove entry fron pdf1_header
-(NSMutableArray*)removeEntry:(NSString*)fileName withQuery:(NSString*)queryString
{
    BOOL success = NO;
    
   // AppDelegate *appDelegate = (AppDelegate *) [[UIApplication sharedApplication] delegate];
    
    sqlite3_stmt *statement;
    
    NSString *removeKeyword =queryString; //[NSString stringWithFormat:@"DELETE FROM pdf1_header WHERE Question = '%@'",fileName];
    
    if (sqlite3_prepare_v2(database, [removeKeyword UTF8String], -1, &statement, NULL) == SQLITE_OK)
    {
        if(sqlite3_step(statement) == SQLITE_DONE)
        {
            success = YES;
            [arr removeObject:fileName];
        }
        else
        {
            NSLog(@"%s: step not ok: %s", __FUNCTION__, sqlite3_errmsg(database));
        }
      //  sqlite3_finalize(statement);
        sqlite3_reset(statement);
        sqlite3_step(statement);
        sqlite3_finalize(statement);
    }
    else
    {
        NSLog(@"%s: prepare failure: %s", __FUNCTION__, sqlite3_errmsg(database));
    }
    
    return arr;
}

@end
