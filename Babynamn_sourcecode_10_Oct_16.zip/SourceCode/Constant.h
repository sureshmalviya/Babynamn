//
//  Constant.h
//  EventApp
//
//  Created by Shahid on 3/4/16.
//  Copyright (c) 2016 Sahid. All rights reserved.
//

#import <EventKit/EventKit.h>
#import <MessageUI/MessageUI.h>

#import "AppDelegate.h"
#import "MBProgressHUD.h"
#import "AboutUSVC.h"

#define CustomLocalisedString(key, comment) \
[[LanguageManager sharedLanguageManager] getTranslationForKey:key]


#ifndef EventApp_Constant_h
#define EventApp_Constant_h
#define  App_Name @"BARNNAMNSAPPEN"

//MASTER TABLE
#define TABLE_MASTER @"master_new"
#define TABLE_TOP100 @"top_hundred"

#define DB_NAME @"name"
#define DB_YEAR @"year"
#define DB_COUNT @"count"
#define DB_GENDER @"gender"
#define DB_GENDER_SWEEDIS @"gender2"
#define DB_INITIAL @"initial"
#define DB_ORIGIN @"lang_origin"
#define DB_SYLLABLES @"syllables"
#define DB_CREATEDON @"createdon"

#define sex_Male @"MALE"
#define sex_Female @"FEMALE"

#define TABLE_TV_SERIES @"tv_series"
#define DB_TYPE @"type"
#define DB_TYPE_NAME @"type_name"
#define DB_COUNTRY @"country"

#define COUNTRY_USA @"USA"
#define COUNTRY_SWEDEN @"SWEDEN"

//register device api keys
#define kDEVICE_ID          @"uniqueDeviceId"
#define kDEVICE_OS          @"device_os"
#define kDEVICE_TYPE        @"device_type"
#define kDEVICE_OS_VERSION  @"os_version"
#define kDEVICE_TOKEN       @"device_token"

#define kLastName @"last_name"

//*********************************************************************************
#define App_Delegate ((AppDelegate *)[[UIApplication sharedApplication] delegate])
#define NS_Defaults [NSUserDefaults standardUserDefaults]
#define NS_Notification [NSNotificationCenter defaultCenter]

#define IS_IPAD (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
#define IS_IPHONE (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)

#define IS_IPHONE_4 fabs( ( double )(( double )[ [ UIScreen mainScreen ] bounds ].size.height < ( double )568 ))
#define IS_IPHONE_5 fabs( ( double )(( double )[ [ UIScreen mainScreen ] bounds ].size.height == ( double )568 ))
#define IS_IPHONE_6 fabs( ( double )(( double )[ [ UIScreen mainScreen ] bounds ].size.height == ( double )667 ))
#define IS_IPHONE_6_PLUS fabs( ( double )(( double )[ [ UIScreen mainScreen ] bounds ].size.height == ( double ) 736 ))
#define IS_IOS_7 fabs( ( double )(( double ) [[[UIDevice currentDevice] systemVersion] floatValue] >= ( double ) 7 ))
#define IS_IOS_8 fabs( ( double )(( double ) [[[UIDevice currentDevice] systemVersion] floatValue] >= ( double ) 8 ))

//-------------------------------colors---------------------------------//
#define Rgb2UIColor(r, g, b)  [UIColor colorWithRed:((r) / 255.0) green:((g) / 255.0) blue:((b) / 255.0) alpha:1.0]

#define UIColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]
//UIColor *color = UIColorFromRGB(0x000000)

#define kEVENT_SEPERATOR_COLOR Rgb2UIColor (204, 203, 207)
#define kEVENT_BG_COLOR Rgb2UIColor (229, 235, 240)
//-------------------------------

#define kDemo 0 //1 for index jump demo on, 0 for index jump demo off

//NSLog in custom debug log
#ifdef DEBUG
#define NSLogDebug(format, ...) \
NSLog(@"<%s:%d> %s, " format, \
strrchr("/" __FILE__, '/') + 1, __LINE__, __PRETTY_FUNCTION__, ## __VA_ARGS__)
#else
#define NSLogDebug(format, ...)
#endif

#endif
