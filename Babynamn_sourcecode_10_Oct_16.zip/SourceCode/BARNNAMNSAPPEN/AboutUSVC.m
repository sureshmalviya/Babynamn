//
//  AboutUSVC.m
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 8/22/16.
//  Copyright © 2016 Sahid. All rights reserved.
//

#import "AboutUSVC.h"

#import "AboutAppVC.h"
#import "ContactUsVC.h"
#import "FaqVC.h"

@interface AboutUSVC ()

@end

@implementation AboutUSVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(IBAction)btnBackClicked:(UIButton*)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(IBAction)btnAboutClicked:(UIButton*)sender
{
    if (sender.tag==101)//about app
    {
        AboutAppVC *obj=[[AboutAppVC alloc]init];
        [self.navigationController pushViewController:obj animated:YES];
    }
    else if (sender.tag==102)//faq
    {
        FaqVC *obj=[[FaqVC alloc]init];
        [self.navigationController pushViewController:obj animated:YES];
    }
    else if (sender.tag==103)//cotact us
    {
        ContactUsVC *obj=[[ContactUsVC alloc]init];
        [self.navigationController pushViewController:obj animated:YES];
    }
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
