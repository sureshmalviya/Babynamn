//
//  BrowseVC.m
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 7/26/16.
//  Copyright (c) 2016 Sahid. All rights reserved.
//

#import "BrowseVC.h"
#import "BrowseListVC.h"
#import "FamousTvSeriesVC.h"
#import "MyFavouriteVC.h"
#import "KnownFilmVC.h"

@import Firebase;
@interface BrowseVC ()

@end

@implementation BrowseVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Button Actions
-(IBAction)btnBackClicked:(UIButton*)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(IBAction)btnFavouriteClicked:(UIButton*)sender
{
    if (sender.tag==101)//favorite
    {
        MyFavouriteVC *fav=[[MyFavouriteVC alloc]init];
        [self.navigationController pushViewController:fav animated:YES];
    }
    else if (sender.tag==102)//help
    {
        AboutUSVC *obj=[[AboutUSVC alloc]init];
        [self.navigationController pushViewController:obj animated:YES];
//        NSLog(@"Help Clicked");
    }
}
-(IBAction)btnShowListClicked:(UIButton*)sender
{
    if (sender.tag==301)//a-o
    {
        //FireBaseAnalytic
        [FIRAnalytics logEventWithName:@"A_to_O"
                            parameters:@{@"description": @"A to O pressed"}];
        
        BrowseListVC *obj=[[BrowseListVC alloc]init];
        obj.strTitle=@"A-Ö";
        obj.isAtoZclicked=YES;
        [self.navigationController pushViewController:obj animated:YES];
    }
    else if (sender.tag==302)//top 100
    {
        //FireBaseAnalytic
        [FIRAnalytics logEventWithName:@"Topp_100"
                            parameters:@{@"description": @"Topp 100 pressed"}];
        
        BrowseListVC *obj=[[BrowseListVC alloc]init];
        obj.strTitle=@"Topp 100";
        [self.navigationController pushViewController:obj animated:YES];
    }
    else if (sender.tag==303)//known films
    {
        //FireBaseAnalytic
        [FIRAnalytics logEventWithName:@"Known_Films"
                            parameters:@{@"description": @"Known Films pressed"}];
        
        FamousTvSeriesVC *fam=[[FamousTvSeriesVC alloc]init];
        fam.seriesType=@"MOVIE";
        fam.strTitle=@"KÄNDA FILMER";
        fam.strSubTitle=@"Namn från kända filmer";
        [self.navigationController pushViewController:fam animated:YES];
    }
    else if (sender.tag==304)//famous tv series
    {
        //FireBaseAnalytic
        [FIRAnalytics logEventWithName:@"Famous_tv_series"
                            parameters:@{@"description": @"Famous tv series pressed"}];
        
        FamousTvSeriesVC *fam=[[FamousTvSeriesVC alloc]init];
        fam.seriesType=@"TV";
        fam.strTitle=@"KÄNDA TV SERIER";
        fam.strSubTitle=@"Namn från TV-serier";
        [self.navigationController pushViewController:fam animated:YES];
    }
}
@end
