//
//  HomeVC.h
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 7/25/16.
//  Copyright (c) 2016 Sahid. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeVC : UIViewController
{
    IBOutlet UILabel *lblTitle;
    
    IBOutlet UIView *viewTutorial;
}
-(IBAction)btnSearchClicked:(UIButton*)sender;
-(IBAction)btnFavouriteClicked:(UIButton*)sender;
-(IBAction)btnCloseTutorial:(UIButton*)sender;
-(IBAction)btnAboutUsClicked:(UIButton*)sender;
@end
