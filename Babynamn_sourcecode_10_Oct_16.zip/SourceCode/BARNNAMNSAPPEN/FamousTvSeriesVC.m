//
//  FamousTvSeriesVC.m
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 7/26/16.
//  Copyright (c) 2016 Sahid. All rights reserved.
//

#import "FamousTvSeriesVC.h"
#import "MyFavouriteVC.h"
#import "TVSeriesCell.h"
#import "TvObject.h"
#import "KnownFilmVC.h"
@interface FamousTvSeriesVC ()

@end

@implementation FamousTvSeriesVC
@synthesize seriesType,strTitle,strSubTitle;
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    btnSwedish.selected=YES;
    
    lblTitle.text=strTitle;
    lblSubTitle.text=strSubTitle;
    
    [self fillInfo];
}
-(void)fillInfo
{
    NSMutableArray *arr=[TvObject getTvSeriesName_Country:COUNTRY_SWEDEN type:seriesType];
    
    arrTVSeries=[App_Delegate sortArray:arr withKey:@"strTypeName" ascending:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Button Actions
-(IBAction)btnBackClicked:(UIButton*)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(IBAction)btnFavouriteClicked:(UIButton*)sender
{
    if (sender.tag==101)//favorite
    {
        MyFavouriteVC *fav=[[MyFavouriteVC alloc]init];
        [self.navigationController pushViewController:fav animated:YES];
    }
    else if (sender.tag==102)//help
    {
        AboutUSVC *obj=[[AboutUSVC alloc]init];
        [self.navigationController pushViewController:obj animated:YES];
        //        NSLog(@"Help Clicked");
    }
}
-(IBAction)btnSwedishClicked:(UIButton*)sender
{
    if (sender.tag==501)//swidesh
    {
        if (sender.selected==NO)
        {
            btnSwedish.selected=YES;
            btnAmerican.selected=NO;
            
            NSMutableArray *arr=[TvObject getTvSeriesName_Country:COUNTRY_SWEDEN type:seriesType];
            arrTVSeries=[App_Delegate sortArray:arr withKey:@"strTypeName" ascending:YES];
            [table_Series reloadData];
            [table_Series setContentOffset:CGPointMake(0, 0)];
        }
    }
    else if (sender.tag==502)//american
    {
        if (sender.selected==NO)
        {
            btnAmerican.selected=YES;
            btnSwedish.selected=NO;
            
            NSMutableArray *arr=[TvObject getTvSeriesName_Country:COUNTRY_USA type:seriesType];
            arrTVSeries=[App_Delegate sortArray:arr withKey:@"strTypeName" ascending:YES];
            [table_Series reloadData];
            [table_Series setContentOffset:CGPointMake(0, 0)];
        }
    }
    
}
#pragma mark - UITableView Delegates
#pragma mark -

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrTVSeries.count;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 52;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *Identifier = @"TVSeriesCell";
    
    TVSeriesCell *cell = (TVSeriesCell*)[tableView dequeueReusableCellWithIdentifier:Identifier];
    
    if(cell==nil)
    {
        NSArray *topLevelObjects = [[NSBundle mainBundle]loadNibNamed:@"TVSeriesCell" owner:nil options:nil];
        cell=[topLevelObjects firstObject];
    }
    
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    
    TvObject *tv=[[TvObject alloc]initWithDefaults];
    tv=[arrTVSeries objectAtIndex:indexPath.row];
    
    cell.lblTitle.text=tv.strTypeName;
    
    return  cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    TvObject *tv=[arrTVSeries objectAtIndex:indexPath.row];
    
    KnownFilmVC *film=[[KnownFilmVC alloc]init];
    film.object_TV=tv;
    [self.navigationController pushViewController:film animated:YES];
}
@end
