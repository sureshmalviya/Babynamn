//
//  HomeVC.m
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 7/25/16.
//  Copyright (c) 2016 Sahid. All rights reserved.
//

#import "HomeVC.h"
#import "SearchVC.h"
#import "BrowseVC.h"
#import "MyFavouriteVC.h"
#import "NameDetailVC.h"
#import "RandomNameVC.h"
#import "AboutUSVC.h"

@interface HomeVC ()

@end

@implementation HomeVC

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    viewTutorial.frame=CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - UIButton Actions
#pragma mark -
-(IBAction)btnSearchClicked:(UIButton*)sender
{
    if (sender.tag==101)//search
    {
        SearchVC *obj=[[SearchVC alloc]init];
        [self.navigationController pushViewController:obj animated:YES];
    }
    else if (sender.tag==102)//browse
    {
        BrowseVC *obj=[[BrowseVC alloc]init];
        [self.navigationController pushViewController:obj animated:YES];
    }
    else if (sender.tag==103)//randomise
    {
        
        RandomNameVC *obj=[[RandomNameVC alloc]init];
        obj.strTitle=@"Randomize";
        [self.navigationController pushViewController:obj animated:YES];
    }
}
-(IBAction)btnFavouriteClicked:(UIButton*)sender
{
    if (sender.tag==201)//favorite
    {
        MyFavouriteVC *fav=[[MyFavouriteVC alloc]init];
        [self.navigationController pushViewController:fav animated:YES];
    }
    else if (sender.tag==202)//help
    {
        AboutUSVC *obj=[[AboutUSVC alloc]init];
        [self.navigationController pushViewController:obj animated:YES];
        //[App_Delegate showPopup:viewTutorial OnView:self.view];
    }
}
-(IBAction)btnCloseTutorial:(UIButton*)sender
{
    [App_Delegate hidePopup:viewTutorial fromView:self.view];
}
-(IBAction)btnAboutUsClicked:(UIButton*)sender
{
    AboutUSVC *obj=[[AboutUSVC alloc]init];
    [self.navigationController pushViewController:obj animated:YES];
}
@end
