//
//  SplashVC.h
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 8/19/16.
//  Copyright © 2016 Sahid. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SplashVC : UIViewController
{
    IBOutlet UIImageView *img;
}
@end
