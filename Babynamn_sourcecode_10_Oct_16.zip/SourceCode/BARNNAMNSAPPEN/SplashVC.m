//
//  SplashVC.m
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 8/19/16.
//  Copyright © 2016 Sahid. All rights reserved.
//

#import "SplashVC.h"
#import "HomeVC.h"

@interface SplashVC ()

@end

@implementation SplashVC

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    if (IS_IPHONE_4)
    {
        img.image=[UIImage imageNamed:@"sp4.png"];
    }
    
    [self performSelector:@selector(pushToHomeVC) withObject:nil afterDelay:2.0];
}
-(void)pushToHomeVC
{
    HomeVC *objHome=[[HomeVC alloc]init];
    [self.navigationController pushViewController:objHome animated:NO];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
