//
//  SearchResultsVC.h
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 7/26/16.
//  Copyright (c) 2016 Sahid. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SearchObject.h"

@interface SearchResultsVC : UIViewController<UITableViewDataSource,UITabBarDelegate>
{
    IBOutlet UITableView *table_names;
    IBOutlet UILabel *lblSex;
    IBOutlet UILabel *lblBeginsWith;
    IBOutlet UILabel *lblCountry;
    IBOutlet UILabel *lblPopularity;
    IBOutlet UILabel *lblSyllable;
    
    NSMutableArray *arrNames;
}
@property(strong,nonatomic)SearchObject *object_search;
-(IBAction)btnBackClicked:(UIButton*)sender;
-(IBAction)btnFavouriteClicked:(UIButton*)sender;
@end
