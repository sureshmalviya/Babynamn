//
//  AppDelegate.h
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 7/25/16.
//  Copyright (c) 2016 Sahid. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SQLiteManager.h"
@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    NSString *dbName;
}
@property (strong, nonatomic) UIWindow *window;

@property(nonatomic,strong) SQLiteManager *dbManager;
@property(nonatomic,retain)NSString *dbPath;


-(void)showPopup:(UIView*)vu OnView:(UIView*)parentView;
-(void)hidePopup:(UIView*)vu fromView:(UIView*)parentView;

-(BOOL)isStringEmpty:(NSString*)str;

-(NSMutableArray *)sortArray:(NSMutableArray*)inputArray withKey:(NSString*)key ascending:(BOOL)order;
@end

