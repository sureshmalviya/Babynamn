//
//  BrowseVC.h
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 7/26/16.
//  Copyright (c) 2016 Sahid. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BrowseVC : UIViewController
{
    IBOutlet UILabel *lblTitle;
}
-(IBAction)btnBackClicked:(UIButton*)sender;
-(IBAction)btnFavouriteClicked:(UIButton*)sender;
-(IBAction)btnShowListClicked:(UIButton*)sender;
@end
