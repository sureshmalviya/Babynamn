//
//  TVSeriesNameDetail.m
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 8/1/16.
//  Copyright (c) 2016 Sahid. All rights reserved.
//

#import "TVSeriesNameDetail.h"
#import "MyFavouriteVC.h"
#import "collectionCell.h"
#import "MyFavoriteObject.h"
@import Firebase;
@interface TVSeriesNameDetail ()

@end

@implementation TVSeriesNameDetail
@synthesize strTitle,tv_object;
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    lblTitle.text=strTitle;
    
    lblName.text=strTitle;
    
    [collectionVu registerNib:[UINib nibWithNibName:@"collectionCell" bundle:[NSBundle mainBundle]] forCellWithReuseIdentifier:@"collectionCell"];
    
    //lblPopularityTitle.text=@"Popularity Statistics (2004-15)";
    
    [self fillInfo];
}
-(void)fillInfo
{
    NSMutableArray *arrDetails=[NameObject getNameDetails:strTitle andGender:tv_object.strGender];
    
    //1
    object_Name=[[NameObject alloc]initWithDefaults];
    if (arrDetails.count>0)
    {
        object_Name=[arrDetails firstObject];
    }
    
    //*****
    lblName.text=tv_object.strName;

    if ([tv_object.strGender isEqualToString:sex_Female]) {
        lblGender.text=@"Flicka";
    }else{
        lblGender.text=@"Pojke";
    }
    
//    viewCountry.hidden=YES;
//    viewFamousPeople.hidden=YES;
//    viewPopularity.hidden=YES;
    
    
    //2
    NSMutableArray *arrTemp=[NameObject getNamePopularityFrom_MasterTable:strTitle genderSW:object_Name.strGender];
    arrPopularity=[self sortYearAscending:arrTemp];
    
    
    //
    if (arrPopularity.count>0)
    {
        NameObject *first=[arrPopularity firstObject];
        NameObject *last=[arrPopularity lastObject];
        
        NSString *startYear=first.strYear;
        NSString *endYear=[last.strYear substringWithRange:NSMakeRange(2, 2)];
        
        lblPopularityTitle.text=[NSString stringWithFormat:@"Antal namngivna bebisar i Sverige(%@-%@)",startYear,endYear];
    }
    
    
    
    //
    lblName.text=tv_object.strName;
    
    if ([tv_object.strGender isEqualToString:sex_Female]) {
        lblGender.text=@"Flicka";
    }else{
        lblGender.text=@"Pojke";
    }
    
    if ([App_Delegate isStringEmpty:object_Name.strGender] && [App_Delegate isStringEmpty:object_Name.strGender2])
    {
        //viewGender.hidden=YES;
        viewCountry.hidden=YES;
        viewFamousPeople.hidden=YES;
        viewPopularity.hidden=YES;
        return;
    }

    lblCountry.text=object_Name.strOrigin;
    
//    NSString *str=[object_Name.strOrigin stringByReplacingOccurrencesOfString:@" " withString:@""];
//    str=[str stringByReplacingOccurrencesOfString:@"," withString:@"\n"];

    //THIS WILL REMOVE THE SPECIAL CHARACTER WITH ACTUAL SPACE CHARECTER
    NSString *str = [object_Name.strOrigin stringByReplacingOccurrencesOfString:@"\u00a0" withString:@""];
    str=[str stringByReplacingOccurrencesOfString:@"," withString:@", "];
    
    
    lblCountry.text=str;
    float height=[self getLabelSize:str];
    viewCountry.layer.cornerRadius=5.0;
    viewCountry.layer.borderColor=[UIColor grayColor].CGColor;
    viewCountry.layer.borderWidth=1.0;
    
    //float height=[self getLabelSize:object_Name.strOrigin];
    
    if (height>21)
    {
        lblCountry.frame=CGRectMake(lblCountry.frame.origin.x, lblCountry.frame.origin.y, lblCountry.frame.size.width, height);
        viewCountry.frame=CGRectMake(viewCountry.frame.origin.x, viewCountry.frame.origin.y, viewCountry.frame.size.width, 29+height);
    }
    else
    {
        lblCountry.frame=CGRectMake(lblCountry.frame.origin.x, lblCountry.frame.origin.y, lblCountry.frame.size.width, 21);
        viewCountry.frame=CGRectMake(viewCountry.frame.origin.x, viewCountry.frame.origin.y, viewCountry.frame.size.width, 29+21);
    }
    
    
    //3
    NSString *strFamousPeople=[App_Delegate.dbManager getFamousPeople_whoHaveName:object_Name.strName];
    float famousHeight=[self getLabelSize:strFamousPeople];
    lblFamousPeople.text=strFamousPeople;
    if (famousHeight>21)
    {
        lblFamousPeople.frame=CGRectMake(lblFamousPeople.frame.origin.x, lblFamousPeople.frame.origin.y, lblFamousPeople.frame.size.width, famousHeight);
        viewFamousPeople.frame=CGRectMake(viewFamousPeople.frame.origin.x, viewCountry.frame.origin.y+viewCountry.frame.size.height+8, viewFamousPeople.frame.size.width, 29+famousHeight);
        
        viewFamousPeople.hidden=NO;
    }
    else
    {
        lblFamousPeople.frame=CGRectMake(lblFamousPeople.frame.origin.x, lblFamousPeople.frame.origin.y, lblFamousPeople.frame.size.width, 21);
        viewFamousPeople.frame=CGRectMake(viewFamousPeople.frame.origin.x, viewCountry.frame.origin.y+viewCountry.frame.size.height+8, viewFamousPeople.frame.size.width, 29+21);
        
        viewFamousPeople.hidden=NO;
    }
    
    if ([App_Delegate isStringEmpty:strFamousPeople] || [strFamousPeople isEqualToString:@"not_found"])
    {
        viewFamousPeople.frame=CGRectMake(viewFamousPeople.frame.origin.x, viewCountry.frame.origin.y+viewCountry.frame.size.height, viewFamousPeople.frame.size.width, 1);
        viewFamousPeople.hidden=YES;
    }
    
    
    viewPopularity.frame=CGRectMake(viewPopularity.frame.origin.x, viewFamousPeople.frame.origin.y+viewFamousPeople.frame.size.height+8, viewPopularity.frame.size.width, viewPopularity.frame.size.height);
    
    
    //
    int arrCounter=(int)arrPopularity.count;
    if (arrCounter==0)
    {
        viewPopularity.hidden=YES;
    }
    else
    {
        int row=ceilf(arrCounter/3);
        
        if (arrCounter%3!=0)
        {
            row+=1;
        }
        
        float h=row*20;
        collectionVu.frame=CGRectMake(collectionVu.frame.origin.x, collectionVu.frame.origin.y, collectionVu.frame.size.width, h);
        
        viewPopularity.frame=CGRectMake(viewPopularity.frame.origin.x, viewFamousPeople.frame.origin.y+viewFamousPeople.frame.size.height+8, viewPopularity.frame.size.width, 30+h);
    }
    
    float xx=viewPopularity.frame.origin.y+viewPopularity.frame.size.height;
    
    if (xx>scrollBG.frame.size.height)
    {
        scrollBG.contentSize=CGSizeMake(self.view.frame.size.width, xx+35);
    }
}
-(NSMutableArray*)sortYearAscending:(NSArray*)arrayToSort
{
    NSArray *sortedArray=[[NSArray alloc]init];
    
    sortedArray = [arrayToSort sortedArrayUsingComparator:^(NameObject *obj1, NameObject *obj2)
                   {
                       if ([obj1.strYear intValue] && [obj2.strYear intValue]) {
                           
                           NSNumber *first = [NSNumber numberWithInt:[obj1.strYear intValue]];
                           NSNumber *second = [NSNumber numberWithInt:[obj2.strYear intValue]];
                           return [first compare:second];
                           //return [second compare:first];
                       }
                       // TODO: default is the same?
                       return (NSComparisonResult)NSOrderedSame;
                   }];
    
    return [sortedArray mutableCopy];
}
-(CGFloat)getLabelSize:(NSString*)str
{
    //1
    NSDictionary *attributesDictionary2 = [NSDictionary dictionaryWithObjectsAndKeys:
                                           [UIFont fontWithName:@"Helvetica" size:12.0], NSFontAttributeName,
                                           nil];
    
    CGRect sz2 = [str boundingRectWithSize:CGSizeMake(276, 9999)
                                   options:NSStringDrawingUsesLineFragmentOrigin
                                attributes:attributesDictionary2
                                   context:nil];
    return sz2.size.height;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Button Actions
-(IBAction)btnBackClicked:(UIButton*)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(IBAction)btnFavouriteClicked:(UIButton*)sender
{
    if (sender.tag==101)//favorite
    {
        MyFavouriteVC *fav=[[MyFavouriteVC alloc]init];
        [self.navigationController pushViewController:fav animated:YES];
    }
    else if (sender.tag==102)//help
    {
        AboutUSVC *obj=[[AboutUSVC alloc]init];
        [self.navigationController pushViewController:obj animated:YES];
        //NSLog(@"Help Clicked");
    }
}
-(IBAction)btnAddFavClicked:(UIButton*)sender
{
    NSMutableArray *arrTemp=[App_Delegate.dbManager getFavorite_Name:object_Name.strName andGender:tv_object.strGender];
    
    if (arrTemp.count>0)
    {
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:App_Name message:@"Namnet finns redan i Mina favoriter" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];//Name already exists my Favorite list
        
        [alert show];
    }
    else
    {
        //FireBaseAnalytic
        [FIRAnalytics logEventWithName:@"Add_to_Favorite"
                            parameters:@{@"description": @"Add to Favorite pressed"}];
        
//        NSString *gender=@"";
//        if ([tv_object.strGender isEqualToString:sex_Female]){
//            gender=@"Kvinna";
//        }else{
//            gender=@"Man";
//        }
        NSMutableArray *arr=[App_Delegate.dbManager getAllFavorites];
        NSString *lastName=@"";
        if (arr.count>0)
        {
            MyFavoriteObject *fv=[arr firstObject];
            lastName=fv.strLastName;
        }
        
        
        MyFavoriteObject *objFav=[[MyFavoriteObject alloc]initWithDefaults];
        objFav.strFirstName=tv_object.strName;
        objFav.strGender=tv_object.strGender;
        objFav.strLastName=lastName;
        int max=[App_Delegate.dbManager getMaxOrdering];
        objFav.ordering=max+1;
        [App_Delegate.dbManager insertFavorite:objFav];
        
        //
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil
                                                                       message:@"Namn tillagt i Mina favoriter"//@"Name added to my favorite list"
                                                                preferredStyle:UIAlertControllerStyleAlert];
        
        [self presentViewController:alert animated:YES completion:nil];
        int duration = 1.5; //duration in seconds
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, duration * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
            [alert dismissViewControllerAnimated:YES completion:nil];
            
        });
    }
}
-(IBAction)btnRandomizeAgain:(UIButton*)sender
{
    [self fillInfo];
}
#pragma mark - CollectionView Delegates
#pragma mark -
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return arrPopularity.count;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    //1
    static NSString *identifier = @"collectionCell";
    collectionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
    
    cell.tag=indexPath.item+1001;
    
    NameObject *obj=[[NameObject alloc]initWithDefaults];
    
    obj=[arrPopularity objectAtIndex:indexPath.item];
    
    cell.lblYear.text=[NSString stringWithFormat:@"%@ -",obj.strYear];
    cell.lblPopularity.text=obj.strPopularity;
    
    return cell;
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    
}


@end
