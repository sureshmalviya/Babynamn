//
//  FamousTvSeriesVC.h
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 7/26/16.
//  Copyright (c) 2016 Sahid. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FamousTvSeriesVC : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    IBOutlet UIButton *btnSwedish;
    IBOutlet UIButton *btnAmerican;
    
    IBOutlet UITableView *table_Series;
    NSMutableArray *arrTVSeries;
    
    IBOutlet UILabel *lblTitle;
    
    IBOutlet UILabel *lblSubTitle;
}
@property(strong,nonatomic)NSString *seriesType;
@property(strong,nonatomic)NSString *strTitle;
@property(strong,nonatomic)NSString *strSubTitle;

-(IBAction)btnBackClicked:(UIButton*)sender;
-(IBAction)btnFavouriteClicked:(UIButton*)sender;
-(IBAction)btnSwedishClicked:(UIButton*)sender;

@end
