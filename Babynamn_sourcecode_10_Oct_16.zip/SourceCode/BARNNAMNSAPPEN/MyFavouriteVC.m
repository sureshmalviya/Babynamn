//
//  MyFavouriteVC.m
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 7/26/16.
//  Copyright (c) 2016 Sahid. All rights reserved.
//

#import "MyFavouriteVC.h"
#import "SearchResultCell.h"
#import "NameDetailVC.h"
#import "FavoriteCell.h"
#import "MyFavoriteObject.h"
//#import <FBSDKShareKit/FBSDKShareKit.h>
#import <Social/Social.h>
@import Firebase;
@interface MyFavouriteVC ()//<FBSDKSharingDelegate>
{
    NSIndexPath *newIndex,*oldIndex;
}
@end

@implementation MyFavouriteVC

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    arrNames=[[NSMutableArray alloc]init];//WithObjects:@"Abraham",@"Mohammed",@"Yunus",@"Yakub",@"Aadam",@"Musa",@"Esha",@"Mariyam",@"Aisha",@"Fatima",@"Daood",@"Ismail",@"Abraham",@"Mohammed",@"Yunus",@"Yakub",@"Aadam",@"Musa",@"Esha",@"Mariyam",@"Aisha",@"Fatima",@"Daood",@"Ismail",@"Abraham",@"Mohammed",@"Yunus",@"Yakub",@"Aadam",@"Musa",@"Esha",@"Mariyam",@"Aisha",@"Fatima",@"Daood",@"Ismail", nil];
    
    table_name.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    table_name.separatorStyle = UITableViewCellSeparatorStyleNone;
    table_name.dataSource = self;
    table_name.delegate=self;
    
    [self fillInfo];
}
-(void)fillInfo
{
    arrNames = [App_Delegate.dbManager getAllFavorites];
    
    if (arrNames.count>0)
    {
        btnEnterLastName.enabled=YES;
        
        MyFavoriteObject *f=[arrNames firstObject];
        if ([App_Delegate isStringEmpty:f.strLastName])
        {
            table_name.frame=CGRectMake(table_name.frame.origin.x, table_name.frame.origin.y, table_name.frame.size.width, btnRemoveLastName.frame.origin.y-table_name.frame.origin.y+btnRemoveLastName.frame.size.height);
            btnRemoveLastName.hidden=YES;
        }
        else
        {
            table_name.frame=CGRectMake(table_name.frame.origin.x, table_name.frame.origin.y, table_name.frame.size.width, btnRemoveLastName.frame.origin.y-table_name.frame.origin.y);
            btnRemoveLastName.hidden=NO;
        }
    }
    else
    {
        btnEnterLastName.enabled=NO;
    }
    
    [table_name reloadData];
    
    //[table_name setEditing:YES animated:YES];
}
-(void)viewDidAppear:(BOOL)animated
{
    viewSharePopup.frame=self.view.frame;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - Button action
-(IBAction)btnBackClicked:(UIButton*)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(IBAction)btnAddFavClicked:(UIButton*)sender
{
    if (sender.tag==101)//share
    {
        [self.view addSubview:viewSharePopup];
        //[self shareFavoriteList];
    }
    else if (sender.tag==102)//add
    {
        [App_Delegate showPopup:viewFavPopup OnView:self.view];
        
        txtFavName.text=@"";
        [txtFavName becomeFirstResponder];
    }
}
-(IBAction)btnEnterLastName:(UIButton*)sender
{
    if (sender.tag==301)
    {
        [App_Delegate showPopup:viewPopup OnView:self.view];
        
        txtLastName.text=@"";
        [txtLastName becomeFirstResponder];
    }
    else if (sender.tag==302)
    {
        NSString *message=[NSString stringWithFormat:@"Är du säker på att du vill ta bort efternamnet?"];
        
        UIAlertView *alrt=[[UIAlertView alloc]initWithTitle:App_Name message:message delegate:self cancelButtonTitle:@"Avbryt" otherButtonTitles:@"Ok", nil];
        alrt.tag=202;
        [alrt show];
    }
}
-(IBAction)btnDonePopup:(UIButton*)sender
{
    if (sender.tag==1001)//done
    {
        if ([App_Delegate.dbManager updateLastNameOfFavoriteList:txtLastName.text])
        {
            [self fillInfo];
            [table_name reloadData];
        }
        else
        {
            //
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil
                                                                           message:@"Något blev fel"//@"Something went wrong"
                                                                    preferredStyle:UIAlertControllerStyleAlert];
            
            [self presentViewController:alert animated:YES completion:nil];
            int duration = 1.5; // duration in seconds
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, duration * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
                [alert dismissViewControllerAnimated:YES completion:nil];
                
            });

        }
        
        [App_Delegate hidePopup:viewPopup fromView:self.view];
    }
    else if (sender.tag==1002)//cancel
    {
        [App_Delegate hidePopup:viewPopup fromView:self.view];
    }
    else if (sender.tag==2001)//done fav popup
    {
        MyFavoriteObject *obj=[[MyFavoriteObject alloc]initWithDefaults];
        if ([App_Delegate isStringEmpty:txtFavName.text]==NO)
        {
            NSMutableArray *arrTemp=[App_Delegate.dbManager getFavorite_Name:[txtFavName.text capitalizedString] andGender:@"zero"];
            if (arrTemp.count>0)
            {
                UIAlertView *alert=[[UIAlertView alloc]initWithTitle:App_Name message:@"Namnet finns redan i Mina favoriter" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];//Name already exists in my favorite list
                
                [alert show];
            }
            else
            {
                obj.strFirstName=txtFavName.text;
                int max=[App_Delegate.dbManager getMaxOrdering];
                obj.ordering=max+1;
                [App_Delegate.dbManager insertFavorite:obj];
                
                [self performSelector:@selector(fillInfo) withObject:nil afterDelay:0.8];
                //[self fillInfo];
                
                //[table_name reloadData];
            }
        }
        else
        {
            //
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil
                                                                           message:@"Något blev fel"//@"Something went wrong"
                                                                    preferredStyle:UIAlertControllerStyleAlert];
            
            [self presentViewController:alert animated:YES completion:nil];
            int duration = 1.5; // duration in seconds
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, duration * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
                [alert dismissViewControllerAnimated:YES completion:nil];
                
            });
            
        }
        
        [App_Delegate hidePopup:viewFavPopup fromView:self.view];
    }
    else if (sender.tag==2002)//cancel fav popup
    {
        [App_Delegate hidePopup:viewFavPopup fromView:self.view];
    }
    
    [txtLastName resignFirstResponder];
    [txtFavName resignFirstResponder];
}
-(void)btnDeleteFav:(UIButton*)sender
{
    CGPoint buttonOrigin = sender.frame.origin;
    CGPoint pointInTableview = [table_name convertPoint:buttonOrigin fromView:sender.superview];
    NSIndexPath *indexPath = [table_name indexPathForRowAtPoint:pointInTableview];
    
    MyFavoriteObject *favObj=[arrNames objectAtIndex:indexPath.row];
    
    indexToDelete=(int)indexPath.row;
    
    NSString *message=[NSString stringWithFormat:@"Är du säker på att du vill ta bort %@?",favObj.strFirstName];
    
    UIAlertView *alrt=[[UIAlertView alloc]initWithTitle:App_Name message:message delegate:self cancelButtonTitle:@"Avbryt" otherButtonTitles:@"Ok", nil];
    alrt.tag=101;
    [alrt show];
}
-(IBAction)btnSocialSharing:(UIButton*)sender
{
    if (sender.tag==2001)//fb
    {
        //FireBaseAnalytic
        [FIRAnalytics logEventWithName:@"Facebook_Share"
                            parameters:@{@"description": @"Facebook Share pressed"}];
        
        [self shareOnFacebook];
    }
    else if (sender.tag==2002)//message
    {
        //FireBaseAnalytic
        [FIRAnalytics logEventWithName:@"SMS_Share"
                            parameters:@{@"description": @"SMS pressed"}];
        
        [self sendSMS];
    }
    else if (sender.tag==2003)//email
    {
        //FireBaseAnalytic
        [FIRAnalytics logEventWithName:@"Email_Share"
                            parameters:@{@"description": @"Email Share pressed"}];
        [self sendEmail];
    }
    else if (sender.tag==2004)//cancel
    {
        
    }
    
    [viewSharePopup removeFromSuperview];
}
#pragma mark - alert view delegates
#pragma mark -
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag==101 && buttonIndex==1)
    {
        MyFavoriteObject *obj=[arrNames objectAtIndex:indexToDelete];
        
        if ([App_Delegate.dbManager deleteFromFavoriteList:obj.strFirstName andGender:obj.strGender])
        {
            [arrNames removeObjectAtIndex:indexToDelete];
        }
        
        [self fillInfo];
        [table_name reloadData];
    }
    else if (alertView.tag==202 && buttonIndex==1)
    {
        [App_Delegate.dbManager updateLastNameOfFavoriteList:@""];
        [self fillInfo];
        [table_name reloadData];
    }
}
#pragma mark - textfield delegates
#pragma mark -
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
#pragma mark - UITableView Delegates
#pragma mark -
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrNames.count;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 30;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *Identifier = @"FavoriteCell";
    
    FavoriteCell *cell = (FavoriteCell*)[tableView dequeueReusableCellWithIdentifier:Identifier];
    
//    if(cell==nil)
//    {
        NSArray *topLevelObjects = [[NSBundle mainBundle]loadNibNamed:@"FavoriteCell" owner:nil options:nil];
        cell=[topLevelObjects firstObject];
//    }
    
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    
    MyFavoriteObject *fav=[arrNames objectAtIndex:indexPath.row];
    NSString *strName=fav.strFirstName;
    
    NSString *lastName=fav.strLastName;
    
    NSString *finalString;
    if ([App_Delegate isStringEmpty:fav.strLastName]==NO){
        finalString=[NSString stringWithFormat:@"%@ %@",strName,lastName];
    }else{
        finalString=strName;
    }
    
    NSString *gender=[self getGenderOfGivenName:fav.strFirstName];
    
    if ([gender isEqualToString:sex_Female])
    {
        cell.lblName.text=[NSString stringWithFormat:@"%@ (F)",finalString];
    }
    else if ([gender isEqualToString:sex_Male])
    {
        cell.lblName.text=[NSString stringWithFormat:@"%@ (P)",finalString];
    }
    else
    {
        cell.lblName.text=[NSString stringWithFormat:@"%@ (-)",finalString];
    }

    
    [cell.btnDelete addTarget:self action:@selector(btnDeleteFav:) forControlEvents:UIControlEventTouchUpInside];
    cell.btnDelete.tag=indexPath.row;
    
    cell.lblName.backgroundColor=[UIColor clearColor];
    cell.backgroundColor=[UIColor clearColor];
    cell.lblName.textColor=[UIColor whiteColor];
    
    cell.contentView.backgroundColor=[UIColor clearColor];
    
    [cell.btnSelectName addTarget:self action:@selector(selectName:) forControlEvents:UIControlEventTouchUpInside];
    cell.btnSelectName.tag=indexPath.row+100;
    cell.btnSelectName.frame=cell.lblName.frame;
    
    return  cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    MyFavoriteObject *fav=[arrNames objectAtIndex:indexPath.row];
    
    NSString *strName=fav.strFirstName;
    
    NameDetailVC *name=[[NameDetailVC alloc]init];
    name.strTitle=[strName capitalizedString];
    name.strGenderr=fav.strGender;
    name.isFromFavoriteScreen=YES;
    [self.navigationController pushViewController:name animated:YES];
}

//- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    return YES;
//}

- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
    //Even if the method is empty you should be seeing both rearrangement icon and animation.
    
    [arrNames exchangeObjectAtIndex:fromIndexPath.row withObjectAtIndex:toIndexPath.row];
    
    newIndex=toIndexPath;
    oldIndex=fromIndexPath;
    
    //
    //MyFavoriteObject *object1=[arrNames objectAtIndex:fromIndexPath.row];
    
    //MyFavoriteObject *object2=[arrNames objectAtIndex:toIndexPath.row];
    
    //
    //[App_Delegate.dbManager updateOrderingOfFavoriteList:object2.ordering oldOrdering:object1.ordering];
    
    //[App_Delegate.dbManager updateOrderingOfFavoriteList:object1.ordering oldOrdering:object2.ordering];
    
    
    //NSLog(@"%d",(int)fromIndexPath.row);
    //NSLog(@"-------->%d",(int)toIndexPath.row);
}

- (void)tableView:(UITableView *)tableView willBeginReorderingRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"begin");
}
- (void)tableView:(UITableView *)tableView didEndReorderingRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    MyFavoriteObject *object1=[arrNames objectAtIndex:newIndex.row];
    
    MyFavoriteObject *object2=[arrNames objectAtIndex:oldIndex.row];
    
    //
    [App_Delegate.dbManager updateOrderingOfFavoriteList:object1.ordering name:object2.strFirstName andGender:object2.strGender];
    
    [App_Delegate.dbManager updateOrderingOfFavoriteList:object2.ordering name:object1.strFirstName andGender:object1.strGender];
    NSLog(@"end reorder");
    
    [table_name performSelector:@selector(reloadData) withObject:nil afterDelay:0.2];
//    [table_name reloadData];
}
- (void)tableView:(UITableView *)tableView didCancelReorderingRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"cancel");
}
-(void)selectName:(UIButton*)sender
{
    CGPoint buttonOrigin = sender.frame.origin;
    CGPoint pointInTableview = [table_name convertPoint:buttonOrigin fromView:sender.superview];
    NSIndexPath *indexPath = [table_name indexPathForRowAtPoint:pointInTableview];
    
    MyFavoriteObject *fav=[arrNames objectAtIndex:indexPath.row];
    
    NSString *strName=fav.strFirstName;
    
    NameDetailVC *name=[[NameDetailVC alloc]init];
    name.strTitle=[strName capitalizedString];
    name.strGenderr=fav.strGender;
    name.isFromFavoriteScreen=YES;
    [self.navigationController pushViewController:name animated:YES];
    
}
-(void)shareFavoriteList
{
    NSString *str1=@"Hej!";
    NSString *str2=@"Här kommer min topplista på namn från Barnnamnsappen! Vad tycker du?";
    NSString *strSubject=@"Min topplista från Barnnamnsappen";
    NSMutableArray *arr=[[NSMutableArray alloc]init];
    for (MyFavoriteObject *obj in arrNames)
    {
        NSString *s=[NSString stringWithFormat:@"• %@",obj.strFirstName];
        [arr addObject:s];
    }
    
    NSString *strFinal=[arr componentsJoinedByString:@"\n"];
    
    NSString *string=[NSString stringWithFormat:@"%@\n\n%@\n\n%@",str1,str2,strFinal];
    
    UIActivityViewController *activityViewController =[[UIActivityViewController alloc] initWithActivityItems:[NSArray arrayWithObject:string]applicationActivities:nil];
    
    [activityViewController setValue:strSubject forKey:@"subject"];
    activityViewController.excludedActivityTypes = [[NSArray alloc] initWithObjects:
                                                    UIActivityTypePostToWeibo,
                                                    UIActivityTypeSaveToCameraRoll,
                                                    UIActivityTypeAssignToContact,
                                                    //UIActivityTypePostToFacebook,
                                                    UIActivityTypePostToTwitter,
                                                    UIActivityTypePostToWeibo,
                                                    //UIActivityTypeMessage,
                                                    //UIActivityTypeMail,
                                                    UIActivityTypePrint,
                                                    UIActivityTypeCopyToPasteboard,
                                                    UIActivityTypeAssignToContact,
                                                    UIActivityTypeSaveToCameraRoll,
                                                    UIActivityTypeAddToReadingList,
                                                    UIActivityTypePostToFlickr,
                                                    UIActivityTypePostToVimeo,
                                                    UIActivityTypePostToTencentWeibo,
                                                    UIActivityTypeAirDrop,
                                                    //UIActivityTypeOpenInIBooks,
                                                    nil];
    
    [self presentViewController:activityViewController animated:YES completion:^{
        
    }];
}
#pragma mark - SMS
#pragma mark -
-(void)sendSMS
{
    NSString *str1=@"Hej!";
    NSString *str2=@"Här kommer min topplista på namn från Barnnamnsappen! Vad tycker du?";
    //NSString *strSubject=@"Min topplista från Barnnamnsappen";
    NSMutableArray *arr=[[NSMutableArray alloc]init];
    for (MyFavoriteObject *obj in arrNames)
    {
        NSString *s=[NSString stringWithFormat:@"• %@",obj.strFirstName];
        [arr addObject:s];
    }
    
    NSString *strFinal=[arr componentsJoinedByString:@"\n"];
    
    //NSString *string=[NSString stringWithFormat:@"%@\n\n%@\n\n%@",str1,str2,strFinal];
    
    //NSString *tempString=@"\nskaffa <a href=\"https://itunes.apple.com/us/app/barnnamnsappen/id1161308570?ls=1&mt=8\">Barnnamnsappen!</a>";
    
    //NSString *yourURL=@"https://itunes.apple.com/us/app/barnnamnsappen/id1161308570?ls=1&mt=8";
    
    NSString *url=@"https://goo.gl/2F8x3P";
    NSString *string=[NSString stringWithFormat:@"%@\n\n%@\n\n%@\n\nSkaffa Barnnamnsappen!<%@>",str1,str2,strFinal,url];
    
    //app store link
    //https://itunes.apple.com/us/app/barnnamnsappen/id1161308570?ls=1&mt=8
    
    if ([MFMessageComposeViewController canSendText])
    {
        MFMessageComposeViewController *controller = [[MFMessageComposeViewController alloc] init];
        if([MFMessageComposeViewController canSendText])
        {
            controller.body = string;
            //controller.recipients = [NSArray arrayWithObjects:@"1(234)567-8910", nil];
            controller.messageComposeDelegate = self;
            [self presentViewController:controller animated:YES completion:^{
                
            }];
        }
    }
    else
    {
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:App_Name message:@"Enheten stöder inte SMS" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];//Your device do not support SMS
        [alert show];
    }
}
- (void)messageComposeViewController:(MFMessageComposeViewController *)controller
                 didFinishWithResult:(MessageComposeResult)result
{
    // Check the result or perform other tasks.
    if (result==MessageComposeResultCancelled)
    {
        NSLog(@"Mail sending cancelled");
    }
    else if(result==MessageComposeResultSent)
    {
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:App_Name message:@"SMS skickas framgångsrikt" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];//SMS sent successfully
        [alert show];
    }
    else if (result==MessageComposeResultFailed)
    {
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:App_Name message:@"SMS-sändning misslyckades" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];//SMS sending failed
        [alert show];
    }
    
    // Dismiss the mail compose view controller.
    [self dismissViewControllerAnimated:YES completion:nil];
}
-(NSString*)shortUrl
{
    NSString *yourURL=@"https://itunes.apple.com/us/app/barnnamnsappen/id1161308570?ls=1&mt=8";
    NSString *urlstr =[yourURL stringByReplacingOccurrencesOfString:@" " withString:@""];///your url string

    NSString *apiEndpoint = [NSString stringWithFormat:@"http://tinyurl.com/api-create.php?url=%@",urlstr];

    
    //NSLog(@"\n\n APIEndPoint : %@",apiEndpoint);
    NSString *shortURL = [NSString stringWithContentsOfURL:[NSURL URLWithString:apiEndpoint]
                                                  encoding:NSASCIIStringEncoding
                                                     error:nil];
    
    //NSLog(@"Long: %@ - Short: %@",urlstr,shortURL);
    return shortURL;
}
#pragma mark - EMAIL
#pragma mark -
-(void)sendEmail
{
    NSString *str1=@"Hej!";
    NSString *str2=@"Här kommer min topplista på namn från Barnnamnsappen! Vad tycker du?";
    NSString *strSubject=@"Min topplista från Barnnamnsappen";
    NSMutableArray *arr=[[NSMutableArray alloc]init];
    for (MyFavoriteObject *obj in arrNames)
    {
        NSString *s=[NSString stringWithFormat:@"<br>• %@",obj.strFirstName];
        [arr addObject:s];
    }
    
    NSString *strFinal=[arr componentsJoinedByString:@"\n"];
    
    //NSString *string=[NSString stringWithFormat:@"%@\n\n%@\n\n%@",str1,str2,strFinal];
    
    NSString *tempString=@"<html><br><br>Skaffa <a href=\"https://itunes.apple.com/us/app/barnnamnsappen/id1161308570?ls=1&mt=8\">Barnnamnsappen!</a></html>";
    NSString *string=[NSString stringWithFormat:@"%@\n\n%@\n\n%@\n%@",str1,str2,strFinal,tempString];
    
    if ([MFMailComposeViewController canSendMail])
    {
        MFMailComposeViewController *picker = [[MFMailComposeViewController alloc] init];
        picker.mailComposeDelegate = self;
        [picker setSubject:strSubject];
        [picker setMessageBody:string isHTML:YES];
        
        //NSString *pdfPath=[NSString stringWithFormat:@"%@/Documents/reports%@",NSHomeDirectory(),App_Delegate.strReportName];
        //NSData *myData = [NSData dataWithContentsOfFile:pdfPath];
        //[picker addAttachmentData:myData mimeType:@"application/pdf" fileName:@"IWBI Report"];
        //[picker setMessageBody:@"Inner West Building Inspection Report" isHTML:NO];
        //NSArray *toRecipients = [NSArray arrayWithObject:[dicValues objectForKey:@"email"]];
        //[picker setToRecipients:toRecipients];
        
        [self presentViewController:picker animated:YES completion:nil];
    }
}
-(void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{
    [controller dismissViewControllerAnimated:YES completion:nil];
    if (result==MFMailComposeResultCancelled)
    {
        NSLog(@"Mail sending cancelled");
    }
    else if(result==MFMailComposeResultSent)
    {
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:App_Name message:@"Post som skickas framgångsrikt" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];//Mail sent successfully
        [alert show];
    }
    else if (result==MFMailComposeResultFailed)
    {
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:App_Name message:@"Post sändning misslyckades" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];//Mail sending failed
        [alert show];
    }
    else if (result==MFMailComposeResultSaved)
    {
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:App_Name message:@"Post sparas utkast" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];//Mail saved to draft
        [alert show];
    }
}
#pragma mark - FB SHARE
#pragma mark -
-(void)shareOnFacebook
{
    NSString *str1=@"Hej!";
    NSString *str2=@"Här kommer min topplista på namn från Barnnamnsappen! Vad tycker du?";
    NSString *strSubject=@"Min topplista från Barnnamnsappen";
    NSMutableArray *arr=[[NSMutableArray alloc]init];
    for (MyFavoriteObject *obj in arrNames)
    {
        NSString *s=[NSString stringWithFormat:@"• %@",obj.strFirstName];
        [arr addObject:s];
    }
    
    NSString *strFinal=[arr componentsJoinedByString:@"\n"];
    
    NSString *string=[NSString stringWithFormat:@"%@\n%@\n\n%@\n\n%@",str1,strSubject,str2,strFinal];
    
    SLComposeViewController *tweetSheet=[SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];
    //     if([SLComposeViewController isAvailableForServiceType:SLServiceTypeTwitter])
    //     {
    SLComposeViewControllerCompletionHandler __block    completionHandler=^(SLComposeViewControllerResult result){
        
        [tweetSheet dismissViewControllerAnimated:YES completion:nil];
        
        switch(result){
            case SLComposeViewControllerResultCancelled:
            default:
            {
                NSLog(@"Cancel");
            }
                break;
            case SLComposeViewControllerResultDone:
            {
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Facebook" message:@"Posted on Facebook Successfully" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                [alert show];
            }
                break;
        }
    };
    //UIImage * image = [UIImage imageWithData:[NSData dataWithContentsOfURL:url]];
    
    [tweetSheet setInitialText:string];
    //[tweetSheet addImage:image];
    [tweetSheet setCompletionHandler:completionHandler];
    [self presentViewController:tweetSheet animated:YES completion:^{
        
    }];
    return;
    
    //
//    FBSDKShareLinkContent *content = [[FBSDKShareLinkContent alloc] init];
//    content.contentURL = nil;//[NSURL URLWithString:@"https://developers.facebook.com"];
//    //content.quote =string;//[NSString stringWithFormat:@"Date: %@\nLocation: %@",strDate,strLocation];
//    content.contentTitle=App_Name;
//    content.contentDescription=string;
//    
//    FBSDKShareDialog *dialog = [[FBSDKShareDialog alloc] init];
//    dialog.fromViewController = self;
//    dialog.shareContent = content;
//    
//    dialog.mode=FBSDKShareDialogModeFeedWeb;
//    dialog.delegate=self;
//    
//
//    
//    //dialog.mode = FBSDKShareDialogModeShareSheet;
//    //dialog.mode = FBSDKShareDialogModeNative; // if you don't set this before canShow call, canShow would always return YES
//    if (![dialog canShow]) {
//        // fallback presentation when there is no FB app
//        dialog.mode = FBSDKShareDialogModeFeedBrowser;
//    }
//    
//    [dialog show];
}
#pragma mark- FBSDK Share delegate
/*
-(void)sharer:(id<FBSDKSharing>)sharer didCompleteWithResults:(NSDictionary *)results
{
    if([results count])
    {
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Facebook" message:@"Post Successfull" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alert show];
    }
    
    //[self hideImagePopUp:viewSocial];
    
    self.tabBarController.tabBar.hidden=NO;
}

-(void)sharer:(id<FBSDKSharing>)sharer didFailWithError:(NSError *)error
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Facebook" message:@"Post Cancelled" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    [alert show];
    
    //[self hideImagePopUp:viewSocial];
    //NSLog(@"error=%@",error);
    self.tabBarController.tabBar.hidden=NO;
}

- (void)sharerDidCancel:(id<FBSDKSharing>)sharer
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Facebook" message:@"Post Cancelled" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    [alert show];
    
    //[self hideImagePopUp:viewSocial];
    
    self.tabBarController.tabBar.hidden=NO;
}
 */
-(NSString*)getGenderOfGivenName:(NSString*)name
{
    NSString *queryString=[NSString stringWithFormat:@"SELECT gender From master_new where name=\"%@\"",name];
    
    NSArray *arrTemp=[App_Delegate.dbManager getRowsForQuery:queryString];
    NSString *str=@"zero";
    if (arrTemp.count>0) {
        NSMutableDictionary *d=[arrTemp firstObject];
        str=[d objectForKey:@"gender"];
    }
    
    if (str ==(id)[NSNull null]) {
        str=@"zero";
    }
    
    return str;
}
 
@end
