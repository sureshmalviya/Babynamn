//
//  NameObject.h
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 7/27/16.
//  Copyright © 2016 Sahid. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NameObject : NSObject

@property(strong,nonatomic)NSString *strName;
@property(strong,nonatomic)NSString *strGender;
@property(strong,nonatomic)NSString *strGender2;
@property(strong,nonatomic)NSString *strOrigin;
@property(strong,nonatomic)NSString *strSyllables;
@property(strong,nonatomic)NSString *strYear;
@property(strong,nonatomic)NSString *strPopularity;
@property(strong,nonatomic)NSString *strInitialChar;
@property(strong,nonatomic)NSMutableArray *arrFamousPeople;
@property(strong,nonatomic)NSMutableArray *arrPopularity;

-(id)initWithDefaults;
+(NSMutableArray*)getTop_Hundred_Gender:(NSString*)gender year:(NSString*)year;

//+(NSMutableArray*)getNameDetails:(NSString*)name;
+(NSMutableArray*)getNameDetails:(NSString*)name andGender:(NSString*)gender;
+(NSMutableArray*)getNamePopularityFromTop100Table:(NSString*)name;

+(NSMutableArray*)getRandomNameFromMasterTable:(BOOL)flag;
+(NSMutableArray*)getNamePopularityFrom_MasterTable:(NSString*)name genderSW:(NSString*)gender;

//+(NSMutableArray*)getAtoZ_NameFrom_MasterTable_initial:(NSString*)initial;
+(NSMutableArray*)getAtoZ_NameFrom_MasterTable_initial:(NSString*)initial andGender:(NSString*)gender;
+(NSMutableArray*)getAllName_MasterTable_query:(NSString*)queryString;
@end
