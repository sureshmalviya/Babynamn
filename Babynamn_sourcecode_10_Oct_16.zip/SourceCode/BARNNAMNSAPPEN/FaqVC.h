//
//  FaqVC.h
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 8/22/16.
//  Copyright © 2016 Sahid. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FaqVC : UIViewController

-(IBAction)btnBackClicked:(UIButton*)sender;

@end
