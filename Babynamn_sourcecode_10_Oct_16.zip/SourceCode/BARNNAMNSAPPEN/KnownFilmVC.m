//
//  KnownFilmVC.m
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 8/1/16.
//  Copyright (c) 2016 Sahid. All rights reserved.
//

#import "KnownFilmVC.h"
#import "SearchResultCell.h"
#import "MyFavouriteVC.h"
#import "NameDetailVC.h"
#import "TvObject.h"
#import "TVSeriesNameDetail.h"

@interface KnownFilmVC ()

@end

@implementation KnownFilmVC
@synthesize strTitle,object_TV,isFromKnownFilms;
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    lblTitle.text=strTitle;
    
    arrNames=[[NSMutableArray alloc]init];//WithObjects:@"Abraham",@"Mohammed",@"Yunus",@"Yakub",@"Aadam",@"Musa",@"Esha",@"Mariyam",@"Aisha",@"Fatima",@"Daood",@"Ismail",@"Abraham",@"Mohammed",@"Yunus",@"Yakub",@"Aadam",@"Musa",@"Esha",@"Mariyam",@"Aisha",@"Fatima",@"Daood",@"Ismail",@"Abraham",@"Mohammed",@"Yunus",@"Yakub",@"Aadam",@"Musa",@"Esha",@"Mariyam",@"Aisha",@"Fatima",@"Daood",@"Ismail", nil];
    
    [self fillInfo];
}
-(void)fillInfo
{
    [btnGender setTitle:@"Alla" forState:UIControlStateNormal];
    
    if (isFromKnownFilms)
    {
        NSMutableArray *arr=[TvObject getNamesFromKnownFilm:btnGender.currentTitle];
        
        arrNames=[App_Delegate sortArray:arr withKey:@"strName" ascending:YES];
    }
    else
    {
        lblTitle.text=object_TV.strTypeName;
        
        NSMutableArray *arr=[TvObject getNamesFromTVSeries_seriesName:object_TV.strTypeName gender:btnGender.currentTitle type:object_TV.strType];
        
        arrNames=[App_Delegate sortArray:arr withKey:@"strName" ascending:YES];
    }
    
    
    [table_names reloadData];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Button Actions
-(IBAction)btnBackClicked:(UIButton*)sender
{
    isFromKnownFilms=NO;
    [self.navigationController popViewControllerAnimated:YES];
}
-(IBAction)btnFavouriteClicked:(UIButton*)sender
{
    if (sender.tag==201)//favorite
    {
        MyFavouriteVC *fav=[[MyFavouriteVC alloc]init];
        [self.navigationController pushViewController:fav animated:YES];
    }
    else if (sender.tag==202)//help
    {
        AboutUSVC *obj=[[AboutUSVC alloc]init];
        [self.navigationController pushViewController:obj animated:YES];
        //NSLog(@"Help Clicked");
    }
}
-(IBAction)btnDropDownClicked:(UIButton*)sender
{
    [self.view endEditing:YES];
    
    NSArray *arr=[[NSArray alloc]initWithObjects:@"Alla",@"Pojke",@"Flicka",nil];
        
        CGFloat listSize = 90;
        if(dropDown == nil)
        {
            dropDown = [[NIDropDown alloc]showDropDown:sender :&listSize :arr :nil :@"down"];
            dropDown.delegate=self;
        }
        else
        {
            [dropDown hideDropDown:sender];
            dropDown = nil;
        }
    
}
#pragma mark - UITableView Delegates
#pragma mark -

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrNames.count;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 30;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *Identifier = @"SearchResultCell";
    
    SearchResultCell *cell = (SearchResultCell*)[tableView dequeueReusableCellWithIdentifier:Identifier];
    
    if(cell==nil)
    {
        NSArray *topLevelObjects = [[NSBundle mainBundle]loadNibNamed:@"SearchResultCell" owner:nil options:nil];
        cell=[topLevelObjects firstObject];
    }
    
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    
    TvObject *name=[arrNames objectAtIndex:indexPath.row];
    NSString *strName=[NSString stringWithFormat:@"%d. %@",(int)indexPath.row+1,name.strName];
    
    cell.lblName.text=strName;
    
    cell.lblName.backgroundColor=[UIColor clearColor];
    cell.backgroundColor=[UIColor clearColor];
    cell.lblName.textColor=[UIColor whiteColor];
    
    if ([btnGender.currentTitle isEqualToString:@"Alla"])
    {
        NSString *str=@"";
        
        if ([name.strGender isEqualToString:sex_Female]) {
            str=[NSString stringWithFormat:@"%@ (F)",strName];
        }else{
            str=[NSString stringWithFormat:@"%@ (P)",strName];
        }
        cell.lblName.text=str;
    }
    else
    {
        cell.lblName.text=strName;
    }
    
    return  cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    TvObject *obj=[arrNames objectAtIndex:indexPath.row];
    
    TVSeriesNameDetail *objTV=[[TVSeriesNameDetail alloc]init];
    objTV.strTitle=obj.strName;
    objTV.tv_object=obj;
    [self.navigationController pushViewController:objTV animated:YES];
}
#pragma mark- Gesture delegate For NiDropDown
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if ([touch.view isDescendantOfView:dropDown])
    {
        return NO;
    }
    
    if ([gestureRecognizer.view isKindOfClass:[UITableView class]])
    {
        return YES;
    }
    
    return YES;
}

- (void) niDropDownDelegateMethod: (NIDropDown *) sender
{
    if (isFromKnownFilms)
    {
        NSMutableArray *arr=[TvObject getNamesFromKnownFilm:btnGender.currentTitle];
        
        arrNames=[App_Delegate sortArray:arr withKey:@"strName" ascending:YES];
    }
    else
    {
        NSMutableArray *arr=[TvObject getNamesFromTVSeries_seriesName:object_TV.strTypeName gender:btnGender.currentTitle type:object_TV.strType];
        
        arrNames=[App_Delegate sortArray:arr withKey:@"strName" ascending:YES];
    }
    [table_names reloadData];
    
    dropDown = nil;
    
}

@end
