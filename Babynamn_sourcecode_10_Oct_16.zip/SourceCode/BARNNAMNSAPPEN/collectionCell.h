//
//  collectionCell.h
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 7/29/16.
//  Copyright (c) 2016 Sahid. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface collectionCell : UICollectionViewCell

@property(strong,nonatomic)IBOutlet UILabel *lblYear;
@property(strong,nonatomic)IBOutlet UILabel *lblPopularity;

@end
