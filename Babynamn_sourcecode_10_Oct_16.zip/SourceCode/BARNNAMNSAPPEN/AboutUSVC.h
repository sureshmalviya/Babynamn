//
//  AboutUSVC.h
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 8/22/16.
//  Copyright © 2016 Sahid. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutUSVC : UIViewController


-(IBAction)btnBackClicked:(UIButton*)sender;
-(IBAction)btnAboutClicked:(UIButton*)sender;

@end
