//
//  BrowseListVC.m
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 7/26/16.
//  Copyright (c) 2016 Sahid. All rights reserved.
//

#import "BrowseListVC.h"
#import "SearchResultCell.h"
#import "MyFavouriteVC.h"
#import "NameDetailVC.h"
#import "NameObject.h"

@interface BrowseListVC ()
{
    BOOL isFirstTime;
}
@end

@implementation BrowseListVC
@synthesize strTitle,isAtoZclicked;
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    lblTitle.text=strTitle;
    
    arrNames=[[NSMutableArray alloc]init];//WithObjects:@"Abraham",@"Mohammed",@"Yunus",@"Yakub",@"Aadam",@"Musa",@"Esha",@"Mariyam",@"Aisha",@"Fatima",@"Daood",@"Ismail",@"Abraham",@"Mohammed",@"Yunus",@"Yakub",@"Aadam",@"Musa",@"Esha",@"Mariyam",@"Aisha",@"Fatima",@"Daood",@"Ismail",@"Abraham",@"Mohammed",@"Yunus",@"Yakub",@"Aadam",@"Musa",@"Esha",@"Mariyam",@"Aisha",@"Fatima",@"Daood",@"Ismail", nil];
    
    //[self fillInfo];
    
    if (isAtoZclicked)
    {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        
        btnAtoZ.hidden=NO;
        imgAtoZ.hidden=NO;
        
        btnYear.hidden=YES;
        imgYear.hidden=YES;
        
        //btnGender.hidden=YES;
        //imgGender.hidden=YES;
        
        [btnGender setTitle:@"Pojke" forState:UIControlStateNormal];
        [btnAtoZ setTitle:@"Alla" forState:UIControlStateNormal];
    }
    else
    {
        btnAtoZ.hidden=YES;
        imgAtoZ.hidden=YES;
        
        btnYear.hidden=NO;
        imgYear.hidden=NO;
        
        //btnGender.hidden=NO;
        //imgGender.hidden=NO;
        
        [btnGender setTitle:@"Pojke" forState:UIControlStateNormal];
        [btnYear setTitle:@"2015" forState:UIControlStateNormal];
    }
}
-(void)viewDidAppear:(BOOL)animated
{
    if (!isFirstTime)
    {
        isFirstTime=YES;
        [self fillInfo];
    }
}
-(void)fillInfo
{
//    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    if (isAtoZclicked)
    {
        NSMutableArray *arr=[NameObject getAtoZ_NameFrom_MasterTable_initial:btnAtoZ.currentTitle andGender:btnGender.currentTitle];
        
        arrNames=[App_Delegate sortArray:arr withKey:@"strName" ascending:YES];
    }
    else
    {
        NSMutableArray *arr=[NameObject getTop_Hundred_Gender:btnGender.currentTitle year:btnYear.currentTitle];
        
        arrNames=[self sortPopularityAscending:arr];
        
        //arrNames=[App_Delegate sortArray:arr withKey:@"strName" ascending:YES];
    }
    
    [table_names reloadData];
    [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
}
-(NSMutableArray*)sortPopularityAscending:(NSMutableArray*)arrayToSort
{
    NSArray *sortedArray=[[NSArray alloc]init];
    
    sortedArray = [arrayToSort sortedArrayUsingComparator:^(NameObject *obj1, NameObject *obj2)
                   {
                       if ([obj1.strPopularity intValue] && [obj2.strPopularity intValue]) {
                           
                           NSNumber *first = [NSNumber numberWithInt:[obj1.strPopularity intValue]];
                           NSNumber *second = [NSNumber numberWithInt:[obj1.strPopularity intValue]];
                           //return [first compare:second];
                           return [second compare:first];
                       }
                       // TODO: default is the same?
                       return (NSComparisonResult)NSOrderedSame;
                   }];
    
    return [sortedArray mutableCopy];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Button Actions
-(IBAction)btnBackClicked:(UIButton*)sender
{
    isAtoZclicked=NO;
    [self.navigationController popViewControllerAnimated:YES];
}
-(IBAction)btnFavouriteClicked:(UIButton*)sender
{
    if (sender.tag==201)//favorite
    {
        MyFavouriteVC *fav=[[MyFavouriteVC alloc]init];
        [self.navigationController pushViewController:fav animated:YES];
    }
    else if (sender.tag==202)//help
    {
        AboutUSVC *obj=[[AboutUSVC alloc]init];
        [self.navigationController pushViewController:obj animated:YES];
        // NSLog(@"Help Clicked");
    }
}
-(IBAction)btnDropDownClicked:(UIButton*)sender
{
    [self.view endEditing:YES];
    if (sender.tag==501)//select year
    {
        NSArray *arr=[[NSArray alloc]initWithObjects:@"2004",@"2005",@"2006",@"2007",@"2008",@"2009",@"2010",@"2011",@"2012",@"2013",@"2014",@"2015",nil];
        CGFloat listSize = 120;
        if(dropDown == nil)
        {
            dropDown = [[NIDropDown alloc]showDropDown:sender :&listSize :arr :nil :@"down"];
            dropDown.delegate=self;
        }
        else
        {
            [dropDown hideDropDown:sender];
            dropDown = nil;
        }

    }
    else if (sender.tag==502)//gender
    {
        NSArray *arr;//=[[NSArray alloc]initWithObjects:@"Pojke",@"Flicka",nil];
        CGFloat listSize = 60;
        
        if (isAtoZclicked)
        {
            arr=[[NSArray alloc]initWithObjects:@"Alla",@"Pojke",@"Flicka",nil];
            listSize = 90;
        }
        else
        {
            arr=[[NSArray alloc]initWithObjects:@"Pojke",@"Flicka",nil];
            listSize = 60;
        }
        
        if(dropDown == nil)
        {
            dropDown = [[NIDropDown alloc]showDropDown:sender :&listSize :arr :nil :@"down"];
            dropDown.delegate=self;
        }
        else
        {
            [dropDown hideDropDown:sender];
            dropDown = nil;
        }
    }
    else if (sender.tag==503)
    {
        NSArray *arr=[[NSArray alloc]initWithObjects:@"Alla",@"A",@"B",@"C",@"D",@"E",@"F",@"G",@"H",@"I",@"J",@"K",@"L",@"M",@"N",@"O",@"P",@"Q",@"R",@"S",@"T",@"U",@"V",@"W",@"X",@"Y",@"Z",@"Å",@"Ä",@"Ö",nil];
        
        CGFloat listSize = 150;
        if(dropDown == nil)
        {
            dropDown = [[NIDropDown alloc]showDropDown:sender :&listSize :arr :nil :@"down"];
            dropDown.delegate=self;
        }
        else
        {
            [dropDown hideDropDown:sender];
            dropDown = nil;
        }
    }
}
#pragma mark - UITableView Delegates
#pragma mark -

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrNames.count;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 30;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *Identifier = @"SearchResultCell";
    
    SearchResultCell *cell = (SearchResultCell*)[tableView dequeueReusableCellWithIdentifier:Identifier];
    
    if(cell==nil)
    {
        NSArray *topLevelObjects = [[NSBundle mainBundle]loadNibNamed:@"SearchResultCell" owner:nil options:nil];
        cell=[topLevelObjects firstObject];
    }
    
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    
    NameObject *name=[arrNames objectAtIndex:indexPath.row];
    
    NSString *strName=[NSString stringWithFormat:@"%d. %@",(int)indexPath.row+1,name.strName];
    //NSString *strName=[NSString stringWithFormat:@"%@, popularity = %@",name.strName,name.strPopularity];
    
    cell.lblName.text=strName;
    
    cell.lblName.backgroundColor=[UIColor clearColor];
    cell.backgroundColor=[UIColor clearColor];
    cell.lblName.textColor=[UIColor whiteColor];
    
    /*
    cell.lblPopularity.text=name.strPopularity;
    cell.lblPopularity.layer.cornerRadius=8.0;
    [cell.lblPopularity setClipsToBounds:YES];
    cell.lblPopularity.backgroundColor=[UIColor colorWithRed:189/255.0 green:251/255.0 blue:255/255.0 alpha:1];
    if (isAtoZclicked){
        cell.lblPopularity.hidden=YES;
    }else{
        cell.lblPopularity.hidden=NO;
    }
    */
    if (isAtoZclicked && [btnGender.currentTitle isEqualToString:@"Alla"])
    {
        NSString *str=@"";
        
        if ([name.strGender isEqualToString:sex_Female]) {
            str=[NSString stringWithFormat:@"%@ (F)",strName];
        }else{
            str=[NSString stringWithFormat:@"%@ (P)",strName];
        }
        cell.lblName.text=str;
    }
    else
    {
        cell.lblName.text=strName;
    }
    
    return  cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NameObject *obj=[arrNames objectAtIndex:indexPath.row];
    
    if (isAtoZclicked)
    {
        NameDetailVC *objName=[[NameDetailVC alloc]init];
        objName.strTitle=obj.strName;
        objName.strGenderr=obj.strGender;
        objName.isFromTopHundred=NO;
        [self.navigationController pushViewController:objName animated:YES];
    }
    else
    {
        NameDetailVC *objName=[[NameDetailVC alloc]init];
        objName.strTitle=obj.strName;
        objName.strGenderr=obj.strGender;
        objName.isFromTopHundred=YES;
        [self.navigationController pushViewController:objName animated:YES];
    }
    
    
}
#pragma mark- Gesture delegate For NiDropDown
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if ([touch.view isDescendantOfView:dropDown])
    {
        return NO;
    }
    
    if ([gestureRecognizer.view isKindOfClass:[UITableView class]])
    {
        return YES;
    }
    
    return YES;
}

- (void) niDropDownDelegateMethod: (NIDropDown *) sender
{
//    [sender removeFromSuperview];
    
    if (isAtoZclicked)
    {
        NSMutableArray *arr=[NameObject getAtoZ_NameFrom_MasterTable_initial:btnAtoZ.currentTitle andGender:btnGender.currentTitle];
        
        arrNames=[App_Delegate sortArray:arr withKey:@"strName" ascending:YES];
    }
    else
    {
        NSMutableArray *arr=[NameObject getTop_Hundred_Gender:btnGender.currentTitle year:btnYear.currentTitle];
        
        arrNames=[self sortPopularityAscending:arr];
        //arrNames=[App_Delegate sortArray:arr withKey:@"strName" ascending:YES];
    }
    [table_names reloadData];
    [table_names setContentOffset:CGPointMake(0, 0)];
    
    dropDown = nil;
    
}

@end
