//
//  TvObject.h
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 8/1/16.
//  Copyright (c) 2016 Sahid. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TvObject : NSObject

@property(strong,nonatomic)NSString *strName;
@property(strong,nonatomic)NSString *strGender;
@property(strong,nonatomic)NSString *strType;
@property(strong,nonatomic)NSString *strTypeName;
@property(strong,nonatomic)NSString *strCountry;

-(id)initWithDefaults;
+(NSMutableArray*)getNamesFromKnownFilm:(NSString*)gender;
+(NSMutableArray*)getTvSeriesName_Country:(NSString*)country type:(NSString*)type;


+(NSMutableArray*)getNamesFromTVSeries_seriesName:(NSString*)seriesName gender:(NSString*)gender type:(NSString*)type;
@end
