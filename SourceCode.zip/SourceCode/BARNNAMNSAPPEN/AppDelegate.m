//
//  AppDelegate.m
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 7/25/16.
//  Copyright (c) 2016 Sahid. All rights reserved.
//

#import "AppDelegate.h"
#import "HomeVC.h"
#import "SplashVC.h"
#import <FBSDKCoreKit/FBSDKCoreKit.h>
@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    // Override point for customization after application launch.
    self.window=[[UIWindow alloc]initWithFrame:[[UIScreen mainScreen]bounds]];
    self.window.backgroundColor=[UIColor whiteColor];
    [self.window makeKeyAndVisible];

    SplashVC *objHomeScreen=[[SplashVC alloc]init];
    UINavigationController *nav=[[UINavigationController alloc]initWithRootViewController:objHomeScreen];
    self.window.rootViewController=nav;
    nav.navigationBarHidden=YES;
    
    //Database
    dbName=@"baby.sqlite";
    self.dbPath=[self getDBPath:dbName];
    NSLog(@"DBPath:%@",self.dbPath);
    [self copyDatabaseFromApplicationBundleIfNeeded];
    self.dbManager = [[SQLiteManager alloc] initWithDatabaseNamed:dbName];
    
    [self.dbManager openDatabase];
    
    [[FBSDKApplicationDelegate sharedInstance] application:application
                             didFinishLaunchingWithOptions:launchOptions];
    
    return YES;
}

- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url
  sourceApplication:(NSString *)sourceApplication annotation:(id)annotation {
    
    BOOL handled = [[FBSDKApplicationDelegate sharedInstance] application:application
                                                                  openURL:url
                                                        sourceApplication:sourceApplication
                                                               annotation:annotation
                    ];
    // Add any custom logic here.
    return handled;
}
#pragma mark - Database Methods
#pragma mark -
- (NSString *)getDBPath :(NSString *)fileName
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    NSString *documentsDir = [paths objectAtIndex:0];
    return [documentsDir stringByAppendingPathComponent:fileName];
}

-(void)copyDatabaseFromApplicationBundleIfNeeded
{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    Boolean success = [fileManager fileExistsAtPath:self.dbPath];
    if(success)
        return;
    
    NSString *databasePathFromApp = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:dbName];
    [fileManager copyItemAtPath:databasePathFromApp toPath:self.dbPath error:nil];
}
#pragma mark - Other Methods
#pragma mark -
-(NSMutableArray *)sortArray:(NSMutableArray*)inputArray withKey:(NSString*)key ascending:(BOOL)order
{
    NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:key
                                                                     ascending:order
                                                                      selector:@selector(caseInsensitiveCompare:)];//[[NSSortDescriptor alloc] initWithKey:key ascending:order];
    
    NSArray *sortDescriptors = [NSArray arrayWithObject:sortDescriptor];
    NSArray *ary = [inputArray sortedArrayUsingDescriptors:sortDescriptors];
    
    return [ary mutableCopy];
}
-(void)showPopup:(UIView*)vu OnView:(UIView*)parentView
{
    //Set Animation
    vu.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.1, 0.1);
    vu.alpha=0;
    
    [UIView animateWithDuration:0.2  animations:^{
        vu.transform = CGAffineTransformScale(CGAffineTransformIdentity, 1, 1);
        vu.alpha=1;
        
        [parentView addSubview:vu];
    }];
}
-(void)hidePopup:(UIView*)vu fromView:(UIView*)parentView
{
    //Set Animation
    [UIView animateWithDuration:0.2 animations:^{
        vu.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.1, 0.1);
        vu.alpha=0.1;
        
    } completion:^(BOOL finished) {
        [vu removeFromSuperview];
    }];
}
-(BOOL)isStringEmpty:(NSString*)str
{
    BOOL isEmpty=YES;
    
    if ([[str stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] length]>0)
    {
        isEmpty=NO;
    }
    
    return isEmpty;
}
- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    [FBSDKAppEvents activateApp];
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
