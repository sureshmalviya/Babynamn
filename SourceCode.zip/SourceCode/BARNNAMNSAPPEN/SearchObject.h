//
//  SearchObject.h
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 7/27/16.
//  Copyright © 2016 Sahid. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SearchObject : NSObject

@property(strong,nonatomic)NSString *strGender;
@property(strong,nonatomic)NSString *strCountry;
@property(strong,nonatomic)NSString *strSyllables;
@property(strong,nonatomic)NSString *strBeginsWith;
@property(strong,nonatomic)NSString *strPopularity;

-(id)initWithDefaults;
@end
