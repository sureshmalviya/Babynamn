//
//  NameObject.m
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 7/27/16.
//  Copyright © 2016 Sahid. All rights reserved.
//

#import "NameObject.h"

@implementation NameObject
@synthesize strGender,strGender2,strInitialChar,strName,strOrigin,strPopularity,strSyllables,strYear,arrFamousPeople,arrPopularity;

-(id)initWithDefaults
{
    strName =@"";
    strGender =@"";
    strGender2 =@"";
    strOrigin =@"";
    strSyllables =@"";
    strYear =@"";
    strPopularity =@"";
    strInitialChar =@"";
    arrFamousPeople =[[NSMutableArray alloc]init];
    arrPopularity =[[NSMutableArray alloc]init];
    
    return self;
}
+(NSMutableArray*)getTop_Hundred_Gender:(NSString*)gender year:(NSString*)year
{
    NSMutableArray *arrTop100=[[NSMutableArray alloc]init];
    
    if ([gender isEqualToString:@"Pojke"])
    {
        gender=sex_Male;
    }
    else if ([gender isEqualToString:@"Flicka"])
    {
        gender=sex_Female;
    }
    
    NSString *queryString;
    
    if ([gender isEqualToString:@"SEX"] && [year isEqualToString:@"YEAR"])
    {
        queryString=[NSString stringWithFormat:@"SELECT * from \"%@\" GROUP BY name ",TABLE_TOP100];
    }
    else if ([gender isEqualToString:@"SEX"])
    {
        queryString=[NSString stringWithFormat:@"SELECT * from \"%@\" WHERE year=\"%@\" GROUP BY name",TABLE_TOP100,year];
    }
    else if ([gender isEqualToString:@"YEAR"])
    {
        queryString=[NSString stringWithFormat:@"SELECT * from \"%@\" WHERE gender=\"%@\" GROUP BY name",TABLE_TOP100,gender];
    }
    else
    {
        queryString=[NSString stringWithFormat:@"SELECT * from \"%@\" WHERE gender=\"%@\" AND year=\"%@\"",TABLE_TOP100,gender,year];
    }
    
    
    NSMutableArray *arrTemp=[[NSMutableArray alloc]init];
    arrTemp=(NSMutableArray*)[App_Delegate.dbManager getRowsForQuery:queryString];
    
    for (NSMutableDictionary *dic in arrTemp)
    {
        NameObject *name=[[NameObject alloc]initWithDefaults];
        
        name.strName = [dic objectForKey:DB_NAME];
        name.strGender =[dic objectForKey:DB_GENDER];
        name.strGender2 =[dic objectForKey:DB_GENDER_SWEEDIS];
        name.strOrigin =[dic objectForKey:DB_ORIGIN];
        name.strSyllables =[dic objectForKey:DB_SYLLABLES];
        name.strYear =[dic objectForKey:DB_YEAR];
        name.strPopularity =[dic objectForKey:DB_COUNT];
        name.strInitialChar =[dic objectForKey:DB_INITIAL];
        name.arrFamousPeople =[[NSMutableArray alloc]init];
        name.arrPopularity =[[NSMutableArray alloc]init];
        
        [arrTop100 addObject:name];
    }

    return arrTop100;
}

+(NSMutableArray*)getNameDetails:(NSString*)name andGender:(NSString*)gender
{
    NSMutableArray *arrName=[[NSMutableArray alloc]init];
    NSString *sex;
    NSString *queryString;
    if ([gender isEqualToString:@"FEMALE"]) {
        sex=sex_Female;
    }else if([gender isEqualToString:@"MALE"]){
        sex=sex_Male;
    }else{
        sex=@"zero";
    }
    
    if ([sex isEqualToString:@"zero"])
    {
        queryString=[NSString stringWithFormat:@"SELECT * from \"%@\" WHERE name=\"%@\"",TABLE_MASTER,name];
    }
    else
    {
        queryString=[NSString stringWithFormat:@"SELECT * from \"%@\" WHERE name=\"%@\" AND gender=\"%@\"",TABLE_MASTER,name,sex];
    }
    
    
    NSMutableArray *arrTemp=[[NSMutableArray alloc]init];
    arrTemp=(NSMutableArray*)[App_Delegate.dbManager getRowsForQuery:queryString];
    
    for (NSMutableDictionary *dic in arrTemp)
    {
        NameObject *name=[[NameObject alloc]initWithDefaults];
        
        name.strName = [dic objectForKey:DB_NAME];
        name.strGender =[dic objectForKey:DB_GENDER];
        name.strGender2 =[dic objectForKey:DB_GENDER_SWEEDIS];
        name.strOrigin =[dic objectForKey:DB_ORIGIN];
        name.strSyllables =[dic objectForKey:DB_SYLLABLES];
        name.strYear =[dic objectForKey:DB_YEAR];
        name.strPopularity =[dic objectForKey:DB_COUNT];
        name.strInitialChar =[dic objectForKey:DB_INITIAL];
        name.arrFamousPeople =[[NSMutableArray alloc]init];
        name.arrPopularity =[[NSMutableArray alloc]init];
        
        [arrName addObject:name];
    }
    
    return arrName;
}
+(NSMutableArray*)getNamePopularityFromTop100Table:(NSString*)name
{
    NSMutableArray *arrName=[[NSMutableArray alloc]init];
    
    NSString *queryString=[NSString stringWithFormat:@"SELECT * FROM top_hundred where name=\"%@\"",name];
    
    NSMutableArray *arrTemp=[[NSMutableArray alloc]init];
    arrTemp=(NSMutableArray*)[App_Delegate.dbManager getRowsForQuery:queryString];
    
    for (NSMutableDictionary *dic in arrTemp)
    {
        NameObject *name=[[NameObject alloc]initWithDefaults];
        
        name.strName = [dic objectForKey:DB_NAME];
        name.strGender =[dic objectForKey:DB_GENDER];
        name.strGender2 =[dic objectForKey:DB_GENDER_SWEEDIS];
        name.strOrigin =[dic objectForKey:DB_ORIGIN];
        name.strSyllables =[dic objectForKey:DB_SYLLABLES];
        name.strYear =[dic objectForKey:DB_YEAR];
        name.strPopularity =[dic objectForKey:DB_COUNT];
        name.strInitialChar =[dic objectForKey:DB_INITIAL];
        name.arrFamousPeople =[[NSMutableArray alloc]init];
        name.arrPopularity =[[NSMutableArray alloc]init];
        
        [arrName addObject:name];
    }
    
    return arrName;
}
+(NSMutableArray*)getRandomNameFromMasterTable:(BOOL)flag
{
    NSMutableArray *arrName=[[NSMutableArray alloc]init];
    
    //NSString *queryString=[NSString stringWithFormat:@"SELECT * FROM master ORDER BY random() limit 1"];
    
    NSString *gender;
    if (flag){
        gender=sex_Male;
    }else{
        gender=sex_Female;
    }
    NSString *queryString=[NSString stringWithFormat:@"SELECT DISTINCT name,gender,gender2,lang_origin FROM master_new WHERE gender=\"%@\" order by random() limit 1",gender];
    
    //NSString *queryString=[NSString stringWithFormat:@"SELECT DISTINCT name,gender,gender2,lang_origin FROM master_new order by random() limit 1"];
    
    NSMutableArray *arrTemp=[[NSMutableArray alloc]init];
    arrTemp=(NSMutableArray*)[App_Delegate.dbManager getRowsForQuery:queryString];
    
    for (NSMutableDictionary *dic in arrTemp)
    {
        NameObject *name=[[NameObject alloc]initWithDefaults];
        
        name.strName = [dic objectForKey:DB_NAME];
        name.strGender =[dic objectForKey:DB_GENDER];
        name.strGender2 =[dic objectForKey:DB_GENDER_SWEEDIS];
        name.strOrigin =[dic objectForKey:DB_ORIGIN];
        name.strSyllables =[dic objectForKey:DB_SYLLABLES];
        name.strYear =[dic objectForKey:DB_YEAR];
        
        int p=[[dic objectForKey:DB_COUNT] intValue];
        name.strPopularity =[NSString stringWithFormat:@"%d",p];
        
        name.strInitialChar =[dic objectForKey:DB_INITIAL];
        name.arrFamousPeople =[[NSMutableArray alloc]init];
        name.arrPopularity =[[NSMutableArray alloc]init];
        
        [arrName addObject:name];
    }
    
    return arrName;
}
+(NSMutableArray*)getNamePopularityFrom_MasterTable:(NSString*)name genderSW:(NSString*)gender
{
    NSMutableArray *arrName=[[NSMutableArray alloc]init];
    
    NSString *queryString=[NSString stringWithFormat:@"SELECT * FROM master_new WHERE name=\"%@\" AND gender=\"%@\" GROUP BY year",name,gender];
    
    if ([App_Delegate isStringEmpty:gender])
    {
        queryString=[NSString stringWithFormat:@"SELECT * FROM master_new WHERE name=\"%@\" GROUP BY year",name];
    }
    
    NSMutableArray *arrTemp=[[NSMutableArray alloc]init];
    arrTemp=(NSMutableArray*)[App_Delegate.dbManager getRowsForQuery:queryString];
    
    for (NSMutableDictionary *dic in arrTemp)
    {
        NameObject *name=[[NameObject alloc]initWithDefaults];
        
        name.strName = [dic objectForKey:DB_NAME];
        name.strGender =[dic objectForKey:DB_GENDER];
        name.strGender2 =[dic objectForKey:DB_GENDER_SWEEDIS];
        name.strOrigin =[dic objectForKey:DB_ORIGIN];
        name.strSyllables =[dic objectForKey:DB_SYLLABLES];
        name.strYear =[dic objectForKey:DB_YEAR];
        
        int p=[[dic objectForKey:DB_COUNT] intValue];
        name.strPopularity =[NSString stringWithFormat:@"%d",p];
        
        name.strInitialChar =[dic objectForKey:DB_INITIAL];
        name.arrFamousPeople =[[NSMutableArray alloc]init];
        name.arrPopularity =[[NSMutableArray alloc]init];
        
        [arrName addObject:name];
    }
    
    return arrName;
}
+(NSMutableArray*)getAtoZ_NameFrom_MasterTable_initial:(NSString*)initial andGender:(NSString*)gender
{
    NSMutableArray *arrName=[[NSMutableArray alloc]init];
    
    NSString *queryString;
    
    NSString *sex;
    if ([gender isEqualToString:@"Flicka"]){
        sex=sex_Female;
    }else{
        sex=sex_Male;
    }
    
    if ([initial isEqualToString:@"Alla"] && [gender isEqualToString:@"Alla"])
    {
        queryString=[NSString stringWithFormat:@"SELECT * FROM master_new group by name"];
    }
    else if ([initial isEqualToString:@"Alla"])
    {
        queryString=[NSString stringWithFormat:@"SELECT * FROM master_new WHERE gender=\"%@\" group by name",sex];
    }
    else
    {
        queryString=[NSString stringWithFormat:@"SELECT * FROM master_new WHERE initial=\"%@\" AND gender=\"%@\" group by name",initial,sex];
    }
    
    
    NSMutableArray *arrTemp=[[NSMutableArray alloc]init];
    arrTemp=(NSMutableArray*)[App_Delegate.dbManager getRowsForQuery:queryString];
    
    for (NSMutableDictionary *dic in arrTemp)
    {
        NameObject *name=[[NameObject alloc]initWithDefaults];
        
        name.strName = [dic objectForKey:DB_NAME];
        name.strGender =[dic objectForKey:DB_GENDER];
        name.strGender2 =[dic objectForKey:DB_GENDER_SWEEDIS];
        name.strOrigin =[dic objectForKey:DB_ORIGIN];
        name.strSyllables =[dic objectForKey:DB_SYLLABLES];
        name.strYear =[dic objectForKey:DB_YEAR];

        int p=[[dic objectForKey:DB_COUNT] intValue];
        name.strPopularity =[NSString stringWithFormat:@"%d",p];
        
        name.strInitialChar =[dic objectForKey:DB_INITIAL];
        name.arrFamousPeople =[[NSMutableArray alloc]init];
        name.arrPopularity =[[NSMutableArray alloc]init];
        
        [arrName addObject:name];
    }
    
    return arrName;
}
+(NSMutableArray*)getAllName_MasterTable_query:(NSString*)queryString
{
    NSMutableArray *arrName=[[NSMutableArray alloc]init];
    
    //NSString *queryString=[NSString stringWithFormat:@"SELECT * FROM master WHERE name=\"%@\" AND gender=\"%@\" GROUP BY year",name,gender];
    
//    if ([App_Delegate isStringEmpty:gender])
//    {
//        queryString=[NSString stringWithFormat:@"SELECT * FROM master WHERE name=\"%@\" GROUP BY year",name];
//    }
    
    NSMutableArray *arrTemp=[[NSMutableArray alloc]init];
    arrTemp=(NSMutableArray*)[App_Delegate.dbManager getRowsForQuery:queryString];
    
    for (NSMutableDictionary *dic in arrTemp)
    {
        NameObject *name=[[NameObject alloc]initWithDefaults];
        
        name.strName = [dic objectForKey:DB_NAME];
        name.strGender =[dic objectForKey:DB_GENDER];
        name.strGender2 =[dic objectForKey:DB_GENDER_SWEEDIS];
        name.strOrigin =[dic objectForKey:DB_ORIGIN];
        name.strSyllables =[dic objectForKey:DB_SYLLABLES];
        name.strYear =[dic objectForKey:DB_YEAR];

        int p=[[dic objectForKey:DB_COUNT] intValue];
        name.strPopularity =[NSString stringWithFormat:@"%d",p];
        
        name.strInitialChar =[dic objectForKey:DB_INITIAL];
        name.arrFamousPeople =[[NSMutableArray alloc]init];
        name.arrPopularity =[[NSMutableArray alloc]init];
        
        [arrName addObject:name];
    }
    
    return arrName;
}
@end
