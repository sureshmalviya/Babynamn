//
//  SearchObject.m
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 7/27/16.
//  Copyright © 2016 Sahid. All rights reserved.
//

#import "SearchObject.h"

@implementation SearchObject
@synthesize strBeginsWith,strCountry,strGender,strPopularity,strSyllables;

-(id)initWithDefaults
{
    strGender = @"";
    strCountry = @"";
    strSyllables = @"";
    strBeginsWith = @"";
    strPopularity = @"";
    
    return self;
}

@end
