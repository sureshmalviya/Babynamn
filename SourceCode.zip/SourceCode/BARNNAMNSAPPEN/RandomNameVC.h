//
//  RandomNameVC.h
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 7/30/16.
//  Copyright (c) 2016 Sahid. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NameObject.h"
@interface RandomNameVC : UIViewController<UICollectionViewDataSource,UICollectionViewDelegate>
{
    IBOutlet UILabel *lblTitle;
    IBOutlet UILabel *lblGender;
    IBOutlet UILabel *lblCountry;
    IBOutlet UILabel *lblFamousPeople;
    
    IBOutlet UIView *viewCountry;
    IBOutlet UIView *viewFamousPeople;
    IBOutlet UIView *viewPopularity;
    
    IBOutlet UILabel *lblName;
    
    IBOutlet UIButton *btnRandomizeMale;
    IBOutlet UIButton *btnRandomizeFemale;
    
    NameObject *object_Name;
    IBOutlet UICollectionView *collectionVu;
    
    NSMutableArray *arrPopularity;
    
    IBOutlet UILabel *lblPopularityTitle;
    
    IBOutlet UIScrollView *scrollBG;
}

@property(strong,nonatomic)NSString *strTitle;
-(IBAction)btnBackClicked:(UIButton*)sender;
-(IBAction)btnFavouriteClicked:(UIButton*)sender;
-(IBAction)btnAddFavClicked:(UIButton*)sender;
-(IBAction)btnRandomizeAgain:(UIButton*)sender;


@end
