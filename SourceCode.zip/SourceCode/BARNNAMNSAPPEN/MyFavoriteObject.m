//
//  MyFavoriteObject.m
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 7/30/16.
//  Copyright (c) 2016 Sahid. All rights reserved.
//

#import "MyFavoriteObject.h"

@implementation MyFavoriteObject
@synthesize strFirstName,strLastName,strGender,ordering;

-(id)initWithDefaults
{
    strFirstName=@"";
    strLastName=@"";
    strGender=@"zero";
    ordering=0;
    
    return self;
}

@end
