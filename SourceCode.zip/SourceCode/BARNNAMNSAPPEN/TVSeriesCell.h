//
//  TVSeriesCell.h
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 8/1/16.
//  Copyright (c) 2016 Sahid. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TVSeriesCell : UITableViewCell

@property(strong,nonatomic)IBOutlet UIImageView *imgTitle;
@property(strong,nonatomic)IBOutlet UILabel *lblTitle;
@end
