//
//  collectionCell.m
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 7/29/16.
//  Copyright (c) 2016 Sahid. All rights reserved.
//

#import "collectionCell.h"

@implementation collectionCell

- (void)awakeFromNib {
    // Initialization code
}

@end
