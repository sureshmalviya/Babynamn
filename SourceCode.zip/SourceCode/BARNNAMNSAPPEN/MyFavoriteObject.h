//
//  MyFavoriteObject.h
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 7/30/16.
//  Copyright (c) 2016 Sahid. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyFavoriteObject : NSObject

@property(strong,nonatomic)NSString *strFirstName;
@property(strong,nonatomic)NSString *strLastName;
@property(strong,nonatomic)NSString *strGender;
@property int ordering;

-(id)initWithDefaults;
@end
