//
//  FavoriteCell.m
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 7/27/16.
//  Copyright © 2016 Sahid. All rights reserved.
//

#import "FavoriteCell.h"

@implementation FavoriteCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
