//
//  KnownFilmVC.h
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 8/1/16.
//  Copyright (c) 2016 Sahid. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NIDropDown.h"
#import "TvObject.h"
@interface KnownFilmVC : UIViewController<UITableViewDataSource,UITabBarDelegate,NIDropDownDelegate>
{
    NIDropDown *dropDown;
    
    IBOutlet UIButton *btnGender;
    IBOutlet UITableView *table_names;
    
    IBOutlet UILabel *lblTitle;
    
    NSMutableArray *arrNames;
}
@property(strong,nonatomic)NSString *strTitle;
@property(strong,nonatomic)TvObject *object_TV;
@property BOOL isFromKnownFilms;
-(IBAction)btnBackClicked:(UIButton*)sender;
-(IBAction)btnFavouriteClicked:(UIButton*)sender;
-(IBAction)btnDropDownClicked:(UIButton*)sender;

@end
