//
//  MyFavouriteVC.h
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 7/26/16.
//  Copyright (c) 2016 Sahid. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HPReorderTableView.h"

@interface MyFavouriteVC : UIViewController<UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate,UIAlertViewDelegate,MFMailComposeViewControllerDelegate,HPReorderTableViewDelegate,MFMessageComposeViewControllerDelegate>
{
    IBOutlet HPReorderTableView *table_name;
    
    NSMutableArray *arrNames;
    
    IBOutlet UIView *viewPopup;
    IBOutlet UITextField *txtLastName;
    
    IBOutlet UIView *viewSharePopup;
 
    IBOutlet UIView *viewFavPopup;
    IBOutlet UITextField *txtFavName;
    
    IBOutlet UIButton *btnEnterLastName;
    IBOutlet UIButton *btnRemoveLastName;
    
    int indexToDelete;
}
-(IBAction)btnBackClicked:(UIButton*)sender;
-(IBAction)btnAddFavClicked:(UIButton*)sender;
-(IBAction)btnEnterLastName:(UIButton*)sender;

-(IBAction)btnDonePopup:(UIButton*)sender;

-(IBAction)btnSocialSharing:(UIButton*)sender;
@end
