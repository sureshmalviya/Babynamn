//
//  NameDetailVC.h
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 7/26/16.
//  Copyright (c) 2016 Sahid. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NameObject.h"

@interface NameDetailVC : UIViewController<UICollectionViewDataSource,UICollectionViewDelegate>
{
    IBOutlet UILabel *lblTitle;
    IBOutlet UILabel *lblGender;
    IBOutlet UILabel *lblCountry;
    IBOutlet UILabel *lblFamousPeople;
    
    IBOutlet UIView *viewGender;
    IBOutlet UIView *viewCountry;
    IBOutlet UIView *viewFamousPeople;
    IBOutlet UIView *viewPopularity;
    
    IBOutlet UILabel *lblName;
    
    IBOutlet UIButton *btnRandomizeAgain;
    
    IBOutlet UILabel *lbl4;
    IBOutlet UILabel *lbl5;
    IBOutlet UILabel *lbl6;
    IBOutlet UILabel *lbl7;
    IBOutlet UILabel *lbl8;
    IBOutlet UILabel *lbl9;
    IBOutlet UILabel *lbl10;
    IBOutlet UILabel *lbl11;
    IBOutlet UILabel *lbl12;
    IBOutlet UILabel *lbl13;
    IBOutlet UILabel *lbl14;
    IBOutlet UILabel *lbl15;
    
    NameObject *object_Name;
    IBOutlet UICollectionView *collectionVu;
    
    NSMutableArray *arrPopularity;
    
    IBOutlet UILabel *lblPopularityTitle;
    
    IBOutlet UIScrollView *scrollBG;
    
    IBOutlet UITextView *txtCountry;
}
@property BOOL isFromFavoriteScreen;

@property BOOL isFromTopHundred;

@property(strong,nonatomic)NSString *strTitle;
@property(strong,nonatomic)NSString *strGenderr;
-(IBAction)btnBackClicked:(UIButton*)sender;
-(IBAction)btnFavouriteClicked:(UIButton*)sender;
-(IBAction)btnAddFavClicked:(UIButton*)sender;
-(IBAction)btnRandomizeAgain:(UIButton*)sender;
@end
