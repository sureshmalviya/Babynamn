//
//  FavoriteCell.h
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 7/27/16.
//  Copyright © 2016 Sahid. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FavoriteCell : UITableViewCell

@property(strong,nonatomic)IBOutlet UILabel *lblName;
@property(strong,nonatomic)IBOutlet UIButton *btnDelete;
@property(strong,nonatomic)IBOutlet UIButton *btnMove;

@property(strong,nonatomic)IBOutlet UIButton *btnSelectName;

@end
