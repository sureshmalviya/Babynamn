//
//  TvObject.m
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 8/1/16.
//  Copyright (c) 2016 Sahid. All rights reserved.
//

#import "TvObject.h"

@implementation TvObject
@synthesize strName,strGender,strType,strTypeName,strCountry;

-(id)initWithDefaults
{
    strName = @"";
    strGender = @"";
    strType = @"";
    strTypeName = @"";
    strCountry = @"";
    
    return self;
}
+(NSMutableArray*)getNamesFromKnownFilm:(NSString*)gender
{
    NSMutableArray *arrName=[[NSMutableArray alloc]init];
    
    NSString *queryString;
    if ([gender isEqualToString:@"Alla"])
    {
        queryString=[NSString stringWithFormat:@"SELECT * from tv_series WHERE type='MOVIE'"];
    }
    else if ([gender isEqualToString:@"Pojke"])
    {
        queryString=[NSString stringWithFormat:@"SELECT * from tv_series WHERE type='MOVIE' AND gender='MALE'"];
    }
    else if ([gender isEqualToString:@"Flicka"])
    {
        queryString=[NSString stringWithFormat:@"SELECT * from tv_series WHERE type='MOVIE' AND gender='FEMALE'"];
    }
    
    
    NSMutableArray *arrTemp=[[NSMutableArray alloc]init];
    arrTemp=(NSMutableArray*)[App_Delegate.dbManager getRowsForQuery:queryString];
    
    for (NSMutableDictionary *dic in arrTemp)
    {
        TvObject *name=[[TvObject alloc]initWithDefaults];
        
        name.strName = [dic objectForKey:DB_NAME];
        name.strGender = [dic objectForKey:DB_GENDER];
        name.strType = [dic objectForKey:DB_TYPE];
        name.strTypeName = [dic objectForKey:DB_TYPE_NAME];
        name.strCountry = [dic objectForKey:DB_COUNTRY];
        
        if (name.strName ==(id)[NSNull null]) {
            continue;
        }
        
        [arrName addObject:name];
    }
    
    return arrName;
}
+(NSMutableArray*)getTvSeriesName_Country:(NSString*)country type:(NSString*)type
{
    NSMutableArray *arrName=[[NSMutableArray alloc]init];
    
    NSString *queryString;
    if ([country isEqualToString:COUNTRY_USA])
    {
        queryString=[NSString stringWithFormat:@"SELECT * from tv_series WHERE type=\"%@\" AND country=\"%@\" group by type_name",type,COUNTRY_USA];
    }
    else if ([country isEqualToString:COUNTRY_SWEDEN])
    {
        queryString=[NSString stringWithFormat:@"SELECT * from tv_series WHERE type=\"%@\" AND country=\"%@\" group by type_name",type,COUNTRY_SWEDEN];
    }
    
    
    NSMutableArray *arrTemp=[[NSMutableArray alloc]init];
    arrTemp=(NSMutableArray*)[App_Delegate.dbManager getRowsForQuery:queryString];
    
    for (NSMutableDictionary *dic in arrTemp)
    {
        TvObject *name=[[TvObject alloc]initWithDefaults];
        
        name.strName = [dic objectForKey:DB_NAME];
        name.strGender = [dic objectForKey:DB_GENDER];
        name.strType = [dic objectForKey:DB_TYPE];
        name.strTypeName = [dic objectForKey:DB_TYPE_NAME];
        name.strCountry = [dic objectForKey:DB_COUNTRY];
        
        if (name.strName ==(id)[NSNull null]) {
            continue;
        }
        
        [arrName addObject:name];
    }
    
    return arrName;
}
+(NSMutableArray*)getNamesFromTVSeries_seriesName:(NSString*)seriesName gender:(NSString*)gender type:(NSString*)type
{
    NSMutableArray *arrName=[[NSMutableArray alloc]init];
    
    NSString *queryString;
    if ([gender isEqualToString:@"Alla"])
    {
        queryString=[NSString stringWithFormat:@"SELECT * from tv_series WHERE type=\"%@\" AND type_name=\"%@\"",type,seriesName];
    }
    else if ([gender isEqualToString:@"Pojke"])
    {
        queryString=[NSString stringWithFormat:@"SELECT * from tv_series WHERE type=\"%@\" AND gender='MALE' AND type_name=\"%@\"",type,seriesName];
    }
    else if ([gender isEqualToString:@"Flicka"])
    {
        queryString=[NSString stringWithFormat:@"SELECT * from tv_series WHERE type=\"%@\" AND gender='FEMALE' AND type_name=\"%@\"",type,seriesName];
    }
    
    
    NSMutableArray *arrTemp=[[NSMutableArray alloc]init];
    arrTemp=(NSMutableArray*)[App_Delegate.dbManager getRowsForQuery:queryString];
    
    for (NSMutableDictionary *dic in arrTemp)
    {
        TvObject *name=[[TvObject alloc]initWithDefaults];
        
        name.strName = [dic objectForKey:DB_NAME];
        name.strGender = [dic objectForKey:DB_GENDER];
        name.strType = [dic objectForKey:DB_TYPE];
        name.strTypeName = [dic objectForKey:DB_TYPE_NAME];
        name.strCountry = [dic objectForKey:DB_COUNTRY];
        
        if (name.strName ==(id)[NSNull null]) {
            continue;
        }
        
        [arrName addObject:name];
    }
    
    return arrName;
}
@end
