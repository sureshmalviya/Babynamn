//
//  BrowseListVC.h
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 7/26/16.
//  Copyright (c) 2016 Sahid. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NIDropDown.h"
@interface BrowseListVC : UIViewController<UITableViewDataSource,UITabBarDelegate,NIDropDownDelegate>
{
    NIDropDown *dropDown;
    IBOutlet UIButton *btnYear;
    IBOutlet UIImageView *imgYear;
    
    IBOutlet UIButton *btnGender;
    IBOutlet UIImageView *imgGender;
    
    IBOutlet UITableView *table_names;
    
    IBOutlet UILabel *lblTitle;
    
    NSMutableArray *arrNames;
    
    IBOutlet UIButton *btnAtoZ;
    IBOutlet UIImageView *imgAtoZ;
    
}
@property(strong,nonatomic)NSString *strTitle;
@property BOOL isAtoZclicked;
-(IBAction)btnBackClicked:(UIButton*)sender;
-(IBAction)btnFavouriteClicked:(UIButton*)sender;
-(IBAction)btnDropDownClicked:(UIButton*)sender;

@end
