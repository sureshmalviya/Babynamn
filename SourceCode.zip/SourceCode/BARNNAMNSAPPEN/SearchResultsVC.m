//
//  SearchResultsVC.m
//  BARNNAMNSAPPEN
//
//  Created by Shahid on 7/26/16.
//  Copyright (c) 2016 Sahid. All rights reserved.
//

#import "SearchResultsVC.h"
#import "SearchResultCell.h"
#import "NameDetailVC.h"
#import "MyFavouriteVC.h"

@interface SearchResultsVC ()

@end

@implementation SearchResultsVC
@synthesize object_search;
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    arrNames=[[NSMutableArray alloc]init];//WithObjects:@"Abraham",@"Mohammed",@"Yunus",@"Yakub",@"Aadam",@"Musa",@"Esha",@"Mariyam",@"Aisha",@"Fatima",@"Daood",@"Ismail",@"Abraham",@"Mohammed",@"Yunus",@"Yakub",@"Aadam",@"Musa",@"Esha",@"Mariyam",@"Aisha",@"Fatima",@"Daood",@"Ismail",@"Abraham",@"Mohammed",@"Yunus",@"Yakub",@"Aadam",@"Musa",@"Esha",@"Mariyam",@"Aisha",@"Fatima",@"Daood",@"Ismail", nil];
    
    [self fillInfo];
}
-(void)fillInfo
{
    lblSex.text=object_search.strGender;
    lblBeginsWith.text=object_search.strBeginsWith;
    lblCountry.text=object_search.strCountry;
    lblPopularity.text=object_search.strPopularity;
    lblSyllable.text=object_search.strSyllables;
    
    if ([object_search.strPopularity intValue]==0)
    {
        lblPopularity.text=@"Alla";
    }
    else if ([object_search.strPopularity intValue]==1)
    {
        lblPopularity.text=@"Mkt ovanligt";
    }
    else if ([object_search.strPopularity intValue]==2)
    {
        lblPopularity.text=@"Ovanligt";
    }
    else if ([object_search.strPopularity intValue]==3)
    {
        lblPopularity.text=@"Vanligt";
    }
    
    //
    NSString *gender;
    NSString *queryString;
    if ([object_search.strGender isEqualToString:@"Pojke"]){
        gender=sex_Male;
    }else if ([object_search.strGender isEqualToString:@"Flicka"]){
        gender=sex_Female;
    }
    
    //
    NSString *sex,*initial,*syllabel,*country,*popularity;
    NSMutableArray *arr=[[NSMutableArray alloc]init];
    if ([object_search.strGender isEqualToString:@"Alla"]==NO)
    {
        sex=[NSString stringWithFormat:@"gender=\"%@\"",gender];
        [arr addObject:sex];
    }
    
    if ([object_search.strSyllables isEqualToString:@"Alla"]==NO)
    {
        syllabel=[NSString stringWithFormat:@"syllables=\"%@\"",object_search.strSyllables];
        [arr addObject:syllabel];
    }
    
    if ([object_search.strBeginsWith isEqualToString:@"Alla"]==NO)
    {
        initial=[NSString stringWithFormat:@"initial=\"%@\"",object_search.strBeginsWith];
        [arr addObject:initial];
    }
    
    if ([object_search.strCountry isEqualToString:@"Alla"]==NO)
    {
        country=[NSString stringWithFormat:@"lang_origin LIKE \"%%%@%%\"",object_search.strCountry];
        [arr addObject:country];
    }
    
    if ([object_search.strPopularity intValue]!=0)
    {
        if (arr.count>0)
        {
            if ([object_search.strPopularity intValue]==1)
            {
                popularity=@"master_new.count BETWEEN 0 and 9";
            }
            else if ([object_search.strPopularity intValue]==2)
            {
                popularity=@"master_new.count BETWEEN 10 and 100";
            }
            else if ([object_search.strPopularity intValue]==3)
            {
                popularity=@"master_new.count >101";
            }
            
            NSString *str=@"year=2015";
            
            [arr addObject:str];
            
            [arr addObject:popularity];
        }
        else
        {
            if ([object_search.strPopularity intValue]==1)
            {
                popularity=@"master_new.count BETWEEN 0 and 9";
            }
            else if ([object_search.strPopularity intValue]==2)
            {
                popularity=@"master_new.count BETWEEN 10 and 100";
            }
            else if ([object_search.strPopularity intValue]==3)
            {
                popularity=@"master_new.count >100";
            }
            
            NSString *str=@"year=2015";
            
            [arr addObject:str];
            
            [arr addObject:popularity];
        }
    }
    
    NSString *_query=[arr componentsJoinedByString:@" AND "];
    
    if (_query && [App_Delegate isStringEmpty:_query]==NO)
    {
        queryString=[NSString stringWithFormat:@"SELECT * FROM master_new WHERE %@ GROUP BY name ORDER BY master_new.name ASC",_query];
    }
    else
    {
        queryString=[NSString stringWithFormat:@"SELECT * FROM master_new GROUP BY name ORDER BY master_new.name ASC"];
    }

    NSMutableArray *arrTemp=[NameObject getAllName_MasterTable_query:queryString];

    arrNames=arrTemp;
    
    //arrNames=[App_Delegate sortArray:arrTemp withKey:@"strName" ascending:YES];
    
    [table_names reloadData];
}
-(void)viewDidAppear:(BOOL)animated
{
    if (IS_IPHONE_4)
    {
        
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - Button Actions
-(IBAction)btnBackClicked:(UIButton*)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(IBAction)btnFavouriteClicked:(UIButton*)sender
{
    if (sender.tag==101)//favorite
    {
        MyFavouriteVC *fav=[[MyFavouriteVC alloc]init];
        [self.navigationController pushViewController:fav animated:YES];
    }
    else if (sender.tag==102)//help
    {
        AboutUSVC *obj=[[AboutUSVC alloc]init];
        [self.navigationController pushViewController:obj animated:YES];
        //NSLog(@"Help Clicked");
    }
}

#pragma mark - UITableView Delegates
#pragma mark -
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrNames.count;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 30;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *Identifier = @"SearchResultCell";
    
    SearchResultCell *cell = (SearchResultCell*)[tableView dequeueReusableCellWithIdentifier:Identifier];
    
    if(cell==nil)
    {
        NSArray *topLevelObjects = [[NSBundle mainBundle]loadNibNamed:@"SearchResultCell" owner:nil options:nil];
        cell=[topLevelObjects firstObject];
    }
    
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    
    NameObject *obj=[arrNames objectAtIndex:indexPath.row];
    
    NSString *strName=@"";
    
    if ([obj.strGender isEqualToString:sex_Female]) {
        strName=[NSString stringWithFormat:@"%@ (F)",obj.strName];
    }else{
        strName=[NSString stringWithFormat:@"%@ (P)",obj.strName];
    }

    
    cell.lblName.text=strName;
    
    cell.lblName.backgroundColor=[UIColor clearColor];
    cell.backgroundColor=[UIColor clearColor];
    cell.lblName.textColor=[UIColor whiteColor];
    
    return  cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NameObject *obj=[arrNames objectAtIndex:indexPath.row];
    
    NameDetailVC *objName=[[NameDetailVC alloc]init];
    objName.strTitle=obj.strName;
    objName.strGenderr=obj.strGender;
    [self.navigationController pushViewController:objName animated:YES];
}

@end
