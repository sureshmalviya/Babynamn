//
//  DBFile.h
//  Italic
//
//  Created by FOX-MAC-M on 29/03/14.
//  Copyright (c) 2014 fox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>

@class AppDelegate;
static sqlite3 *database;

@interface DBFile : NSObject
{
    AppDelegate * app;
    NSDateFormatter *formatter;
}
-(id)initWith;
#pragma mark - Form1
-(void)insertValuesInTableForm1:(NSString*)reportName formNo:(NSString*)formNo name:(NSString*)name phone:(NSString*)phone email:(NSString*)email jobInvoice:(NSString*)jobInvoice reportOrderedBy:(NSString*)reportOrderedBy address:(NSString*)address date:(NSString*)date arrivalTime:(NSString*)arrivalTime depTime:(NSString*)depTime weather:(NSString*)weather furnishd:(NSString*)furnished tenacy:(NSString*)tenacy personpresent:(NSString*)personpresent image:(NSString*)image;

#pragma mark - Form2
-(void)insertValuesInTableForm2:(NSString*)reportName formNo:(NSString*)formNo invoice:(NSString*)invoice client:(NSString*)client phone:(NSString*)phone property:(NSString*)property fee:(NSString*)fee amount:(NSString*)amount abnNo:(NSString*)abnNo paidDate:(NSString*)paidDate;

#pragma mark - Form3
-(void)insertValuesInTableForm3:(NSString*)reportName formNo:(NSString*)formNo roofExterior:(NSString*)roofExterior exterior:(NSString*)exterior walls:(NSString*)walls drainage:(NSString*)drainage outBuilding:(NSString*)outBuilding floorSpace:(NSString*)floorSpace roofSpace:(NSString*)roofSpace interior:(NSString*)interior overall:(NSString*)overall;

#pragma mark - Image Description
-(void)insertValuesInTableImgDesc:(NSString*)reportName formNo:(NSString*)formNo image:(NSString*)image desc:(NSString*)desc imgId:(NSString*)imgId;

#pragma mark - Room Description
-(void)insertValuesInTableRoomDesc:(NSString*)reportName formNo:(NSString*)formNo roomName:(NSString*)roomName roomDesc:(NSString*)roomDesc image:(NSString*)image desc:(NSString*)desc roomNo:(NSString*)roomNo;

-(NSMutableArray*)selectRandomEntryFormTableRoomDesc:(NSString*)queryString;

#pragma mark - Text Description
-(void)insertValuesInTableTextDesc:(NSString*)reportName formNo:(NSString*)formNo title:(NSString*)title desc:(NSString*)desc textId:(NSString*)textId;

#pragma mark - Form4
-(void)insertValuesInTableForm4:(NSString*)reportName formNo:(NSString*)formNo que1:(NSString*)que1 que2:(NSString*)que2 que3:(NSString*)que3 que4:(NSString*)que4 que5:(NSString*)que5 que6:(NSString*)que6 que7:(NSString*)que7 que8:(NSString*)que8 que9:(NSString*)que9;

#pragma mark - Form5
-(void)insertValuesInTableForm5:(NSString*)reportName formNo:(NSString*)formNo description:(NSString*)description frontFace:(NSString*)frontFace topography:(NSString*)topography storeys:(NSString*)storeys floorType:(NSString*)floorType wallType:(NSString*)wallType roofType:(NSString*)roofType roofCovering:(NSString*)roofCovering interiorLining:(NSString*)interiorLining noOfBalconies:(NSString*)noOfBalconies location:(NSString*)location;

#pragma mark - Form6
-(void)insertValuesInTableForm6:(NSString*)reportName formNo:(NSString*)formNo pool:(NSString*)pool cpr:(NSString*)cpr fence:(NSString*)fence fenceNote:(NSString*)fenceNote imgPath1:(NSString*)imgPath1 imgPath2:(NSString*)imgPath2 imgPath3:(NSString*)imgPath3 imgNote1:(NSString*)imgNote1 imgNote2:(NSString*)imgNote2 imgNote3:(NSString*)imgNote3 shed:(NSString*)shed shedcmt:(NSString*)shedcmt garage:(NSString*)garage garagecmt:(NSString*)garagecmt carport:(NSString*)carport carportcmt:(NSString*)carportcmt pergola:(NSString*)pergola pergolacmt:(NSString*)pergolacmt decking:(NSString*)decking deckingcmt:(NSString*)deckingcmt outbuilding:(NSString*)outbuilding outbuildingcmt:(NSString*)outbuildingcmt flat:(NSString*)flat flatcmt:(NSString*)flatcmt;

#pragma mark - Form7
-(void)insertValuesInTableForm7:(NSString*)reportName formNo:(NSString*)formNo params:(NSMutableDictionary*)dicParams;

#pragma mark - Form8
-(void)insertValuesInTableForm8:(NSString*)reportName formNo:(NSString*)formNo cracking:(NSString*)cracking engineer:(NSString*)engineer;

#pragma mark - Form9
-(void)insertValuesInTableForm9:(NSString*)reportName formNo:(NSString*)formNo param:(NSMutableDictionary*)dicParam;


#pragma mark - Form10
-(void)insertValuesInTableForm10:(NSString*)reportName formNo:(NSString*)formNo imgPath1:(NSString*)imgPath1 imgDesc1:(NSString*)imgDesc1 imgPath2:(NSString*)imgPath2 imgDesc2:(NSString*)imgDesc2 imgPath3:(NSString*)imgPath3 imgDesc3:(NSString*)imgDesc3 imgPath4:(NSString*)imgPath4 imgDesc4:(NSString*)imgDesc4 imgPath5:(NSString*)imgPath5 imgDesc5:(NSString*)imgDesc5 imgPath6:(NSString*)imgPath6 imgDesc6:(NSString*)imgDesc6 que1:(NSString*)que1 cmt1:(NSString*)cmt1 que2:(NSString*)que2 cmt2:(NSString*)cmt2 que3:(NSString*)que3 cmt3:(NSString*)cmt3 que4:(NSString*)que4 cmt4:(NSString*)cmt4 que5:(NSString*)que5 cmt5:(NSString*)cmt5 que6:(NSString*)que6 cmt6:(NSString*)cmt6 que7:(NSString*)que7 cmt7:(NSString*)cmt7 que8:(NSString*)que8 cmt8:(NSString*)cmt8 que9:(NSString*)que9 cmt9:(NSString*)cmt9 que10:(NSString*)que10 cmt10:(NSString*)cmt10 que11:(NSString*)que11 cmt11:(NSString*)cmt11 que12:(NSString*)que12 cmt12:(NSString*)cmt12 que13:(NSString*)que13 cmt13:(NSString*)cmt13 que14:(NSString*)que14 cmt14:(NSString*)cmt14 que15:(NSString*)que15 cmt15:(NSString*)cmt15 que16:(NSString*)que16 cmt16:(NSString*)cmt16 que17:(NSString*)que17 cmt17:(NSString*)cmt17 que18:(NSString*)que18 cmt18:(NSString*)cmt18 que19:(NSString*)que19 cmt19:(NSString*)cmt19;

#pragma mark - Form11
-(void)insertValuesInTableForm11:(NSString*)reportName formNo:(NSString*)formNo que0:(NSString*)que0 desc0:(NSString*)desc0 que1:(NSString*)que1 desc1:(NSString*)desc1 que2:(NSString*)que2 desc2:(NSString*)desc2 que3:(NSString*)que3 desc3:(NSString*)desc3 que4:(NSString*)que4 desc4:(NSString*)desc4 que5:(NSString*)que5 desc5:(NSString*)desc5 que6:(NSString*)que6 desc6:(NSString*)desc6 que7:(NSString*)que7 desc7:(NSString*)desc7;

#pragma mark - Form12
-(void)insertValuesInTableForm12:(NSString*)reportName formNo:(NSString*)formNo que0:(NSString*)que0 desc0:(NSString*)desc0 que1:(NSString*)que1 desc1:(NSString*)desc1 que2:(NSString*)que2 desc2:(NSString*)desc2 que3:(NSString*)que3 desc3:(NSString*)desc3 que4:(NSString*)que4 desc4:(NSString*)desc4 que5:(NSString*)que5 desc5:(NSString*)desc5 que6:(NSString*)que6 desc6:(NSString*)desc6 que7:(NSString*)que7 desc7:(NSString*)desc7 que8:(NSString*)que8 desc8:(NSString*)desc8 que9:(NSString*)que9 desc9:(NSString*)desc9 que10:(NSString*)que10 desc10:(NSString*)desc10 que11:(NSString*)que11 desc11:(NSString*)desc11 que12:(NSString*)que12 desc12:(NSString*)desc12 que13:(NSString*)que13 desc13:(NSString*)desc13;

#pragma mark - Form13
-(void)insertValuesInTableForm13:(NSString*)reportName formNo:(NSString*)formNo que0:(NSString*)que0 desc0:(NSString*)desc0 que1:(NSString*)que1 desc1:(NSString*)desc1 que2:(NSString*)que2 desc2:(NSString*)desc2 que3:(NSString*)que3 desc3:(NSString*)desc3 que4:(NSString*)que4 desc4:(NSString*)desc4 que5:(NSString*)que5 desc5:(NSString*)desc5 que6:(NSString*)que6 desc6:(NSString*)desc6 que7:(NSString*)que7 desc7:(NSString*)desc7 que8:(NSString*)que8 desc8:(NSString*)desc8 que9:(NSString*)que9 desc9:(NSString*)desc9 que10:(NSString*)que10 desc10:(NSString*)desc10 que11:(NSString*)que11 desc11:(NSString*)desc11 que12:(NSString*)que12 desc12:(NSString*)desc12 que13:(NSString*)que13 desc13:(NSString*)desc13 que14:(NSString*)que14 desc14:(NSString*)desc14 que15:(NSString*)que15 desc15:(NSString*)desc15;

#pragma mark - Form14
-(void)insertValuesInTableForm14:(NSString*)reportName formNo:(NSString*)formNo que0:(NSString*)que0 desc0:(NSString*)desc0 que1:(NSString*)que1 desc1:(NSString*)desc1 que2:(NSString*)que2 desc2:(NSString*)desc2 que3:(NSString*)que3 desc3:(NSString*)desc3 que4:(NSString*)que4 desc4:(NSString*)desc4 que5:(NSString*)que5 desc5:(NSString*)desc5 que6:(NSString*)que6 desc6:(NSString*)desc6 que7:(NSString*)que7 desc7:(NSString*)desc7 que8:(NSString*)que8 desc8:(NSString*)desc8 que9:(NSString*)que9 desc9:(NSString*)desc9 que10:(NSString*)que10 desc10:(NSString*)desc10 que11:(NSString*)que11 desc11:(NSString*)desc11 que12:(NSString*)que12 desc12:(NSString*)desc12 que13:(NSString*)que13 desc13:(NSString*)desc13 que14:(NSString*)que14 desc14:(NSString*)desc14 que15:(NSString*)que15 desc15:(NSString*)desc15 que16:(NSString*)que16 desc16:(NSString*)desc16 que17:(NSString*)que17 desc17:(NSString*)desc17 que18:(NSString*)que18 desc18:(NSString*)desc18 que19:(NSString*)que19 desc19:(NSString*)desc19;

#pragma mark - Form16
-(void)insertValuesInTableForm16:(NSString*)reportName formNo:(NSString*)formNo que0:(NSString*)que0 que1:(NSString*)que1 que2:(NSString*)que2 que3:(NSString*)que3 que4:(NSString*)que4 que5:(NSString*)que5 que6:(NSString*)que6 que7:(NSString*)que7 que8:(NSString*)que8 que9:(NSString*)que9 que10:(NSString*)que10 que11:(NSString*)que11 que12:(NSString*)que12 que13:(NSString*)que13 que14:(NSString*)que14 que15:(NSString*)que15 que16:(NSString*)que16  que17:(NSString*)que17 que18:(NSString*)que18 que19:(NSString*)que19 que20:(NSString*)que20 que21:(NSString*)que21 que22:(NSString*)que22 que23:(NSString*)que23 que24:(NSString*)que24 que25:(NSString*)que25 que26:(NSString*)que26 que27:(NSString*)que27;

#pragma mark - tableSignature
-(void)insertValuesInTableSignatre:(NSString*)reportName imagePath:(NSString*)imagePath sign:(NSString*)sign date:(NSString*)date;


//insertValuesInTable 2
-(void)insertValuesInTableItem:(NSString*)pdfname item:(NSString*)item date1:(NSString*)date1 date2:(NSString*)date2 date3:(NSString*)date3 date4:(NSString*)date4 temp1:(NSString*)temp1 temp2:(NSString*)temp2 temp3:(NSString*)temp3 temp4:(NSString*)temp4 mc1:(NSString*)mc1 mc2:(NSString*)mc2 mc3:(NSString*)mc3 mc4:(NSString*)mc4 viewId:(NSString*)viewId description:(NSString*)description;













//select query 1
-(NSMutableArray*)selectRandomEntryFormTableHeader:(NSString*)pdfName;

//select query 2
-(NSMutableArray*)selectRandomEntryFormTableItem:(NSString*)pdfName withViewId:(NSString*)viewId;

//PDF2-----------------

//insertValuesInTableRowCount 1
-(void)insertValuesInTableRowCount:(NSString*)pdfName rowCount1:(int)rowCount1 rowCount2:(int)rowCount2;

//insertValuesInTableHeader 1
-(void)insertValuesInTableHeader1:(NSString*)pdfName title:(NSString*)title invoice:(NSString*)invoice name:(NSString*)name address:(NSString*)address city:(NSString*)city phone:(NSString*)phone area:(NSString*)area datetime:(NSString*)datetime category:(NSString*)category class:(NSString*)class superviser:(NSString*)superviser;

//insertValuesInTableHeader 2
-(void)insertValuesInTableHeadre2:(NSString*)pdfName titleatmos:(NSString*)titleAtmos inspection1:(NSString*)inspection1 inspection2:(NSString*)inspection2 inspection3:(NSString*)inspection3 inspection4:(NSString*)inspection4 inspection5:(NSString*)inspection5 titleEquipment:(NSString*)titleEquipment cfm1:(NSString*)cfm1 cfm2:(NSString*)cfm2 cfm3:(NSString*)cfm3 cfm4:(NSString*)cfm4 cfm5:(NSString*)cfm5 inspection11:(NSString*)inspection11 inspection22:(NSString*)inspection22 inspection33:(NSString*)inspection33 inspection44:(NSString*)inspection44 inspection55:(NSString*)inspection55;

//insertValuesInTableRow
-(void)insertValuesInTableRow:(NSString*)pdfname viewId:(NSString*)viewId rowNumber:(int)rowNumber dateTime:(NSString*)dateTime temp1:(NSString*)temp1 rh1:(NSString*)rh1 gpp1:(NSString*)gpp1 temp2:(NSString*)temp2 rh2:(NSString*)rh2 gpp2:(NSString*)gpp2 temp3:(NSString*)temp3 rh3:(NSString*)rh3 gpp3:(NSString*)gpp3 temp4:(NSString*)temp4 rh4:(NSString*)rh4 gpp4:(NSString*)gpp4 temp5:(NSString*)temp5 rh5:(NSString*)rh5 gpp5:(NSString*)gpp5;

//select query for TableNumberOfRows
-(NSMutableArray*)selectRandomEntryFormTableRowCount:(NSString*)pdfName;

//select query 1
-(NSMutableArray*)selectRandomEntryFormTableHeader1:(NSString*)pdfName;

//select query 2
-(NSMutableArray*)selectRandomEntryFormTableHeader2:(NSString*)pdfName;

//select query 3
-(NSMutableArray*)selectRandomEntryFormTableRow:(NSString*)pdfName withViewId:(NSString*)viewId andRowNumber:(int)rowNumber;
//remove entry frpm pdf1_header
-(NSMutableArray*)removeEntry:(NSString*)fileName withQuery:(NSString*)queryString;

//  CREATE TABLE "tableForm9" ("" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR, "" VARCHAR)

@end
